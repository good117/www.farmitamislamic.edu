import { useEffect, useState, type FormEvent } from 'react';
import { Mail, Phone, Plus, Search, Trash2, X } from 'lucide-react';
import { useDescriptionLanguage } from '../context/LanguageContext';
import {
  CAMPUS_GALLERY_FIGURES,
  FACULTY_MEMBERS,
  INSTITUTION_CONTACT,
  type FacultyDepartment,
  type FacultyMember,
} from '../data/schoolData';
import {
  createCustomFacultyMember,
  filterFaculty,
  validateNewFacultyInput,
  type NewFacultyErrors,
  type NewFacultyFormInput,
} from '../utils/admissions';
import { ResilientImage } from './ResilientImage';

const CUSTOM_FACULTY_STORAGE_KEY = 'farmitam_custom_faculty_v1';

const LEADERSHIP_COPY = {
  bn: {
    paragraphs: [
      'FARMITAM Islamic School & College-এ আমাদের শিক্ষা সংস্কৃতি গড়ে উঠেছে প্রতিদিনের ব্যক্তিগত মেন্টরশিপ ও নিবিড় তত্ত্বাবধানের ওপর। কোনো শিক্ষার্থী নূরানী (কায়েদা, আমপারা ও কুরআন) অথবা প্লে-গ্রুপ দিয়ে শুরু করুক, জেনারেল (প্লে–দশম) শাখায় অগ্রসর হোক, দুই বছর মেয়াদী ক্যাডেট প্রোগ্রামে প্রশিক্ষণ নিক, কিংবা হিফজুল কুরআন বিভাগে পবিত্র কুরআন মুখস্থ করুক—প্রত্যেকেই পায় শিক্ষকের একান্ত মনোযোগ।',
      'কোনাবাড়ী ক্যাম্পাসে কনিষ্ঠ (প্লে থেকে পঞ্চম) ও জ্যেষ্ঠ (ষষ্ঠ থেকে দশম ও ক্যাডেট) শিক্ষার্থীদের বয়সোপযোগী আনন্দময় শ্রেণিকক্ষ, শান্ত কুরআন শিক্ষাকক্ষ, সমৃদ্ধ কেন্দ্রীয় পাঠাগার এবং আধুনিক বিজ্ঞান গবেষণাগারের সমন্বয়ে গড়ে উঠেছে সুশৃঙ্খল শিক্ষা পরিবেশ।',
    ],
    chiefDirectorCredentials: `প্রধান পরিচালক, ${INSTITUTION_CONTACT.bnName} · অনার্স ও মাস্টার্স (ইংরেজি ভাষা ও সাহিত্য), জাতীয় বিশ্ববিদ্যালয়`,
    quote:
      '“উপকারী জ্ঞান অর্জন করো যা ইহকাল ও পরকাল উভয়কেই আলোকিত করে—পদ্ধতিতে সুশৃঙ্খল, চরিত্রে বিনয়ী এবং মানবতার সেবায় অবিচল।”',
    quoteFooter: 'প্রতিষ্ঠাকালীন প্রাতিষ্ঠানিক আদর্শ · ফারমিটম একাডেমিক সিন্ডিকেট, ২০২৬',
    searchPlaceholder: 'শিক্ষকের নাম, পদবি বা বিষয় লিখুন...',
    searchAria: 'নাম, পদবি বা বিষয় অনুযায়ী শিক্ষক খুঁজুন',
    departments: {
      All: 'সকল বিভাগ',
      School: 'স্কুল শাখা',
      Cadet: 'ক্যাডেট বিভাগ',
      Noorani: 'নূরানী বিভাগ',
      'Hifzul Quran': 'হিফজুল কুরআন বিভাগ',
    },
    addTeacherBtn: 'নতুন শিক্ষক যুক্ত করুন',
    closeAddTeacherBtn: 'ফরম বন্ধ করুন',
    formHeading: 'নতুন শিক্ষক / বিভাগীয় দায়িত্বশীল যুক্ত করুন',
    formSubheading: 'স্কুল শাখা, ক্যাডেট, নূরানী অথবা হিফজুল কুরআন বিভাগে নতুন শিক্ষকের তথ্য সংরক্ষণ করুন।',
    labelDepartment: 'বিভাগ / শাখা *',
    labelName: 'শিক্ষকের পূর্ণ নাম *',
    placeholderName: 'যেমন: মাওলানা আব্দুল করিম',
    labelRole: 'পদবি ও বিষয় *',
    placeholderRole: 'যেমন: সিনিয়র গণিত শিক্ষক',
    labelCredentials: 'শিক্ষাগত যোগ্যতা ও বিশ্ববিদ্যালয় *',
    placeholderCredentials: 'যেমন: অনার্স ও মাস্টার্স (গণিত), জাতীয় বিশ্ববিদ্যালয়',
    labelPhone: 'মোবাইল নম্বর (ঐচ্ছিক)',
    placeholderPhone: '018XXXXXXXX',
    labelEmail: 'ইমেইল ঠিকানা (ঐচ্ছিক)',
    placeholderEmail: 'teacher@example.com',
    labelFocus: 'পাঠদান ও দায়িত্বের বিবরণ (ঐচ্ছিক)',
    placeholderFocus: 'সংশ্লিষ্ট বিভাগে পাঠদান ও তত্ত্বাবধানের সংক্ষিপ্ত বিবরণ',
    submitTeacher: 'শিক্ষক তালিকায় যুক্ত করুন',
    cancelBtn: 'বাতিল করুন',
    vacantNameText: 'নাম: ______________________',
    vacantHint: 'এই বিভাগের শিক্ষকের নাম এখনো ফাঁকা রাখা হয়েছে',
    assignToWingBtn: 'এই বিভাগে শিক্ষক যুক্ত করুন',
    removeCustomBtn: 'তালিকা থেকে সরান',
    emptyTitle: 'কোনো শিক্ষকের তথ্য পাওয়া যায়নি',
    emptySubtitle: 'সকল শিক্ষকের তালিকা দেখতে বিভাগ বা অনুসন্ধান শব্দ পরিবর্তন করুন।',
    resetFilter: 'ফিল্টার রিসেট করুন',
    officeHoursLabel: 'সময়সূচি',
    callLabel: 'ফোন',
    emailLabel: 'ইমেইল',
  },
  en: {
    paragraphs: [
      'At FARMITAM Islamic School & College, our educational culture is built on daily personal mentorship and attentive guidance. Whether a child enters Playgroup and Noorani (Quyeda, Ampar and Quran), progresses through General (Play to Ten), trains in the Two-Year Cadet Program, or memorizes the Quran in Hifzul Quran, every learner receives dedicated faculty attention.',
      'Across our Konabari campus, tailored age-appropriate classrooms for younger learners (Play to Primary) sit alongside senior high-school and Cadet study courtyards (Classes VI–X), quiet Quranic circles, our central reading hall, and modern STEM laboratories.',
    ],
    chiefDirectorCredentials: `Chief Director, ${INSTITUTION_CONTACT.name} · Honours & Masters (English Language & Literature), National University`,
    quote:
      '“Seek beneficial knowledge that illuminates both this world and the hereafter—disciplined in method, humble in character, and steadfast in service to humanity.”',
    quoteFooter: 'Founding Institutional Charter · FARMITAM Academic Syndicate, 2026',
    searchPlaceholder: 'Search faculty by name, role, or degree...',
    searchAria: 'Search faculty by name, role, or degree',
    departments: {
      All: 'All Wings',
      School: 'School Wing',
      Cadet: 'Cadet Division',
      Noorani: 'Noorani Division',
      'Hifzul Quran': 'Hifzul Quran',
    },
    addTeacherBtn: 'Add Teacher',
    closeAddTeacherBtn: 'Close Form',
    formHeading: 'Add Faculty Member',
    formSubheading: 'Add a teacher or assign faculty details to School Wing, Cadet, Noorani, or Hifzul Quran.',
    labelDepartment: 'Wing / Division *',
    labelName: 'Full Name *',
    placeholderName: 'e.g. Md. Abdul Karim',
    labelRole: 'Designation & Subject *',
    placeholderRole: 'e.g. Senior Mathematics Teacher',
    labelCredentials: 'Qualification & University *',
    placeholderCredentials: 'e.g. Honours & Masters, National University',
    labelPhone: 'Phone Number (Optional)',
    placeholderPhone: '018XXXXXXXX',
    labelEmail: 'Email Address (Optional)',
    placeholderEmail: 'teacher@example.com',
    labelFocus: 'Teaching Focus (Optional)',
    placeholderFocus: 'Brief summary of subjects or mentorship responsibilities',
    submitTeacher: 'Add to Directory',
    cancelBtn: 'Cancel',
    vacantNameText: 'Name: ______________________',
    vacantHint: 'Teacher name for this division is currently left blank',
    assignToWingBtn: 'Assign Teacher to Division',
    removeCustomBtn: 'Remove entry',
    emptyTitle: 'No matching faculty found',
    emptySubtitle: 'Clear your department filter or search term to view all educators.',
    resetFilter: 'Reset filters',
    officeHoursLabel: 'Schedule',
    callLabel: 'Phone',
    emailLabel: 'Email',
  },
  ar: {
    paragraphs: [
      'تقوم ثقافتنا التعليمية في مدرسة وكلية فارميتام الإسلامية على التوجيه الشخصي اليومي والرعاية الدقيقة؛ فسواء بدأ الطالب في مرحلة الروضة والنوراني (القاعدة وعمّ والقرآن)، أو واصل في القسم العام حتى الصف العاشر، أو التحق ببرنامج الكاديت لمدة سنتين، أو تفرغ لتحفيظ القرآن الكريم، فإنه ينال عناية تربوية متخصصة.',
      'يضم حرمنا الدراسي في كوناباري فصولاً مخصصة للصغار (من الروضة إلى الخامس) بأسلوب تعليمي محبب، إلى جانب ساحات دراسية منظمة لطلاب المرحلة العليا والكاديت (السادس إلى العاشر)، وحلقات القرآن، والمكتبة المركزية، والمختبرات العلمية الحديثة.',
    ],
    chiefDirectorCredentials: `المدير العام، ${INSTITUTION_CONTACT.arName} · بكالوريوس وماجستير (اللغة الإنجليزية)، الجامعة الوطنية`,
    quote:
      '«اطلب العلم النافع الذي ينير الدنيا والآخرة — منضبطاً في المنهج، متواضعاً في الخُلُق، ثابتاً في خدمة الإنسان.»',
    quoteFooter: 'الميثاق التأسيسي للمؤسسة · مجلس فارميتام الأكاديمي ٢٠٢٦',
    searchPlaceholder: 'ابحث عن أستاذ أو تخصص...',
    searchAria: 'البحث عن الأساتذة حسب الاسم أو التخصص',
    departments: {
      All: 'جميع الأقسام',
      School: 'القسم المدرسي',
      Cadet: 'قسم الكاديت',
      Noorani: 'قسم النوراني',
      'Hifzul Quran': 'تحفيظ القرآن',
    },
    addTeacherBtn: 'إضافة أستاذ جديد',
    closeAddTeacherBtn: 'إغلاق النموذج',
    formHeading: 'إضافة أستاذ أو مشرف جديد',
    formSubheading: 'أضف بيانات الأستاذ إلى القسم المدرسي أو الكاديت أو النوراني أو تحفيظ القرآن.',
    labelDepartment: 'القسم / الشعبة *',
    labelName: 'الاسم الكامل للأستاذ *',
    placeholderName: 'مثال: الأستاذ عبد الكريم',
    labelRole: 'المسمى الوظيفي والمادة *',
    placeholderRole: 'مثال: معلم الرياضيات الأول',
    labelCredentials: 'المؤهل العلمي والجامعة *',
    placeholderCredentials: 'مثال: بكالوريوس وماجستير، الجامعة الوطنية',
    labelPhone: 'رقم الهاتف (اختياري)',
    placeholderPhone: '018XXXXXXXX',
    labelEmail: 'البريد الإلكتروني (اختياري)',
    placeholderEmail: 'teacher@example.com',
    labelFocus: 'مجال التدريس والمهام (اختياري)',
    placeholderFocus: 'وصف موجز للمهام التدريسية والإشرافية',
    submitTeacher: 'إضافة إلى القائمة',
    cancelBtn: 'إلغاء',
    vacantNameText: 'الاسم: ______________________',
    vacantHint: 'اسم المدرس لهذا القسم متروك فارغاً حالياً',
    assignToWingBtn: 'تعيين أستاذ لهذا القسم',
    removeCustomBtn: 'حذف الإضافة',
    emptyTitle: 'لم يتم العثور على أساتذة مطابقين',
    emptySubtitle: 'قم بتعديل القسم أو كلمة البحث لعرض جميع أعضاء هيئة التدريس.',
    resetFilter: 'إعادة تعيين التصفية',
    officeHoursLabel: 'المواعيد',
    callLabel: 'الهاتف',
    emailLabel: 'البريد',
  },
};

const DEPARTMENT_KEYS: Array<'All' | FacultyDepartment> = [
  'All',
  'School',
  'Cadet',
  'Noorani',
  'Hifzul Quran',
];

const ADDABLE_DEPARTMENTS: FacultyDepartment[] = ['School', 'Cadet', 'Noorani', 'Hifzul Quran'];

const EMPTY_FORM: NewFacultyFormInput = {
  name: '',
  role: '',
  department: 'School',
  credentials: '',
  phone: '',
  email: '',
  focus: '',
};

export function LeadershipFacultySection() {
  const { lang, dir } = useDescriptionLanguage();
  const copy = LEADERSHIP_COPY[lang];
  const [department, setDepartment] = useState<'All' | FacultyDepartment>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [customFaculty, setCustomFaculty] = useState<FacultyMember[]>(() => {
    try {
      const raw = window.localStorage.getItem(CUSTOM_FACULTY_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });
  const [isAddFormOpen, setIsAddFormOpen] = useState(false);
  const [formInput, setFormInput] = useState<NewFacultyFormInput>(EMPTY_FORM);
  const [formErrors, setFormErrors] = useState<NewFacultyErrors>({});

  useEffect(() => {
    try {
      window.localStorage.setItem(CUSTOM_FACULTY_STORAGE_KEY, JSON.stringify(customFaculty));
    } catch {
      // Ignore storage failures in restricted contexts
    }
  }, [customFaculty]);

  // Keep other divisions' default placeholder cards blank-named until a custom teacher is added to that division
  const customDepartmentsFilled = new Set(customFaculty.map((member) => member.department));
  const combinedFaculty: FacultyMember[] = [
    ...FACULTY_MEMBERS.filter(
      (member) => !(member.isNameVacant && customDepartmentsFilled.has(member.department))
    ),
    ...customFaculty,
  ];

  const visibleFaculty = filterFaculty(combinedFaculty, department, searchQuery);

  const openAddFormForDepartment = (targetDept: FacultyDepartment) => {
    setFormInput({
      ...EMPTY_FORM,
      department: targetDept,
    });
    setFormErrors({});
    setIsAddFormOpen(true);
  };

  const handleAddTeacherSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const errors = validateNewFacultyInput(formInput, lang);
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    const newMember = createCustomFacultyMember(formInput);
    setCustomFaculty((prev) => [...prev, newMember]);
    setDepartment('All');
    setSearchQuery('');
    setFormInput(EMPTY_FORM);
    setFormErrors({});
    setIsAddFormOpen(false);
  };

  const handleRemoveCustomTeacher = (id: string) => {
    setCustomFaculty((prev) => prev.filter((member) => member.id !== id));
  };

  return (
    <>
      {/* Leadership & Campus Student Environments */}
      <section id="leadership" className="py-16 lg:py-20 border-b border-[#E5DFD2] bg-[#FAF8F4]">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
            {/* Chief Director's Editorial Address & Quote (5 cols) */}
            <div className="lg:col-span-5 space-y-5">
              <p className="text-xs font-medium tracking-wide text-[#8E6210]">
                ০৪. নেতৃত্ব, শিক্ষার্থী ও ক্যাম্পাস পরিবেশ · Campus &amp; Students ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic">
                  القيادة وبيئة الطلاب
                </span>
              </p>
              <h2 className="font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-[#14231B] text-balance">
                আত্মিক শুদ্ধতা ও মেধার সমন্বিত বিকাশ
              </h2>
              <p className="text-sm font-medium text-[#2D4C3B]">
                Educating the Mind Without Neglecting the Soul ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic font-semibold text-[#8E6210]">
                  تربية العقول وتزكية النفوس
                </span>
              </p>

              <div
                dir={dir}
                lang={lang}
                className={`pt-4 border-t border-[#DCD5C7] space-y-4 text-[15.5px] leading-[1.8] text-[#354039] max-w-[65ch] ${
                  lang === 'ar' ? 'font-arabic text-right' : ''
                }`}
              >
                {copy.paragraphs.map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>

              <div className="pt-4 border-t border-[#DCD5C7] space-y-0.5">
                <p className="font-serif text-lg font-semibold text-[#182E23]">হাফেজ আব্দুর রাজ্জাক</p>
                <p className="text-xs font-medium text-[#2D4C3B]">
                  Hafez Abdur Razzak ·{' '}
                  <span dir="rtl" lang="ar" className="font-arabic text-[#8E6210]">
                    الحافظ عبد الرزاق
                  </span>
                </p>
                <p
                  dir={dir}
                  lang={lang}
                  className={`text-xs text-[#5B665F] pt-0.5 ${lang === 'ar' ? 'font-arabic text-right' : ''}`}
                >
                  {copy.chiefDirectorCredentials}
                </p>
              </div>

              <blockquote
                dir={dir}
                lang={lang}
                className={`py-5 border-y border-[#DCD5C7] ${lang === 'ar' ? 'font-arabic text-right' : ''}`}
              >
                <p className="font-serif text-lg sm:text-xl italic leading-snug text-[#182E23]">
                  {copy.quote}
                </p>
                <footer className="mt-2 text-xs text-[#5B665F]">{copy.quoteFooter}</footer>
              </blockquote>
            </div>

            {/* Junior & Senior Students + Campus Environment Gallery (7 cols) */}
            <div className="lg:col-span-7">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6" data-testid="student-environment-gallery">
                {CAMPUS_GALLERY_FIGURES.map((fig) => (
                  <figure key={fig.id} className="flex flex-col">
                    <div className="aspect-[4/3] rounded-lg overflow-hidden border border-[#DCD5C7] bg-[#EFECE4]">
                      <ResilientImage
                        src={fig.src}
                        alt={fig.altByLang[lang]}
                        className="w-full h-full object-cover"
                        fallbackTitle={fig.fallbackTitle}
                      />
                    </div>
                    <figcaption
                      dir={dir}
                      lang={lang}
                      className={`mt-2.5 text-xs font-serif italic text-[#5B665F] ${
                        lang === 'ar' ? 'font-arabic text-right not-italic' : ''
                      }`}
                    >
                      {fig.captionByLang[lang]}
                    </figcaption>
                  </figure>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Faculty & Scholars Directory */}
      <section id="faculty" className="py-16 lg:py-20 border-b border-[#E5DFD2] bg-white">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-[#E5DFD2]">
            <div>
              <p className="text-xs font-medium tracking-wide text-[#8E6210]">
                ০৫. অভিজ্ঞ শিক্ষকমণ্ডলী · Scholars &amp; Educators ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic">
                  الأساتذة والعلماء
                </span>
              </p>
              <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-[#14231B]">
                শিক্ষকমণ্ডলীর পরিচিতি
              </h2>
              <p className="mt-1 text-sm font-medium text-[#2D4C3B]">
                Faculty Directory ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic font-semibold text-[#8E6210]">
                  هيئة التدريس
                </span>
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full md:w-auto">
              <div className="w-full sm:w-64 relative">
                <label htmlFor="faculty-search" className="sr-only">
                  {copy.searchAria}
                </label>
                <Search
                  className="w-4 h-4 text-[#6B766F] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                  aria-hidden="true"
                />
                <input
                  id="faculty-search"
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={copy.searchPlaceholder}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] placeholder:text-[#6B766F] focus:outline-2 focus:outline-[#234232]"
                />
              </div>

              <button
                type="button"
                onClick={() => setIsAddFormOpen((prev) => !prev)}
                aria-expanded={isAddFormOpen}
                className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-[#234232] hover:bg-[#182E23] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#234232]"
              >
                {isAddFormOpen ? (
                  <X className="w-4 h-4" aria-hidden="true" />
                ) : (
                  <Plus className="w-4 h-4" aria-hidden="true" />
                )}
                <span>{isAddFormOpen ? copy.closeAddTeacherBtn : copy.addTeacherBtn}</span>
              </button>
            </div>
          </div>

          {/* Department Filter Buttons */}
          <div
            className="mt-6 flex flex-wrap gap-2"
            role="group"
            aria-label="বিভাগ অনুযায়ী শিক্ষক ফিল্টার করুন"
          >
            {DEPARTMENT_KEYS.map((deptKey) => {
              const isSelected = deptKey === department;
              return (
                <button
                  key={deptKey}
                  type="button"
                  onClick={() => setDepartment(deptKey)}
                  aria-pressed={isSelected}
                  className={`px-3.5 py-1.5 text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#234232] ${
                    isSelected
                      ? 'bg-[#234232] text-white'
                      : 'bg-[#F5F2EB] text-[#354039] hover:bg-[#E9E3D5]'
                  }`}
                >
                  {copy.departments[deptKey]}
                </button>
              );
            })}
          </div>

          {/* Optional Add New Faculty Member Form (uses <form> so div:nth-of-type(3) stays the faculty grid) */}
          {isAddFormOpen && (
            <form
              onSubmit={handleAddTeacherSubmit}
              noValidate
              dir={dir}
              lang={lang}
              data-testid="add-faculty-form"
              className={`mt-6 p-6 border border-[#234232]/30 rounded-lg bg-[#FAF8F4] space-y-4 ${
                lang === 'ar' ? 'font-arabic text-right' : ''
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#DCD5C7]">
                <div>
                  <h3 className="font-serif text-lg font-semibold text-[#182E23]">{copy.formHeading}</h3>
                  <p className="text-xs text-[#5B665F]">{copy.formSubheading}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <label htmlFor="new-faculty-dept" className="block text-xs font-semibold text-[#182E23] mb-1">
                    {copy.labelDepartment}
                  </label>
                  <select
                    id="new-faculty-dept"
                    value={formInput.department}
                    onChange={(e) =>
                      setFormInput((prev) => ({ ...prev, department: e.target.value as FacultyDepartment }))
                    }
                    className="w-full px-3 py-2 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                  >
                    {ADDABLE_DEPARTMENTS.map((deptKey) => (
                      <option key={deptKey} value={deptKey}>
                        {copy.departments[deptKey]}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="new-faculty-name" className="block text-xs font-semibold text-[#182E23] mb-1">
                    {copy.labelName}
                  </label>
                  <input
                    id="new-faculty-name"
                    type="text"
                    value={formInput.name}
                    onChange={(e) => {
                      setFormInput((prev) => ({ ...prev, name: e.target.value }));
                      if (formErrors.name) setFormErrors((prev) => ({ ...prev, name: undefined }));
                    }}
                    placeholder={copy.placeholderName}
                    className="w-full px-3 py-2 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                  />
                  {formErrors.name && <p className="mt-1 text-xs text-[#9E2A2B]">{formErrors.name}</p>}
                </div>

                <div>
                  <label htmlFor="new-faculty-role" className="block text-xs font-semibold text-[#182E23] mb-1">
                    {copy.labelRole}
                  </label>
                  <input
                    id="new-faculty-role"
                    type="text"
                    value={formInput.role}
                    onChange={(e) => {
                      setFormInput((prev) => ({ ...prev, role: e.target.value }));
                      if (formErrors.role) setFormErrors((prev) => ({ ...prev, role: undefined }));
                    }}
                    placeholder={copy.placeholderRole}
                    className="w-full px-3 py-2 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                  />
                  {formErrors.role && <p className="mt-1 text-xs text-[#9E2A2B]">{formErrors.role}</p>}
                </div>

                <div className="sm:col-span-2 lg:col-span-1">
                  <label htmlFor="new-faculty-credentials" className="block text-xs font-semibold text-[#182E23] mb-1">
                    {copy.labelCredentials}
                  </label>
                  <input
                    id="new-faculty-credentials"
                    type="text"
                    value={formInput.credentials}
                    onChange={(e) => {
                      setFormInput((prev) => ({ ...prev, credentials: e.target.value }));
                      if (formErrors.credentials)
                        setFormErrors((prev) => ({ ...prev, credentials: undefined }));
                    }}
                    placeholder={copy.placeholderCredentials}
                    className="w-full px-3 py-2 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                  />
                  {formErrors.credentials && (
                    <p className="mt-1 text-xs text-[#9E2A2B]">{formErrors.credentials}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="new-faculty-phone" className="block text-xs font-semibold text-[#182E23] mb-1">
                    {copy.labelPhone}
                  </label>
                  <input
                    id="new-faculty-phone"
                    type="tel"
                    value={formInput.phone ?? ''}
                    onChange={(e) => setFormInput((prev) => ({ ...prev, phone: e.target.value }))}
                    placeholder={copy.placeholderPhone}
                    className="w-full px-3 py-2 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                  />
                </div>

                <div>
                  <label htmlFor="new-faculty-email" className="block text-xs font-semibold text-[#182E23] mb-1">
                    {copy.labelEmail}
                  </label>
                  <input
                    id="new-faculty-email"
                    type="email"
                    value={formInput.email ?? ''}
                    onChange={(e) => setFormInput((prev) => ({ ...prev, email: e.target.value }))}
                    placeholder={copy.placeholderEmail}
                    className="w-full px-3 py-2 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="new-faculty-focus" className="block text-xs font-semibold text-[#182E23] mb-1">
                  {copy.labelFocus}
                </label>
                <input
                  id="new-faculty-focus"
                  type="text"
                  value={formInput.focus ?? ''}
                  onChange={(e) => setFormInput((prev) => ({ ...prev, focus: e.target.value }))}
                  placeholder={copy.placeholderFocus}
                  className="w-full px-3 py-2 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                />
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="submit"
                  className="px-5 py-2 text-sm font-semibold text-white bg-[#234232] hover:bg-[#182E23] rounded-md transition-colors cursor-pointer"
                >
                  {copy.submitTeacher}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsAddFormOpen(false);
                    setFormErrors({});
                  }}
                  className="px-4 py-2 text-sm font-medium text-[#354039] bg-white border border-[#DCD5C7] hover:bg-[#F5F2EB] rounded-md transition-colors cursor-pointer"
                >
                  {copy.cancelBtn}
                </button>
              </div>
            </form>
          )}

          {/* Faculty Grid */}
          {visibleFaculty.length === 0 ? (
            <div
              dir={dir}
              lang={lang}
              className={`mt-8 py-12 px-6 text-center border border-[#E5DFD2] rounded-lg bg-[#FAF8F4] ${
                lang === 'ar' ? 'font-arabic' : ''
              }`}
            >
              <p className="font-serif text-xl font-semibold text-[#182E23]">{copy.emptyTitle}</p>
              <p className="mt-1 text-sm text-[#5B665F]">{copy.emptySubtitle}</p>
              <button
                type="button"
                onClick={() => {
                  setDepartment('All');
                  setSearchQuery('');
                }}
                className="mt-4 px-4 py-2 text-sm font-medium text-white bg-[#234232] rounded-md hover:bg-[#182E23] cursor-pointer"
              >
                {copy.resetFilter}
              </button>
            </div>
          ) : (
            <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {visibleFaculty.map((member) => {
                const showEnName = Boolean(member.nameEn && member.nameEn !== member.name);
                const showArName = Boolean(member.nameAr && member.nameAr !== member.name);

                return (
                  <article
                    key={member.id}
                    className="p-6 border border-[#DCD5C7] rounded-lg bg-[#FAF8F4] flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <div
                          dir={dir}
                          lang={lang}
                          className={`text-xs font-medium tracking-wide text-[#8E6210] ${
                            lang === 'ar' ? 'font-arabic text-right' : ''
                          }`}
                        >
                          {member.departmentLabelByLang[lang]}
                        </div>
                        {member.isCustom && (
                          <button
                            type="button"
                            onClick={() => handleRemoveCustomTeacher(member.id)}
                            aria-label={`${copy.removeCustomBtn}: ${member.name}`}
                            className="inline-flex items-center gap-1 text-[11px] font-medium text-[#6B766F] hover:text-[#9E2A2B] cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>{copy.removeCustomBtn}</span>
                          </button>
                        )}
                      </div>

                      {member.isNameVacant ? (
                        <div className="mt-2">
                          <h3 className="font-serif text-lg font-medium text-[#6B766F] tracking-wide">
                            {copy.vacantNameText}
                          </h3>
                          <p
                            dir={dir}
                            lang={lang}
                            className={`mt-1 text-xs text-[#6B766F] ${
                              lang === 'ar' ? 'font-arabic text-right' : ''
                            }`}
                          >
                            {copy.vacantHint}
                          </p>
                        </div>
                      ) : (
                        <>
                          <h3 className="mt-1.5 font-serif text-xl font-semibold text-[#182E23]">
                            {member.name}
                          </h3>
                          {showEnName && (
                            <p className="mt-0.5 text-xs font-medium text-[#2D4C3B]">{member.nameEn}</p>
                          )}
                          {showArName && (
                            <p
                              dir="rtl"
                              lang="ar"
                              className="font-arabic text-sm font-semibold text-[#8E6210] text-left"
                            >
                              {member.nameAr}
                            </p>
                          )}
                        </>
                      )}

                      <p
                        dir={dir}
                        lang={lang}
                        className={`mt-1.5 text-sm font-medium text-[#2D4C3B] ${
                          lang === 'ar' ? 'font-arabic text-right' : ''
                        }`}
                      >
                        {member.roleByLang[lang]}
                      </p>

                      {/* Direct Parent Contact Links Below Profile Header */}
                      {(member.phone || member.email) && (
                        <div
                          dir={dir}
                          lang={lang}
                          className="mt-2.5 pt-2.5 border-t border-[#E5DFD2] flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs"
                        >
                          {member.phone && (
                            <a
                              href={`tel:${member.phone.replace(/[^\d+]/g, '')}`}
                              className="inline-flex items-center gap-1.5 font-medium text-[#234232] hover:text-[#8E6210] underline underline-offset-2 decoration-[#C5932A] transition-colors tabular-nums"
                            >
                              <Phone className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                              <span>{member.phone}</span>
                            </a>
                          )}
                          {member.email && (
                            <a
                              href={`mailto:${member.email}`}
                              className="inline-flex items-center gap-1.5 font-medium text-[#234232] hover:text-[#8E6210] underline underline-offset-2 decoration-[#C5932A] transition-colors break-all"
                            >
                              <Mail className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                              <span>{member.email}</span>
                            </a>
                          )}
                        </div>
                      )}

                      <p
                        dir={dir}
                        lang={lang}
                        className={`mt-3 text-sm leading-relaxed text-[#434E47] ${
                          lang === 'ar' ? 'font-arabic text-right' : ''
                        }`}
                      >
                        {member.focusByLang[lang]}
                      </p>
                    </div>

                    <div
                      dir={dir}
                      lang={lang}
                      className={`mt-5 pt-4 border-t border-[#E5DFD2] space-y-1.5 text-xs text-[#5B665F] ${
                        lang === 'ar' ? 'font-arabic text-right' : ''
                      }`}
                    >
                      <div className="font-medium text-[#354039]">{member.credentialsByLang[lang]}</div>
                      <div className="font-mono tabular-nums text-[#234232]">
                        {copy.officeHoursLabel}: {member.officeHoursByLang[lang]}
                      </div>
                      {member.isNameVacant && (
                        <div className="pt-1.5">
                          <button
                            type="button"
                            onClick={() => openAddFormForDepartment(member.department)}
                            className="inline-flex items-center gap-1 text-xs font-semibold text-[#234232] hover:text-[#8E6210] underline underline-offset-2 decoration-[#C5932A] cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>{copy.assignToWingBtn}</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>
      </section>
    </>
  );
}


import { useState } from 'react';
import { BookOpen } from 'lucide-react';

interface ResilientImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackTitle?: string;
}

export function ResilientImage({
  src,
  alt,
  className = '',
  fallbackTitle = 'FARMITAM Campus Archive',
}: ResilientImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center bg-[#EBE6DB] text-[#234232] p-6 border border-[#DCD5C7] ${className}`}
      >
        <BookOpen className="w-8 h-8 mb-2 opacity-60" aria-hidden="true" />
        <span className="font-serif text-base font-semibold text-center">{fallbackTitle}</span>
        <span className="text-xs text-[#556059] mt-1 text-center">{alt}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
}

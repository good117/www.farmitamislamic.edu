import { ArrowRight } from 'lucide-react';
import { useDescriptionLanguage } from '../context/LanguageContext';
import { INSTITUTION_FEATURES, INSTITUTION_CONTACT } from '../data/schoolData';
import { DescriptionTranslateBar } from './DescriptionTranslateBar';

const FEATURES_COPY = {
  bn: {
    intro: `${INSTITUTION_CONTACT.bnName}-এর শিক্ষা ব্যবস্থায় নৈতিকতা, ত্রিভাষিক দক্ষতা, নিয়মিত মূল্যায়ন পরীক্ষা ও প্রাক্টিক্যাল অনুশীলনের মাধ্যমে প্রতিটি শিক্ষার্থীকে আদর্শ ও যুগোপযোগী নাগরিক হিসেবে গড়ে তোলা হয়।`,
    curriculumLink: 'বিভাগসমূহ ও পাঠ্যসূচি দেখুন',
    admissionsLink: 'ভর্তির আবেদন করুন',
  },
  en: {
    intro: `Every learner at ${INSTITUTION_CONTACT.name} is mentored through moral formation, trilingual proficiency, five-stage testing, dual general-Islamic schooling, and practical labs to thrive in both faith and modern life.`,
    curriculumLink: 'Explore Curriculum & Divisions',
    admissionsLink: 'Start Admissions Application',
  },
  ar: {
    intro: `في ${INSTITUTION_CONTACT.arName}، يُربّى كل طالب على القيم الأخلاقية وإتقان اللغات الثلاث والتقييم الدوري والتعليم المزدوج والتطبيق العملي لإعداده للحياة الدينية والأكاديمية المعاصرة.`,
    curriculumLink: 'استكشف الأقسام والمناهج',
    admissionsLink: 'تقديم طلب الالتحاق',
  },
};

export function FeaturesSection() {
  const { lang, dir } = useDescriptionLanguage();
  const copy = FEATURES_COPY[lang];

  return (
    <section id="features" className="py-16 lg:py-20 border-b border-[#E5DFD2] bg-[#FAF8F4]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-6 border-b border-[#E5DFD2]">
          <div className="max-w-3xl">
            <p className="text-xs font-medium tracking-wide text-[#8E6210]">
              ০২. প্রতিষ্ঠানের বৈশিষ্ট্যসমূহ · Distinctive Features ·{' '}
              <span dir="rtl" lang="ar" className="font-arabic">
                المزايا والخصائص التعليمية
              </span>
            </p>
            <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-[#14231B] text-balance">
              আমাদের স্বতন্ত্র শিক্ষা বৈশিষ্ট্যসমূহ
            </h2>
            <p className="mt-1 text-sm font-medium text-[#2D4C3B]">
              Core Pillars of Student Formation ·{' '}
              <span dir="rtl" lang="ar" className="font-arabic font-semibold text-[#8E6210]">
                ركائز التميز التربوي والتعليمي
              </span>
            </p>
            <p
              dir={dir}
              lang={lang}
              className={`mt-2.5 text-[15px] leading-relaxed text-[#4B564F] ${
                lang === 'ar' ? 'font-arabic text-right' : ''
              }`}
            >
              {copy.intro}
            </p>
          </div>

          <div className="shrink-0">
            <DescriptionTranslateBar compact />
          </div>
        </div>

        {/* Balanced 5-Feature Editorial Grid: 2 Lead Pillars (lg:col-span-3 each) + 3 Foundation Pillars (lg:col-span-2 each) */}
        <div
          data-testid="features-grid"
          dir={dir}
          lang={lang}
          className={`mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6 ${
            lang === 'ar' ? 'font-arabic text-right' : ''
          }`}
        >
          {INSTITUTION_FEATURES.map((feature, index) => {
            const spanClass =
              index === 0
                ? 'md:col-span-2 lg:col-span-3'
                : index === 1
                  ? 'md:col-span-1 lg:col-span-3'
                  : 'md:col-span-1 lg:col-span-2';

            return (
              <article
                key={feature.id}
                data-testid="feature-card"
                className={`${spanClass} p-6 bg-white border border-[#DCD5C7] rounded-lg flex flex-col justify-between gap-4`}
              >
                <div>
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-medium text-[#8E6210] tabular-nums">
                    <span className="font-mono">{feature.indexByLang[lang]}</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-[#5B665F]">{feature.kickerByLang[lang]}</span>
                  </div>

                  <h3 className="mt-2 font-serif text-xl sm:text-2xl font-semibold leading-snug text-[#182E23] text-balance">
                    {feature.titleByLang[lang]}
                  </h3>

                  {lang === 'bn' ? (
                    <p className="mt-1 text-xs font-medium text-[#2D4C3B]" dir="ltr">
                      {feature.titleEn} ·{' '}
                      <span dir="rtl" lang="ar" className="font-arabic text-[#8E6210]">
                        {feature.titleAr}
                      </span>
                    </p>
                  ) : lang === 'en' ? (
                    <p className="mt-1 text-xs font-medium text-[#2D4C3B]" dir="ltr">
                      {feature.titleBn} ·{' '}
                      <span dir="rtl" lang="ar" className="font-arabic text-[#8E6210]">
                        {feature.titleAr}
                      </span>
                    </p>
                  ) : (
                    <p className="mt-1 text-xs font-medium text-[#2D4C3B]" dir="rtl">
                      <span>{feature.titleBn}</span> · <span dir="ltr">{feature.titleEn}</span>
                    </p>
                  )}

                  <p className="mt-3 text-sm sm:text-[15px] leading-relaxed text-[#434E47]">
                    {feature.descriptionByLang[lang]}
                  </p>
                </div>

                {feature.checkpointsByLang && (
                  <div className="pt-4 border-t border-[#EFECE4]">
                    <ul
                      aria-label={feature.titleByLang[lang]}
                      className={`grid grid-cols-1 divide-y divide-[#EFECE4] sm:divide-y-0 gap-2 text-xs text-[#182E23] ${
                        feature.checkpointsByLang[lang].length === 4
                          ? 'sm:grid-cols-2 lg:grid-cols-4'
                          : 'sm:grid-cols-5'
                      }`}
                    >
                      {feature.checkpointsByLang[lang].map((stage, stageIdx) => (
                        <li
                          key={stage}
                          className="pt-2 first:pt-0 sm:first:pt-1.5 sm:pt-1.5 sm:border-t sm:border-[#E5DFD2] font-medium tabular-nums"
                        >
                          <span className="inline-block sm:block font-mono text-[11px] text-[#8E6210] mr-2 sm:mr-0">
                            {String(stageIdx + 1).padStart(2, '0')}
                          </span>
                          <span className="sm:mt-0.5 inline sm:block">{stage}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </article>
            );
          })}
        </div>

        {/* Clean Action Links */}
        <div
          dir={dir}
          lang={lang}
          className={`mt-8 pt-6 border-t border-[#E5DFD2] flex flex-wrap items-center gap-6 text-sm font-semibold ${
            lang === 'ar' ? 'font-arabic' : ''
          }`}
        >
          <a
            href="#academics"
            className="inline-flex items-center gap-1.5 text-[#234232] hover:text-[#8E6210] underline underline-offset-4 decoration-[#C5932A] transition-colors whitespace-nowrap"
          >
            <span>{copy.curriculumLink}</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </a>
          <a
            href="#admissions"
            className="inline-flex items-center gap-1.5 text-[#8E6210] hover:text-[#182E23] underline underline-offset-4 decoration-[#C5932A] transition-colors whitespace-nowrap"
          >
            <span>{copy.admissionsLink}</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </a>
        </div>
      </div>
    </section>
  );
}

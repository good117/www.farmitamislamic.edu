import { useEffect, useState, type FormEvent } from 'react';
import { Check, Copy, Search } from 'lucide-react';
import { useDescriptionLanguage } from '../context/LanguageContext';
import { ACADEMIC_PROGRAMS, INSTITUTION_CONTACT, type DivisionId } from '../data/schoolData';
import {
  generateTrackingId,
  validateApplicationForm,
  type ApplicationErrors,
  type ApplicationFormValues,
  type ResidentialOption,
  type ShiftOption,
  type SubmittedApplication,
} from '../utils/admissions';

const STORAGE_KEY = 'farmitam_applications_v1';

interface AdmissionsSectionProps {
  prefillDivision?: DivisionId;
  prefillShift?: ShiftOption;
  prefillResidential?: ResidentialOption;
}

const INITIAL_FORM: ApplicationFormValues = {
  studentName: '',
  dateOfBirth: '',
  guardianName: '',
  guardianPhone: '',
  guardianEmail: '',
  division: 'general',
  shift: 'morning',
  residential: 'day-scholar',
  previousSchool: '',
  notes: '',
};

const ADMISSIONS_COPY = {
  bn: {
    intro:
      'ডিসেম্বর ২০২৬-এর মেধা যাচাই ও ভর্তি পরীক্ষার জন্য নির্ধারিত ট্র্যাকিং নম্বর পেতে নিচের অফিশিয়াল ভর্তি ফরমটি পূরণ করুন।',
    tabApply: 'আবেদন জমা দিন',
    tabLookup: 'আবেদনের অবস্থা',
    receiptEyebrow: 'নিবন্ধন সম্পন্ন হয়েছে',
    receiptTitle: 'অফিশিয়াল প্রার্থী ট্র্যাকিং রসিদ',
    receiptSubtitle:
      'ডিসেম্বর ২০২৬-এর মেধা মূল্যায়ন পরীক্ষা ও অভিভাবক যাচাইয়ের জন্য আপনার ট্র্যাকিং নম্বরটি সংরক্ষণ করুন।',
    trackingRef: 'ট্র্যাকিং রেফারেন্স নম্বর',
    copied: 'কপি হয়েছে',
    copyId: 'আইডি কপি করুন',
    studentLabel: 'শিক্ষার্থীর নাম',
    divisionLabel: 'নির্বাচিত বিভাগ',
    guardianInfoLabel: 'অভিভাবকের তথ্য',
    statusLabel: 'আবেদনের অবস্থা',
    statusPending: 'জমা হয়েছে — পর্যালোচনাধীন',
    statusScheduled: 'মূল্যায়ন নির্ধারিত',
    submitAnother: 'আরেকটি আবেদন জমা দিন',
    viewAllApps: 'আবেদনের তালিকা দেখুন',
    fieldStudent: 'শিক্ষার্থীর পূর্ণ নাম',
    phStudent: 'যেমন: আব্দুল্লাহ আল-মামুন',
    fieldDob: 'জন্ম তারিখ',
    fieldDivision: 'শিক্ষা বিভাগ',
    fieldShift: 'পছন্দের শিফট',
    shiftMorning: 'প্রভাতী শাখা',
    shiftDay: 'দিবা শাখা',
    shiftMorningLab: 'প্রভাতি + ল্যাব শাখা',
    fieldResidency: 'আবাসন ধরন',
    resDayScholar: 'অনাবাসিক',
    resHostel: 'আবাসিক হোস্টেল',
    fieldGuardian: 'পিতা/মাতা বা অভিভাবকের নাম',
    phGuardian: 'পূর্ণ নাম লিখুন',
    fieldPhone: 'অভিভাবকের মোবাইল নম্বর',
    fieldEmail: 'অভিভাবকের ইমেইল',
    fieldPrevSchool: 'পূর্ববর্তী স্কুল / মাদ্রাসা',
    phPrevSchool: 'প্রতিষ্ঠানের নাম অথবা "প্রথমবার ভর্তি"',
    fieldNotes: 'হিফজ বা বৃত্তি সংক্রান্ত তথ্য (ঐচ্ছিক)',
    phNotes: 'মুখস্থকৃত পারা সংখ্যা বা পূর্বের মেধা সনদ',
    submitBtn: 'ভর্তির আবেদন জমা দিন',
    checklistItems: [
      'আবেদন জমার পর প্রাপ্ত ট্র্যাকিং রসিদের প্রিন্ট কপি।',
      'শিক্ষার্থীর জন্ম নিবন্ধন সনদ ও দুই কপি পাসপোর্ট সাইজের ছবি।',
      'পূর্ববর্তী প্রতিষ্ঠানের ছাড়পত্র বা নম্বরপত্র (জেনারেল ও ক্যাডেট বিভাগের জন্য)।',
      '৫০% হিফজুল কুরআন বৃত্তির জন্য হিফজ সনদ অথবা তিলাওয়াত যাচাই।',
    ],
    registrarOffice: 'রেজিস্ট্রার ও ভর্তি দপ্তর',
    contactPrefix: 'যোগাযোগ',
    lookupPlaceholder: 'ট্র্যাকিং আইডি বা শিক্ষার্থীর নাম লিখুন...',
    lookupHint: 'তাৎক্ষণিক যাচাইয়ের জন্য আপনার ব্রাউজারে আবেদনসমূহ সংরক্ষিত থাকে।',
    emptyNone: 'এই সেশনে এখনো কোনো আবেদন জমা দেওয়া হয়নি',
    emptySearch: 'আপনার অনুসন্ধানের সাথে কোনো আবেদন মেলেনি',
    emptyNoneHint: 'প্রার্থীর নাম নিবন্ধন করতে ও ট্র্যাকিং আইডি পেতে "আবেদন জমা দিন" ট্যাবে যান।',
    emptySearchHint: 'পূর্ণ FISC-2026 ট্র্যাকিং নম্বর দিয়ে পুনরায় অনুসন্ধান করুন।',
    openFormBtn: 'ভর্তি আবেদন ফরম খুলুন',
    thTracking: 'ট্র্যাকিং আইডি',
    thCandidate: 'প্রার্থীর তথ্য',
    thDivision: 'বিভাগ',
    thSubmitted: 'জমার তারিখ',
    thStatus: 'অবস্থা',
    thAction: 'ব্যবস্থা',
    guardianPrefix: 'অভিভাবক',
    withdrawBtn: 'প্রত্যাহার করুন',
  },
  en: {
    intro:
      'Complete the official candidate registration form below to receive a verified tracking number for the December 2026 placement & entrance assessments.',
    tabApply: 'Submit Application',
    tabLookup: 'Application Lookup',
    receiptEyebrow: 'Registration Recorded',
    receiptTitle: 'Official Candidate Tracking Receipt',
    receiptSubtitle:
      'Retain your tracking reference for December 2026 placement tests and guardian verification.',
    trackingRef: 'Tracking Reference',
    copied: 'Copied',
    copyId: 'Copy ID',
    studentLabel: 'Student',
    divisionLabel: 'Division',
    guardianInfoLabel: 'Guardian',
    statusLabel: 'Status',
    statusPending: 'Submitted — Under Review',
    statusScheduled: 'Assessment Scheduled',
    submitAnother: 'Submit Another Application',
    viewAllApps: 'View Application Registry',
    fieldStudent: 'Student Full Name',
    phStudent: 'e.g. Abdullah Al-Mamun',
    fieldDob: 'Date of Birth',
    fieldDivision: 'Academic Division',
    fieldShift: 'Preferred Shift',
    shiftMorning: 'Morning Shift',
    shiftDay: 'Day Shift',
    shiftMorningLab: 'Morning + Lab Shift',
    fieldResidency: 'Residency Mode',
    resDayScholar: 'Day Scholar',
    resHostel: 'Residential Hostel',
    fieldGuardian: 'Parent / Guardian Name',
    phGuardian: 'Full legal name',
    fieldPhone: 'Guardian Mobile Phone',
    fieldEmail: 'Guardian Email',
    fieldPrevSchool: 'Previous School / Madrasa',
    phPrevSchool: 'Institution name or "First Time Enrollment"',
    fieldNotes: 'Hifz or Scholarship Notes (Optional)',
    phNotes: 'Para completed or prior merit credentials',
    submitBtn: 'Submit Admissions Application',
    checklistItems: [
      'Printed copy of generated Tracking Receipt upon form submission.',
      'Student Birth Registration Certificate & two passport-size photographs.',
      'Previous Academic Transcript / Transfer Letter (General & Cadet wings).',
      'Hifz verification certificate for 50% Hifzul Quran Merit Waiver eligibility.',
    ],
    registrarOffice: 'Registrar & Admissions Office',
    contactPrefix: 'Tel',
    lookupPlaceholder: 'Search by tracking ID or student name...',
    lookupHint: 'Applications submitted in this browser are saved locally for instant status lookup.',
    emptyNone: 'No applications submitted yet in this session',
    emptySearch: 'No matching applications found',
    emptyNoneHint: 'Switch to Submit Application to register a candidate and generate a Tracking ID.',
    emptySearchHint: 'Try searching by full FISC-2026 tracking ID.',
    openFormBtn: 'Open Application Form',
    thTracking: 'Tracking ID',
    thCandidate: 'Candidate',
    thDivision: 'Division',
    thSubmitted: 'Submitted',
    thStatus: 'Status',
    thAction: 'Action',
    guardianPrefix: 'Guardian',
    withdrawBtn: 'Withdraw',
  },
  ar: {
    intro:
      'يرجى تعبئة نموذج تسجيل الطلب الرسمي أدناه للحصول على رقم تتبع معتمد لاختبارات القبول وتحديد المستوى في ديسمبر ٢٠٢٦.',
    tabApply: 'تقديم طلب',
    tabLookup: 'متابعة الطلبات',
    receiptEyebrow: 'تم تسجيل الطلب بنجاح',
    receiptTitle: 'إيصال تتبع الطلب الرسمي',
    receiptSubtitle: 'يرجى الاحتفاظ برقم التتبع لمواعيد اختبارات القبول والتحقق في ديسمبر ٢٠٢٦.',
    trackingRef: 'رقم التتبع المرجعي',
    copied: 'تم النسخ',
    copyId: 'نسخ الرقم',
    studentLabel: 'اسم الطالب',
    divisionLabel: 'القسم المختار',
    guardianInfoLabel: 'بيانات ولي الأمر',
    statusLabel: 'حالة الطلب',
    statusPending: 'تم التقديم — قيد المراجعة',
    statusScheduled: 'تم تحديد موعد التقييم',
    submitAnother: 'تقديم طلب آخر',
    viewAllApps: 'عرض سجل الطلبات',
    fieldStudent: 'الاسم الكامل للطالب',
    phStudent: 'مثال: عبد الله المأمون',
    fieldDob: 'تاريخ الميلاد',
    fieldDivision: 'القسم الدراسي',
    fieldShift: 'الفترة المفضلة',
    shiftMorning: 'الفترة الصباحية',
    shiftDay: 'الفترة المسائية',
    shiftMorningLab: 'الصباحية + المختبر',
    fieldResidency: 'نظام السكن',
    resDayScholar: 'طالب نهاري',
    resHostel: 'سكن داخلي',
    fieldGuardian: 'اسم ولي الأمر',
    phGuardian: 'الاسم القانوني الكامل',
    fieldPhone: 'رقم جوال ولي الأمر',
    fieldEmail: 'البريد الإلكتروني لولي الأمر',
    fieldPrevSchool: 'المدرسة أو المعهد السابق',
    phPrevSchool: 'اسم المؤسسة أو "التحاق لأول مرة"',
    fieldNotes: 'ملاحظات الحفظ أو المنحة (اختياري)',
    phNotes: 'عدد الأجزاء المحفوظة أو شهادات التفوق',
    submitBtn: 'إرسال طلب الالتحاق',
    checklistItems: [
      'نسخة مطبوعة من إيصال التتبع بعد إرسال الطلب.',
      'شهادة ميلاد الطالب وصورتان شخصيتان بحجم جواز السفر.',
      'كشف الدرجات أو شهادة الانتقال السابقة (للقسم العام والكاديت).',
      'شهادة حفظ أو تقييم التلاوة لاستحقاق منحة تحفيظ القرآن ٥٠٪.',
    ],
    registrarOffice: 'مكتب القبول والتسجيل',
    contactPrefix: 'تواصل',
    lookupPlaceholder: 'ابحث برقم التتبع أو اسم الطالب...',
    lookupHint: 'يتم حفظ الطلبات المقدمة في هذا المتصفح محلياً لسرعة التحقق والمتابعة.',
    emptyNone: 'لم يتم تقديم أي طلبات في هذه الجلسة بعد',
    emptySearch: 'لا توجد طلبات مطابقة لبحثك',
    emptyNoneHint: 'انتقل إلى تبويب "تقديم طلب" لتسجيل طالب والحصول على رقم تتبع.',
    emptySearchHint: 'جرب البحث برقم التتبع الكامل FISC-2026.',
    openFormBtn: 'فتح نموذج التقديم',
    thTracking: 'رقم التتبع',
    thCandidate: 'الطالب',
    thDivision: 'القسم',
    thSubmitted: 'تاريخ التقديم',
    thStatus: 'الحالة',
    thAction: 'إجراء',
    guardianPrefix: 'ولي الأمر',
    withdrawBtn: 'سحب الطلب',
  },
};

export function AdmissionsSection({
  prefillDivision,
  prefillShift,
  prefillResidential,
}: AdmissionsSectionProps) {
  const { lang, dir } = useDescriptionLanguage();
  const copy = ADMISSIONS_COPY[lang];

  const [activeTab, setActiveTab] = useState<'apply' | 'lookup'>('apply');
  const [formValues, setFormValues] = useState<ApplicationFormValues>(INITIAL_FORM);
  const [errors, setErrors] = useState<ApplicationErrors>({});
  const [submittedReceipt, setSubmittedReceipt] = useState<SubmittedApplication | null>(null);
  const [applications, setApplications] = useState<SubmittedApplication[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });
  const [lookupQuery, setLookupQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    if (prefillDivision || prefillShift || prefillResidential) {
      setFormValues((prev) => ({
        ...prev,
        division: prefillDivision ?? prev.division,
        shift: prefillShift ?? prev.shift,
        residential: prefillResidential ?? prev.residential,
      }));
      setActiveTab('apply');
      setSubmittedReceipt(null);
    }
  }, [prefillDivision, prefillShift, prefillResidential]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(applications));
    } catch {
      // Ignore storage quota issues
    }
  }, [applications]);

  const updateField = <K extends keyof ApplicationFormValues>(field: K, value: ApplicationFormValues[K]) => {
    setFormValues((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validateApplicationForm(formValues, lang);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    const newRecord: SubmittedApplication = {
      ...formValues,
      studentName: formValues.studentName.trim(),
      guardianName: formValues.guardianName.trim(),
      guardianPhone: formValues.guardianPhone.trim(),
      guardianEmail: formValues.guardianEmail.trim(),
      previousSchool: formValues.previousSchool.trim(),
      notes: formValues.notes.trim(),
      trackingId: generateTrackingId(applications.length + 1, 2026),
      submittedAt: new Date().toISOString().slice(0, 10),
      status: 'Submitted — Under Review',
    };

    setApplications((prev) => [newRecord, ...prev]);
    setSubmittedReceipt(newRecord);
    setFormValues(INITIAL_FORM);
    setErrors({});
  };

  const handleRemoveApplication = (trackingId: string) => {
    setApplications((prev) => prev.filter((item) => item.trackingId !== trackingId));
  };

  const handleCopyTrackingId = async (trackingId: string) => {
    try {
      await navigator.clipboard.writeText(trackingId);
      setCopiedId(trackingId);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      // Clipboard fallback ignored
    }
  };

  const filteredApplications = applications.filter((app) => {
    const q = lookupQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      app.trackingId.toLowerCase().includes(q) ||
      app.studentName.toLowerCase().includes(q) ||
      app.guardianName.toLowerCase().includes(q)
    );
  });

  const getDivisionLabel = (id: DivisionId) => {
    const prog = ACADEMIC_PROGRAMS.find((p) => p.id === id);
    if (!prog) return id;
    return lang === 'bn' ? prog.bnTitle : lang === 'en' ? prog.title : prog.arTitle;
  };

  const getStatusLabel = (status: SubmittedApplication['status']) =>
    status === 'Submitted — Under Review' ? copy.statusPending : copy.statusScheduled;

  return (
    <section id="admissions" className="py-16 lg:py-20 bg-[#FAF8F4]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-[#E5DFD2]">
          <div className="max-w-2xl">
            <p className="text-xs font-medium tracking-wide text-[#8E6210]">
              ০৮. ভর্তি পোর্টাল · Admissions Portal ·{' '}
              <span dir="rtl" lang="ar" className="font-arabic">
                بوابة القبول والتسجيل
              </span>
            </p>
            <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-[#14231B]">
              শিক্ষার্থী ভর্তি আবেদন ও অবস্থা যাচাই
            </h2>
            <p className="mt-1 text-sm font-medium text-[#2D4C3B]">
              Student Enrollment &amp; Status Registry ·{' '}
              <span dir="rtl" lang="ar" className="font-arabic font-semibold text-[#8E6210]">
                تسجيل الطلاب ومتابعة الطلبات
              </span>
            </p>
            <p
              dir={dir}
              lang={lang}
              className={`mt-2.5 text-[15px] text-[#4B564F] ${lang === 'ar' ? 'font-arabic text-right' : ''}`}
            >
              {copy.intro}
            </p>
          </div>

          {/* Mode Tabs */}
          <div role="tablist" aria-label="ভর্তি পোর্টালের অংশসমূহ" className="flex items-center gap-1 p-1 bg-[#F5F2EB] rounded-lg shrink-0">
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'apply'}
              onClick={() => setActiveTab('apply')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'apply'
                  ? 'bg-white text-[#182E23] shadow-sm'
                  : 'text-[#4B564F] hover:text-[#182E23]'
              }`}
            >
              {copy.tabApply}
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'lookup'}
              onClick={() => setActiveTab('lookup')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap tabular-nums cursor-pointer ${
                activeTab === 'lookup'
                  ? 'bg-white text-[#182E23] shadow-sm'
                  : 'text-[#4B564F] hover:text-[#182E23]'
              }`}
            >
              {copy.tabLookup} ({applications.length})
            </button>
          </div>
        </div>

        {activeTab === 'apply' ? (
          submittedReceipt ? (
            <div
              data-testid="application-receipt"
              dir={dir}
              lang={lang}
              className={`mt-8 max-w-2xl mx-auto p-8 border border-[#234232]/30 rounded-lg bg-white ${
                lang === 'ar' ? 'font-arabic text-right' : ''
              }`}
            >
              <p className="text-xs font-medium tracking-wide text-[#234232]">{copy.receiptEyebrow}</p>
              <h3 className="mt-2 font-serif text-3xl font-semibold text-[#182E23]">{copy.receiptTitle}</h3>
              <p className="mt-0.5 text-xs font-medium text-[#2D4C3B]" dir="ltr">
                Official Candidate Tracking Receipt ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic text-[#8E6210]">
                  إيصال تتبع الطلب الرسمي
                </span>
              </p>
              <p className="mt-2 text-sm text-[#434E47]">{copy.receiptSubtitle}</p>

              <div className="mt-6 p-4 bg-white border border-[#DCD5C7] rounded-md flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="text-xs text-[#5B665F]">{copy.trackingRef}</div>
                  <div
                    dir="ltr"
                    data-testid="receipt-tracking-id"
                    className="font-mono text-2xl font-semibold text-[#182E23] tabular-nums"
                  >
                    {submittedReceipt.trackingId}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopyTrackingId(submittedReceipt.trackingId)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-[#DCD5C7] rounded-md bg-[#FAF8F4] hover:bg-[#EFECE4] text-[#182E23] cursor-pointer"
                >
                  {copiedId === submittedReceipt.trackingId ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#234232]" />
                      <span>{copy.copied}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>{copy.copyId}</span>
                    </>
                  )}
                </button>
              </div>

              <dl className="mt-6 divide-y divide-[#E5DFD2] text-sm">
                <div className="py-2.5 flex justify-between gap-4">
                  <dt className="text-[#5B665F]">{copy.studentLabel}</dt>
                  <dd className="font-medium text-[#182E23]">{submittedReceipt.studentName}</dd>
                </div>
                <div className="py-2.5 flex justify-between gap-4">
                  <dt className="text-[#5B665F]">{copy.divisionLabel}</dt>
                  <dd className="font-medium text-[#182E23]">{getDivisionLabel(submittedReceipt.division)}</dd>
                </div>
                <div className="py-2.5 flex justify-between gap-4">
                  <dt className="text-[#5B665F]">{copy.guardianInfoLabel}</dt>
                  <dd className="font-medium text-[#182E23]">
                    {submittedReceipt.guardianName} · {submittedReceipt.guardianPhone}
                  </dd>
                </div>
                <div className="py-2.5 flex justify-between gap-4">
                  <dt className="text-[#5B665F]">{copy.statusLabel}</dt>
                  <dd className="font-medium text-[#234232]">{getStatusLabel(submittedReceipt.status)}</dd>
                </div>
              </dl>

              <div className="mt-6 pt-5 border-t border-[#DCD5C7] flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={() => setSubmittedReceipt(null)}
                  className="px-4 py-2 text-sm font-medium text-white bg-[#234232] hover:bg-[#182E23] rounded-md cursor-pointer"
                >
                  {copy.submitAnother}
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('lookup')}
                  className="px-4 py-2 text-sm font-medium text-[#234232] bg-white border border-[#DCD5C7] hover:border-[#234232] rounded-md cursor-pointer"
                >
                  {copy.viewAllApps}
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
              <div
                dir={dir}
                lang={lang}
                className={`lg:col-span-8 space-y-6 ${lang === 'ar' ? 'font-arabic text-right' : ''}`}
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="studentName" className="block text-sm font-medium text-[#1A1F1C] mb-1.5">
                      {copy.fieldStudent} <span className="text-[#9A3412]">*</span>
                    </label>
                    <input
                      id="studentName"
                      type="text"
                      value={formValues.studentName}
                      onChange={(e) => updateField('studentName', e.target.value)}
                      placeholder={copy.phStudent}
                      aria-invalid={Boolean(errors.studentName)}
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                    />
                    {errors.studentName && (
                      <p role="alert" className="mt-1.5 text-xs text-[#9A3412]">
                        {errors.studentName}
                      </p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="dateOfBirth" className="block text-sm font-medium text-[#1A1F1C] mb-1.5">
                      {copy.fieldDob} <span className="text-[#9A3412]">*</span>
                    </label>
                    <input
                      id="dateOfBirth"
                      type="date"
                      value={formValues.dateOfBirth}
                      onChange={(e) => updateField('dateOfBirth', e.target.value)}
                      aria-invalid={Boolean(errors.dateOfBirth)}
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                    />
                    {errors.dateOfBirth && (
                      <p role="alert" className="mt-1.5 text-xs text-[#9A3412]">
                        {errors.dateOfBirth}
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                  <div>
                    <label htmlFor="division" className="block text-sm font-medium text-[#1A1F1C] mb-1.5">
                      {copy.fieldDivision}
                    </label>
                    <select
                      id="division"
                      value={formValues.division}
                      onChange={(e) => updateField('division', e.target.value as DivisionId)}
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                    >
                      {ACADEMIC_PROGRAMS.map((p) => (
                        <option key={p.id} value={p.id}>
                          {lang === 'bn' ? `${p.bnTitle} (${p.title})` : lang === 'en' ? p.title : p.arTitle}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label htmlFor="shift" className="block text-sm font-medium text-[#1A1F1C] mb-1.5">
                      {copy.fieldShift}
                    </label>
                    <select
                      id="shift"
                      value={formValues.shift}
                      onChange={(e) => updateField('shift', e.target.value as ShiftOption)}
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                    >
                      <option value="morning">{copy.shiftMorning}</option>
                      <option value="day">{copy.shiftDay}</option>
                      <option value="morning-lab">{copy.shiftMorningLab}</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="residential" className="block text-sm font-medium text-[#1A1F1C] mb-1.5">
                      {copy.fieldResidency}
                    </label>
                    <select
                      id="residential"
                      value={formValues.residential}
                      onChange={(e) => updateField('residential', e.target.value as ResidentialOption)}
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                    >
                      <option value="day-scholar">{copy.resDayScholar}</option>
                      <option value="hostel">{copy.resHostel}</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                  <div>
                    <label htmlFor="guardianName" className="block text-sm font-medium text-[#1A1F1C] mb-1.5">
                      {copy.fieldGuardian} <span className="text-[#9A3412]">*</span>
                    </label>
                    <input
                      id="guardianName"
                      type="text"
                      value={formValues.guardianName}
                      onChange={(e) => updateField('guardianName', e.target.value)}
                      placeholder={copy.phGuardian}
                      aria-invalid={Boolean(errors.guardianName)}
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                    />
                    {errors.guardianName && (
                      <p role="alert" className="mt-1.5 text-xs text-[#9A3412]">
                        {errors.guardianName}
                      </p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="guardianPhone" className="block text-sm font-medium text-[#1A1F1C] mb-1.5">
                      {copy.fieldPhone} <span className="text-[#9A3412]">*</span>
                    </label>
                    <input
                      id="guardianPhone"
                      type="tel"
                      value={formValues.guardianPhone}
                      onChange={(e) => updateField('guardianPhone', e.target.value)}
                      placeholder="018XXXXXXXX"
                      aria-invalid={Boolean(errors.guardianPhone)}
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                    />
                    {errors.guardianPhone && (
                      <p role="alert" className="mt-1.5 text-xs text-[#9A3412]">
                        {errors.guardianPhone}
                      </p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="guardianEmail" className="block text-sm font-medium text-[#1A1F1C] mb-1.5">
                      {copy.fieldEmail} <span className="text-[#9A3412]">*</span>
                    </label>
                    <input
                      id="guardianEmail"
                      type="email"
                      value={formValues.guardianEmail}
                      onChange={(e) => updateField('guardianEmail', e.target.value)}
                      placeholder="guardian@example.com"
                      aria-invalid={Boolean(errors.guardianEmail)}
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                    />
                    {errors.guardianEmail && (
                      <p role="alert" className="mt-1.5 text-xs text-[#9A3412]">
                        {errors.guardianEmail}
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="previousSchool" className="block text-sm font-medium text-[#1A1F1C] mb-1.5">
                      {copy.fieldPrevSchool} <span className="text-[#9A3412]">*</span>
                    </label>
                    <input
                      id="previousSchool"
                      type="text"
                      value={formValues.previousSchool}
                      onChange={(e) => updateField('previousSchool', e.target.value)}
                      placeholder={copy.phPrevSchool}
                      aria-invalid={Boolean(errors.previousSchool)}
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                    />
                    {errors.previousSchool && (
                      <p role="alert" className="mt-1.5 text-xs text-[#9A3412]">
                        {errors.previousSchool}
                      </p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="notes" className="block text-sm font-medium text-[#1A1F1C] mb-1.5">
                      {copy.fieldNotes}
                    </label>
                    <input
                      id="notes"
                      type="text"
                      value={formValues.notes}
                      onChange={(e) => updateField('notes', e.target.value)}
                      placeholder={copy.phNotes}
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                    />
                  </div>
                </div>

                <div className="pt-2 flex items-center gap-4">
                  <button
                    type="submit"
                    className="px-6 py-3 text-sm font-semibold text-white bg-[#234232] hover:bg-[#182E23] rounded-md transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#234232]"
                  >
                    {copy.submitBtn}
                  </button>
                </div>
              </div>

              {/* Admissions Document Checklist Sidebar */}
              <aside className="lg:col-span-4 bg-white border border-[#DCD5C7] rounded-lg p-6 space-y-5">
                <h3 className="font-serif text-2xl font-semibold text-[#182E23]">
                  প্রয়োজনীয় কাগজপত্র ও যাচাই তালিকা
                </h3>
                <p className="-mt-3 text-xs font-medium text-[#2D4C3B]">
                  Verification Checklist ·{' '}
                  <span dir="rtl" lang="ar" className="font-arabic text-[#8E6210]">
                    قائمة المستندات المطلوبة
                  </span>
                </p>
                <ol
                  dir={dir}
                  lang={lang}
                  className={`space-y-3 text-sm text-[#434E47] list-decimal list-inside ${
                    lang === 'ar' ? 'font-arabic text-right' : ''
                  }`}
                >
                  {copy.checklistItems.map((item, idx) => (
                    <li key={idx}>{item}</li>
                  ))}
                </ol>
                <div
                  dir={dir}
                  lang={lang}
                  className={`pt-4 border-t border-[#DCD5C7] text-xs text-[#5B665F] space-y-1 ${
                    lang === 'ar' ? 'font-arabic text-right' : ''
                  }`}
                >
                  <div className="font-semibold text-[#182E23]">{copy.registrarOffice}</div>
                  <div>{INSTITUTION_CONTACT.addressByLang[lang]}</div>
                  <div className="font-mono tabular-nums" dir="ltr">
                    {copy.contactPrefix}: {INSTITUTION_CONTACT.phone} · {INSTITUTION_CONTACT.hoursByLang[lang]}
                  </div>
                  <div className="font-mono" dir="ltr">
                    Gmail:{' '}
                    <a
                      href={`mailto:${INSTITUTION_CONTACT.email}`}
                      className="text-[#234232] underline underline-offset-2 hover:text-[#8E6210]"
                    >
                      {INSTITUTION_CONTACT.email}
                    </a>
                  </div>
                </div>
              </aside>
            </form>
          )
        ) : (
          <div
            dir={dir}
            lang={lang}
            className={`mt-8 space-y-6 ${lang === 'ar' ? 'font-arabic text-right' : ''}`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="relative sm:w-80">
                <label htmlFor="lookup-search" className="sr-only">
                  {copy.lookupPlaceholder}
                </label>
                <Search
                  className="w-4 h-4 text-[#6B766F] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                  aria-hidden="true"
                />
                <input
                  id="lookup-search"
                  type="search"
                  value={lookupQuery}
                  onChange={(e) => setLookupQuery(e.target.value)}
                  placeholder={copy.lookupPlaceholder}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] placeholder:text-[#6B766F] focus:outline-2 focus:outline-[#234232]"
                />
              </div>
              <p className="text-xs text-[#5B665F]">{copy.lookupHint}</p>
            </div>

            {filteredApplications.length === 0 ? (
              <div className="p-10 text-center border border-[#E5DFD2] rounded-lg bg-white">
                <p className="font-serif text-xl font-semibold text-[#182E23]">
                  {applications.length === 0 ? copy.emptyNone : copy.emptySearch}
                </p>
                <p className="mt-1 text-sm text-[#5B665F]">
                  {applications.length === 0 ? copy.emptyNoneHint : copy.emptySearchHint}
                </p>
                <button
                  type="button"
                  onClick={() => setActiveTab('apply')}
                  className="mt-4 px-4 py-2 text-sm font-medium text-white bg-[#234232] hover:bg-[#182E23] rounded-md cursor-pointer"
                >
                  {copy.openFormBtn}
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto border border-[#E5DFD2] rounded-lg bg-white">
                <table className={`w-full border-collapse ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                  <thead>
                    <tr className="bg-[#FAF8F4] border-b border-[#E5DFD2] text-xs font-medium text-[#5B665F]">
                      <th className="py-3 px-4 font-medium">{copy.thTracking}</th>
                      <th className="py-3 px-4 font-medium">{copy.thCandidate}</th>
                      <th className="py-3 px-4 font-medium">{copy.thDivision}</th>
                      <th className="py-3 px-4 font-medium">{copy.thSubmitted}</th>
                      <th className="py-3 px-4 font-medium">{copy.thStatus}</th>
                      <th className={`py-3 px-4 font-medium ${lang === 'ar' ? 'text-left' : 'text-right'}`}>
                        {copy.thAction}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EFECE4] text-sm">
                    {filteredApplications.map((app) => (
                      <tr key={app.trackingId} className="hover:bg-[#FAF8F4]/70">
                        <td
                          dir="ltr"
                          className="py-3 px-4 font-mono font-medium text-[#182E23] tabular-nums whitespace-nowrap"
                        >
                          {app.trackingId}
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-medium text-[#1A1F1C]">{app.studentName}</div>
                          <div className="text-xs text-[#5B665F]">
                            {copy.guardianPrefix}: {app.guardianName}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-[#434E47]">{getDivisionLabel(app.division)}</td>
                        <td
                          dir="ltr"
                          className="py-3 px-4 font-mono text-xs text-[#5B665F] tabular-nums whitespace-nowrap"
                        >
                          {app.submittedAt}
                        </td>
                        <td className="py-3 px-4 font-medium text-[#234232] whitespace-nowrap">
                          {getStatusLabel(app.status)}
                        </td>
                        <td className={`py-3 px-4 whitespace-nowrap ${lang === 'ar' ? 'text-left' : 'text-right'}`}>
                          <button
                            type="button"
                            onClick={() => handleRemoveApplication(app.trackingId)}
                            aria-label={`${app.trackingId} ${copy.withdrawBtn}`}
                            className="text-xs font-medium text-[#9A3412] hover:underline cursor-pointer"
                          >
                            {copy.withdrawBtn}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}

import { useDescriptionLanguage } from '../context/LanguageContext';
import { INSTITUTION_CONTACT } from '../data/schoolData';
import { ResilientImage } from './ResilientImage';

const FOOTER_COPY = {
  bn: {
    description:
      'গাজীপুরের কোনাবাড়ীতে জেনারেল (প্লে থেকে দশম), ক্যাডেট (দুই বছর মেয়াদী প্রোগ্রাম), নূরানী (কায়েদা, আমপারা ও কুরআন) এবং হিফজুল কুরআন বিভাগের সমন্বিত শিক্ষা প্রতিষ্ঠান।',
    linksTitle: 'গুরুত্বপূর্ণ লিংক',
    links: [
      { href: '#academics', label: 'একাডেমিক বিভাগসমূহ' },
      { href: '#features', label: 'প্রতিষ্ঠানের বৈশিষ্ট্যসমূহ' },
      { href: '#history', label: 'ইতিহাস, লক্ষ্য ও উদ্দেশ্য' },
      { href: '#faculty', label: 'শিক্ষকমণ্ডলীর পরিচিতি' },
      { href: '#notices', label: 'অফিশিয়াল নোটিশ বোর্ড' },
      { href: '#testimonials', label: 'অভিভাবক ও শিক্ষার্থীদের মতামত' },
      { href: '#admissions', label: 'অনলাইন ভর্তি পোর্টাল' },
    ],
    campusTitle: 'ক্যাম্পাস ও যোগাযোগ',
    contactLabel: 'যোগাযোগ',
    mobileLabel: 'মোবাইল',
    copyright: `© ২০২৬ ${INSTITUTION_CONTACT.bnName} (${INSTITUTION_CONTACT.name})। সর্বস্বত্ব সংরক্ষিত।`,
  },
  en: {
    description:
      'Integrated Islamic and modern scholarship in Konabari, Gazipur across General (Play to Ten), Cadet (Two Years Program), Noorani (Quyeda, Ampar and Quran), and Hifzul Quran.',
    linksTitle: 'Important Links',
    links: [
      { href: '#academics', label: 'Academic Divisions' },
      { href: '#features', label: 'Distinctive Features' },
      { href: '#history', label: 'History, Vision & Mission' },
      { href: '#faculty', label: 'Scholars & Faculty' },
      { href: '#notices', label: 'Official Notice Board' },
      { href: '#testimonials', label: 'Parent & Student Testimonials' },
      { href: '#admissions', label: 'Online Admissions Portal' },
    ],
    campusTitle: 'Campus & Contact',
    contactLabel: 'Contact',
    mobileLabel: 'Phone',
    copyright: `© 2026 ${INSTITUTION_CONTACT.name}. All rights reserved.`,
  },
  ar: {
    description:
      'مؤسسة تعليمية متكاملة في كوناباري بغازي بور تجمع بين القسم العام (من الروضة إلى العاشر) وبرنامج الكاديت والنوراني وتحفيظ القرآن الكريم.',
    linksTitle: 'روابط مهمة',
    links: [
      { href: '#academics', label: 'الأقسام الدراسية' },
      { href: '#features', label: 'المزايا التعليمية' },
      { href: '#history', label: 'التاريخ والرؤية والرسالة' },
      { href: '#faculty', label: 'هيئة التدريس' },
      { href: '#notices', label: 'لوحة الإعلانات الرسمية' },
      { href: '#testimonials', label: 'آراء أولياء الأمور والطلاب' },
      { href: '#admissions', label: 'بوابة القبول والتسجيل' },
    ],
    campusTitle: 'الحرم الدراسي والتواصل',
    contactLabel: 'تواصل',
    mobileLabel: 'جوال',
    copyright: `© ٢٠٢٦ ${INSTITUTION_CONTACT.arName} (${INSTITUTION_CONTACT.name}). جميع الحقوق محفوظة.`,
  },
};

export function Footer() {
  const { lang, dir } = useDescriptionLanguage();
  const copy = FOOTER_COPY[lang];

  return (
    <footer className="bg-[#182E23] text-[#E6E2D8] border-t border-[#234232]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-12 lg:py-14">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          <div className="md:col-span-5 flex items-start gap-4">
            <ResilientImage
              src="/assets/aistudio/download_8c285805.png"
              alt="ফারমিটম ইসলামিক স্কুল এন্ড কলেজ মনোগ্রাম"
              className="w-14 h-14 object-contain bg-white rounded-full p-1 shrink-0"
              fallbackTitle="FISC"
            />
            <div>
              <div className="font-serif text-xl font-semibold text-white">
                {INSTITUTION_CONTACT.bnName}
              </div>
              <div className="text-xs font-medium text-[#E6E2D8] mt-0.5">
                {INSTITUTION_CONTACT.name} ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic text-[#D8B45A]">
                  {INSTITUTION_CONTACT.arName}
                </span>
              </div>
              <p className="mt-1.5 text-xs tracking-wide text-[#D8B45A]">
                জ্ঞানের সাথে ঈমান · Knowledge With Faith ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic">
                  العلم مع الإيمان
                </span>{' '}
                · {INSTITUTION_CONTACT.foundedYearByLang[lang]}
              </p>
              <p
                dir={dir}
                lang={lang}
                className={`mt-3 text-sm leading-relaxed text-[#C6CEC8] max-w-sm ${
                  lang === 'ar' ? 'font-arabic text-right' : ''
                }`}
              >
                {copy.description}
              </p>
            </div>
          </div>

          <div
            dir={dir}
            lang={lang}
            className={`md:col-span-3 space-y-2 text-sm ${lang === 'ar' ? 'font-arabic text-right' : ''}`}
          >
            <div className="text-xs tracking-wide text-[#D8B45A] font-medium">{copy.linksTitle}</div>
            <ul className="space-y-1.5 text-[#C6CEC8]">
              {copy.links.map((item) => (
                <li key={item.href}>
                  <a href={item.href} className="hover:text-white transition-colors">
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div
            dir={dir}
            lang={lang}
            className={`md:col-span-4 space-y-2 text-sm ${lang === 'ar' ? 'font-arabic text-right' : ''}`}
          >
            <div className="text-xs tracking-wide text-[#D8B45A] font-medium">{copy.campusTitle}</div>
            <p className="text-[#C6CEC8]">{INSTITUTION_CONTACT.addressByLang[lang]}</p>
            <p className="text-[#C6CEC8] font-mono text-xs tabular-nums" dir="ltr">
              {copy.contactLabel}: {INSTITUTION_CONTACT.phone} · {INSTITUTION_CONTACT.hoursByLang[lang]}
            </p>
            <p className="text-[#C6CEC8] font-mono text-xs" dir="ltr">
              Gmail:{' '}
              <a
                href={`mailto:${INSTITUTION_CONTACT.email}`}
                className="hover:text-white underline underline-offset-2 transition-colors"
              >
                {INSTITUTION_CONTACT.email}
              </a>
            </p>
          </div>
        </div>

        <div
          dir={dir}
          lang={lang}
          className={`mt-10 pt-6 border-t border-[#2D4C3B] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#A9B5AD] ${
            lang === 'ar' ? 'font-arabic' : ''
          }`}
        >
          <p>{copy.copyright}</p>
          <p>
            {INSTITUTION_CONTACT.addressByLang[lang]} · {copy.mobileLabel}: {INSTITUTION_CONTACT.phone}
          </p>
        </div>
      </div>
    </footer>
  );
}

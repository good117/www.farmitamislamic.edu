import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { ResilientImage } from './ResilientImage';

interface HeaderProps {
  onApplyClick: () => void;
}

const NAV_LINKS = [
  { href: '#academics', label: 'বিভাগসমূহ' },
  { href: '#history', label: 'ইতিহাস' },
  { href: '#faculty', label: 'শিক্ষকমণ্ডলী' },
  { href: '#notices', label: 'নোটিশ' },
  { href: '#admissions', label: 'ভর্তি' },
];

export function Header({ onApplyClick }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleMobileNav = (href: string) => {
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F4]/95 backdrop-blur-sm border-b border-[#E5DFD2]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <a
          href="#top"
          className="flex items-center gap-2.5 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#234232]"
        >
          <ResilientImage
            src="/assets/aistudio/download_8c285805.png"
            alt="FARMITAM Islamic School & College Crest"
            className="w-9 h-9 object-contain shrink-0"
            fallbackTitle="FISC"
          />
          <span className="font-serif text-xl font-bold tracking-tight text-[#182E23] whitespace-nowrap shrink-0">
            FARMITAM
          </span>
        </a>

        {/* Zone 2: 5 concise single-line nav links */}
        <nav aria-label="মূল নেভিগেশন" className="hidden md:flex items-center gap-7">
          {NAV_LINKS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-[#3F4A43] hover:text-[#182E23] hover:underline underline-offset-4 decoration-[#C5932A] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#234232]"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onApplyClick}
            className="px-4 py-2 text-sm font-medium text-white bg-[#234232] hover:bg-[#182E23] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#234232]"
          >
            আবেদন করুন
          </button>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-label={mobileMenuOpen ? 'নেভিগেশন মেনু বন্ধ করুন' : 'নেভিগেশন মেনু খুলুন'}
            aria-expanded={mobileMenuOpen}
            className="md:hidden inline-flex items-center justify-center w-11 h-11 rounded-md text-[#182E23] hover:bg-[#EFECE4] transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#234232]"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <nav
          aria-label="Mobile navigation"
          className="md:hidden border-t border-[#E5DFD2] bg-[#FAF8F4] px-4 py-3 space-y-1"
        >
          {NAV_LINKS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={(e) => {
                e.preventDefault();
                handleMobileNav(item.href);
              }}
              className="block px-3 py-2.5 text-sm font-medium text-[#2A332D] hover:bg-[#EFECE4] rounded-md"
            >
              {item.label}
            </a>
          ))}
        </nav>
      )}
    </header>
  );
}

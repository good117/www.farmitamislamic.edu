import { useState } from 'react';
import { useDescriptionLanguage } from '../context/LanguageContext';
import { ACADEMIC_PROGRAMS, type DivisionId } from '../data/schoolData';
import {
  calculateTuitionBreakdown,
  FEE_PLANS,
  formatCurrencyBDT,
  getDivisionWeeklyModes,
  getWeeklyInstructionSchedule,
  resolveFeePlan,
  SCHOLARSHIP_PERCENT_OPTIONS,
  toLocaleDigits,
  type FeePlanId,
  type ResidentialOption,
  type ScholarshipPercent,
  type ScholarshipScope,
  type ShiftOption,
} from '../utils/admissions';

interface AcademicsSectionProps {
  activeDivision?: DivisionId;
  onChangeDivision?: (division: DivisionId) => void;
  onSelectDivisionForApplication: (division: DivisionId, shift: ShiftOption, residential: ResidentialOption) => void;
}

const ACADEMICS_COPY = {
  bn: {
    intro:
      'যেকোনো একটি শিক্ষা বিভাগ নির্বাচন করে তার সাপ্তাহিক পাঠ্যসূচির বিবরণ দেখুন এবং শাখাভিত্তিক বেতন কাঠামো ও ৫%–৫০% বৃত্তি অনুযায়ী মাসিক ও এককালীন হিসাব যাচাই করুন।',
    annualIntake: 'বাৎসরিক আসন সংখ্যা',
    seatsSuffix: 'টি আসন',
    facultyRatio: 'শিক্ষক-শিক্ষার্থী অনুপাত',
    weeklyInstruction: 'সাপ্তাহিক পাঠদান',
    hoursSuffix: 'ঘণ্টা',
    thCode: 'কোড',
    thSubject: 'মূল বিষয় ও বিবরণ',
    thStream: 'শিক্ষা ধারা',
    thHours: 'ঘণ্টা / সপ্তাহ',
    estimatorNote: 'এর তাৎক্ষণিক বেতন হিসাব',
    planSelectorLabel: 'শাখা ও প্যাকেজ নির্বাচন করুন',
    scholarshipLabel: 'বৃত্তি সুবিধা (৫% – ৫০%)',
    scholarshipNone: 'সাধারণ ফি (০% — বৃত্তি ব্যতীত)',
    scholarshipScopeLabel: 'বৃত্তি প্রযোজ্য ক্ষেত্র',
    scopeMonthly: 'মাসিক বেতন',
    scopeOneTime: 'এককালীন ভর্তি',
    scopeBoth: 'উভয় ক্ষেত্র',
    feeAdmission: 'এককালীন ভর্তি ও ল্যাব নিবন্ধন ফি',
    feeDress: 'পোশাক ও কেস',
    feeOneTimeWaiver: 'এককালীন ভর্তি বৃত্তি মওকুফ',
    feeNetOneTime: 'নিট এককালীন (ভর্তির সময়)',
    feeMonthlyTuition: 'নিয়মিত মাসিক বেতন',
    feeWeeklyTest: 'সাপ্তাহিক ও মাসিক টেস্ট',
    feeHostelRent: 'আবাসিক ফি',
    feeFood: 'খাবার',
    feeClub: 'ক্লাব সুবিধা',
    feeLab: 'ল্যাব ফি',
    feeMonthlyWaiver: 'মাসিক বেতন বৃত্তি মওকুফ',
    feeNet: 'নিট মাসিক প্রদেয়',
    feeAnnual: 'প্রথম বছরের সম্ভাব্য মোট খরচ (এককালীন + ১২ মাস)',
    applyPrefix: '-এ আবেদন করুন',
    weeklyScheduleHeading: 'শিফট ও আবাসিক অনুযায়ী সাপ্তাহিক পাঠদান ও টেস্ট সূচি',
    testRowCode: 'TST-WK',
    testRowSubject: 'সাপ্তাহিক মূল্যায়ন ও শ্রেণি টেস্ট',
    testRowStream: 'সাপ্তাহিক পরীক্ষা',
    feeMatrixEyebrow: 'বেতন কাঠামো · Official Fee Schedule · هيكل الرسوم الدراسية',
    feeMatrixHeading: 'শাখা ও আবাসনভিত্তিক সম্পূর্ণ বেতন কাঠামো',
    feeMatrixSubtitle:
      'যেকোনো শাখার নামে ক্লিক করে উপরের ক্যালকুলেটরে তার এককালীন ও মাসিক হিসাব যাচাই করুন।',
    thFeeItem: 'ফি-এর খাত ও বিবরণ',
    rowTotalOneTime: 'মোট এককালীন (ভর্তি + পোশাক ও কেস)',
    rowTotalMonthly: 'মোট মাসিক বেতন',
    scholarshipNoteTitle: 'বৃত্তি ও আর্থিক সহায়তা নীতিমালা:',
    scholarshipNoteBody:
      'আর্থিক অস্বচ্ছলতায় ও মেধার মূল্যায়নে মাসিক অথবা এককালীন ফিতে ৫% থেকে ৫০% পর্যন্ত বৃত্তি প্রদান করা হয়।',
    currencySuffix: 'টাকা',
  },
  en: {
    intro:
      'Select an academic wing to inspect its weekly syllabus allocation and calculate one-time and monthly tuition across all five branch plans with 5%–50% scholarships.',
    annualIntake: 'Annual Intake',
    seatsSuffix: 'Seats',
    facultyRatio: 'Faculty Ratio',
    weeklyInstruction: 'Weekly Instruction',
    hoursSuffix: 'Hours',
    thCode: 'Code',
    thSubject: 'Core Subject & Description',
    thStream: 'Academic Stream',
    thHours: 'Hrs / Wk',
    estimatorNote: 'Live fee calculation',
    planSelectorLabel: 'Select Branch & Fee Plan',
    scholarshipLabel: 'Scholarship Rate (5% – 50%)',
    scholarshipNone: 'Standard Tuition (0% — No Waiver)',
    scholarshipScopeLabel: 'Apply Scholarship To',
    scopeMonthly: 'Monthly Tuition',
    scopeOneTime: 'One-Time Admission',
    scopeBoth: 'Both',
    feeAdmission: 'One-Time Admission & Lab Registration',
    feeDress: 'Uniform & Case',
    feeOneTimeWaiver: 'One-Time Admission Waiver',
    feeNetOneTime: 'Net One-Time Total (At Admission)',
    feeMonthlyTuition: 'Regular Monthly Tuition',
    feeWeeklyTest: 'Weekly & Monthly Tests',
    feeHostelRent: 'Residential Hostel Fee',
    feeFood: 'Dining & Meals',
    feeClub: 'Club Facilities',
    feeLab: 'Laboratory Fee',
    feeMonthlyWaiver: 'Monthly Tuition Waiver',
    feeNet: 'Net Monthly Payable',
    feeAnnual: 'Estimated First-Year Total (One-Time + 12 Months)',
    applyPrefix: 'Apply for ',
    weeklyScheduleHeading: 'Weekly Instruction & Test Hours by Shift / Residency',
    testRowCode: 'TST-WK',
    testRowSubject: 'Weekly Assessment & Progress Test',
    testRowStream: 'Weekly Evaluation',
    feeMatrixEyebrow: 'Fee Structure · বেতন কাঠামো · هيكل الرسوم الدراسية',
    feeMatrixHeading: 'Official Fee Schedule Across All Five Plans',
    feeMatrixSubtitle:
      'Click any branch plan column below to load its exact breakdown into the live estimator above.',
    thFeeItem: 'Fee Component',
    rowTotalOneTime: 'Total One-Time (Admission + Uniform & Case)',
    rowTotalMonthly: 'Total Monthly Payable',
    scholarshipNoteTitle: 'Scholarship & Financial Aid Policy:',
    scholarshipNoteBody:
      'Based on financial hardship and merit evaluation, scholarships from 5% up to 50% are awarded on monthly tuition or one-time admission fees.',
    currencySuffix: 'BDT',
  },
  ar: {
    intro:
      'اختر أحد الأقسام التعليمية لاستعراض خطته الدراسية الأسبوعية وحساب الرسوم التأسيسية والشهرية عبر الفروع الخمسة مع منح تتراوح بين ٥٪ و٥٠٪.',
    annualIntake: 'الطاقة الاستيعابية السنوية',
    seatsSuffix: 'مقعداً',
    facultyRatio: 'نسبة المعلمين للطلاب',
    weeklyInstruction: 'ساعات التدريس الأسبوعية',
    hoursSuffix: 'ساعة',
    thCode: 'الرمز',
    thSubject: 'المادة الدراسية والوصف',
    thStream: 'المسار العلمي',
    thHours: 'ساعة / أسبوع',
    estimatorNote: 'حساب فوري للرسوم الدراسية',
    planSelectorLabel: 'اختر النظام والباقة',
    scholarshipLabel: 'نسبة المنحة الدراسية (٥٪ – ٥٠٪)',
    scholarshipNone: 'الرسوم الأساسية (٠٪ — بدون منحة)',
    scholarshipScopeLabel: 'نطاق تطبيق المنحة',
    scopeMonthly: 'الرسوم الشهرية',
    scopeOneTime: 'رسوم القبول',
    scopeBoth: 'كلاهما',
    feeAdmission: 'رسوم القبول وتسجيل المختبر (مرة واحدة)',
    feeDress: 'الزي المدرسي والحقيبة',
    feeOneTimeWaiver: 'خصم المنحة على رسوم القبول',
    feeNetOneTime: 'صافي رسوم القبول التأسيسية',
    feeMonthlyTuition: 'الرسوم الشهرية الأساسية',
    feeWeeklyTest: 'الاختبارات الأسبوعية والشهرية',
    feeHostelRent: 'رسوم السكن الداخلي',
    feeFood: 'الوجبات والإعاشة',
    feeClub: 'مرافق النادي والأنشطة',
    feeLab: 'رسوم المختبر',
    feeMonthlyWaiver: 'خصم المنحة الشهرية',
    feeNet: 'صافي الرسوم الشهرية المستحقة',
    feeAnnual: 'إجمالي السنة الأولى التقديري (التأسيسية + ١٢ شهراً)',
    applyPrefix: 'تقديم طلب للالتحاق بـ ',
    weeklyScheduleHeading: 'جدول التدريس والاختبار الأسبوعي حسب الفترة والسكن',
    testRowCode: 'TST-WK',
    testRowSubject: 'الاختبار والتقييم الأسبوعي',
    testRowStream: 'التقييم الأسبوعي',
    feeMatrixEyebrow: 'هيكل الرسوم · বেতন কাঠামো · Official Fee Schedule',
    feeMatrixHeading: 'جدول الرسوم الكامل لجميع الفروع والباقات',
    feeMatrixSubtitle:
      'انقر على أي باقة أدناه لتحميل تفاصيلها مباشرة في حاسبة الرسوم أعلاه.',
    thFeeItem: 'بند الرسوم',
    rowTotalOneTime: 'إجمالي الرسوم التأسيسية (القبول + الزي)',
    rowTotalMonthly: 'إجمالي الرسوم الشهرية',
    scholarshipNoteTitle: 'سياسة المنح والدعم المالي:',
    scholarshipNoteBody:
      'تُمنح منح دراسية تتراوح من ٥٪ إلى ٥٠٪ على الرسوم الشهرية أو رسوم القبول لمرة واحدة بناءً على تقييم التفوق أو الحاجة المالية.',
    currencySuffix: 'تاكا',
  },
};

export function AcademicsSection({
  activeDivision: controlledDivision,
  onChangeDivision,
  onSelectDivisionForApplication,
}: AcademicsSectionProps) {
  const { lang, dir } = useDescriptionLanguage();
  const copy = ACADEMICS_COPY[lang];
  const [internalDivision, setInternalDivision] = useState<DivisionId>('general');
  const activeDivision = controlledDivision ?? internalDivision;
  const setActiveDivision = (next: DivisionId) => {
    setInternalDivision(next);
    onChangeDivision?.(next);
  };
  const [feePlanId, setFeePlanId] = useState<FeePlanId>('non-res-morning');
  const [scholarshipPercent, setScholarshipPercent] = useState<ScholarshipPercent>(0);
  const [scholarshipScope, setScholarshipScope] = useState<ScholarshipScope>('monthly');

  const selectedPlan = resolveFeePlan(feePlanId);
  const shift = selectedPlan.shift;
  const residential = selectedPlan.residential;

  const program = ACADEMIC_PROGRAMS.find((p) => p.id === activeDivision) ?? ACADEMIC_PROGRAMS[0];
  const activeSchedule = getWeeklyInstructionSchedule(activeDivision, shift, residential);
  const divisionModes = getDivisionWeeklyModes(activeDivision);

  const tuition = calculateTuitionBreakdown({
    division: activeDivision,
    planId: feePlanId,
    scholarshipPercent,
    scholarshipScope,
  });

  const activeProgramName =
    lang === 'bn' ? program.bnTitle : lang === 'en' ? program.title : program.arTitle;

  const formatAmount = (amount: number) => {
    if (amount === 0) return '—';
    return `${formatCurrencyBDT(amount)} ${copy.currencySuffix}`;
  };

  return (
    <section id="academics" className="py-16 lg:py-20 border-b border-[#E5DFD2] bg-white">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        <div className="max-w-3xl">
          <p className="text-xs font-medium tracking-wide text-[#8E6210]">
            ০১. একাডেমিক কাঠামো ও বেতন · Academic Architecture ·{' '}
            <span dir="rtl" lang="ar" className="font-arabic">
              الهيكل الأكاديمي والرسوم
            </span>
          </p>
          <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-[#14231B] text-balance">
            শিক্ষার চারটি সমন্বিত বিভাগ
          </h2>
          <p className="mt-1 text-sm font-medium text-[#2D4C3B]">
            Four Integrated Divisions of Learning ·{' '}
            <span dir="rtl" lang="ar" className="font-arabic font-semibold text-[#8E6210]">
              أربعة أقسام تعليمية متكاملة
            </span>
          </p>
          <p
            dir={dir}
            lang={lang}
            className={`mt-3 text-[15px] leading-relaxed text-[#4B564F] ${
              lang === 'ar' ? 'font-arabic text-right' : ''
            }`}
          >
            {copy.intro}
          </p>
        </div>

        {/* Division Selector Tabs */}
        <div
          role="tablist"
          aria-label="একাডেমিক বিভাগসমূহ"
          className="mt-8 flex flex-wrap gap-2 border-b border-[#E5DFD2] pb-4"
        >
          {ACADEMIC_PROGRAMS.map((div) => {
            const isActive = div.id === activeDivision;
            return (
              <button
                key={div.id}
                role="tab"
                type="button"
                aria-selected={isActive}
                onClick={() => setActiveDivision(div.id)}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#234232] ${
                  isActive
                    ? 'bg-[#234232] text-white'
                    : 'bg-[#F5F2EB] text-[#2F3A33] hover:bg-[#E9E3D5]'
                }`}
              >
                {div.title}
              </button>
            );
          })}
        </div>

        {/* Curriculum & Tuition Split */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Curriculum Table (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs font-mono text-[#5B665F] tabular-nums">
                <span>{program.code}</span>
                <span aria-hidden="true">·</span>
                <span>{program.gradesByLang[lang]}</span>
                <span aria-hidden="true">·</span>
                <span>{program.ageRangeByLang[lang]}</span>
                <span aria-hidden="true">·</span>
                <span>{program.shiftSummaryByLang[lang]}</span>
              </div>
              <h3 className="mt-2 font-serif text-2xl font-semibold text-[#182E23]">{program.bnTitle}</h3>
              <p className="mt-1 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs font-medium text-[#2D4C3B]">
                <span className="font-mono">{program.title}</span>
                <span aria-hidden="true">·</span>
                <span dir="rtl" lang="ar" className="font-arabic text-sm font-semibold text-[#8E6210]">
                  {program.arTitle}
                </span>
              </p>
              <p
                dir={dir}
                lang={lang}
                className={`mt-2.5 text-[15px] leading-relaxed text-[#434E47] ${
                  lang === 'ar' ? 'font-arabic text-right' : ''
                }`}
              >
                {program.summaryByLang[lang]}
              </p>
            </div>

            {/* Key Metrics Strip */}
            <div
              dir={dir}
              className={`grid grid-cols-3 gap-4 py-4 border-y border-[#E5DFD2] ${
                lang === 'ar' ? 'font-arabic text-right' : ''
              }`}
            >
              <div>
                <div className="text-xs text-[#5B665F]">{copy.annualIntake}</div>
                <div className="mt-0.5 text-lg font-semibold text-[#182E23] tabular-nums">
                  {program.seatCapacity} {copy.seatsSuffix}
                </div>
              </div>
              <div>
                <div className="text-xs text-[#5B665F]">{copy.facultyRatio}</div>
                <div className="mt-0.5 text-lg font-semibold text-[#182E23] tabular-nums">
                  {program.studentTeacherRatioByLang[lang]}
                </div>
              </div>
              <div>
                <div className="text-xs text-[#5B665F]">{copy.weeklyInstruction}</div>
                <div
                  data-testid="active-weekly-instruction"
                  className="mt-0.5 text-base sm:text-lg font-semibold text-[#182E23] tabular-nums"
                >
                  {activeSchedule.compactByLang[lang]}
                </div>
              </div>
            </div>

            {/* Shift & Residential Weekly Hours Switcher */}
            <div dir={dir} className={lang === 'ar' ? 'font-arabic text-right' : ''}>
              <div className="text-xs font-medium text-[#5B665F] mb-2">{copy.weeklyScheduleHeading}</div>
              <div
                data-testid="division-weekly-modes"
                className={`grid grid-cols-1 gap-2.5 ${
                  divisionModes.length === 3 ? 'sm:grid-cols-3' : 'sm:grid-cols-2'
                }`}
              >
                {divisionModes.map((mode) => {
                  const isModeActive =
                    (mode.modeKey === 'residential' && residential === 'hostel') ||
                    (mode.modeKey !== 'residential' &&
                      residential === 'day-scholar' &&
                      (divisionModes.length === 2 || mode.modeKey === shift));
                  return (
                    <button
                      key={`${program.id}-${mode.modeKey}`}
                      type="button"
                      aria-pressed={isModeActive}
                      onClick={() => {
                        if (mode.modeKey === 'residential') {
                          setFeePlanId((prev) =>
                            prev === 'res-morning-lab' ? 'res-morning-lab' : 'res-morning'
                          );
                        } else if (mode.modeKey === 'day') {
                          setFeePlanId('non-res-day');
                        } else {
                          setFeePlanId((prev) =>
                            prev === 'non-res-morning-lab' ? 'non-res-morning-lab' : 'non-res-morning'
                          );
                        }
                      }}
                      className={`px-3.5 py-2.5 rounded-md border transition-colors cursor-pointer ${
                        lang === 'ar' ? 'text-right' : 'text-left'
                      } ${
                        isModeActive
                          ? 'bg-[#F4EFE4] border-[#234232] text-[#14231B]'
                          : 'bg-white border-[#E5DFD2] text-[#4B564F] hover:border-[#234232]/50'
                      }`}
                    >
                      <div className="text-xs font-medium text-[#5B665F]">{mode.modeLabelByLang[lang]}</div>
                      <div className="mt-0.5 text-sm font-semibold text-[#182E23] tabular-nums">
                        {mode.displayByLang[lang]}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Structured Curriculum Table */}
            <div className="overflow-x-auto border border-[#E5DFD2] rounded-lg">
              <table
                dir={dir}
                className={`w-full border-collapse ${lang === 'ar' ? 'text-right font-arabic' : 'text-left'}`}
              >
                <thead>
                  <tr className="bg-[#FAF8F4] border-b border-[#E5DFD2] text-xs font-medium text-[#5B665F]">
                    <th className="py-3 px-4 font-medium">{copy.thCode}</th>
                    <th className="py-3 px-4 font-medium">{copy.thSubject}</th>
                    <th className="py-3 px-4 font-medium">{copy.thStream}</th>
                    <th className={`py-3 px-4 font-medium ${lang === 'ar' ? 'text-left' : 'text-right'}`}>
                      {copy.thHours}
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EFECE4] text-sm">
                  {program.modules.map((mod) => (
                    <tr key={mod.code} className="hover:bg-[#FAF8F4]/70 transition-colors">
                      <td className="py-3 px-4 font-mono text-xs text-[#5B665F] tabular-nums whitespace-nowrap">
                        {mod.code}
                      </td>
                      <td className="py-3 px-4 font-medium text-[#1A1F1C]">{mod.subjectByLang[lang]}</td>
                      <td className="py-3 px-4 text-[#4B564F] whitespace-nowrap">{mod.streamByLang[lang]}</td>
                      <td
                        className={`py-3 px-4 font-mono text-[#182E23] tabular-nums ${
                          lang === 'ar' ? 'text-left' : 'text-right'
                        }`}
                      >
                        {mod.hoursByMode[activeSchedule.modeKey]}
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-[#FAF8F4] font-medium">
                    <td className="py-3 px-4 font-mono text-xs text-[#8E6210] tabular-nums whitespace-nowrap">
                      {copy.testRowCode}
                    </td>
                    <td className="py-3 px-4 text-[#182E23]">{copy.testRowSubject}</td>
                    <td className="py-3 px-4 text-[#8E6210] whitespace-nowrap">{copy.testRowStream}</td>
                    <td
                      className={`py-3 px-4 font-mono font-semibold text-[#182E23] tabular-nums ${
                        lang === 'ar' ? 'text-left' : 'text-right'
                      }`}
                    >
                      {activeSchedule.testHours}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Interactive Tuition & Scholarship Estimator (5 cols) */}
          <aside
            aria-label="টিউশন ফি ও বৃত্তি নির্ধারক"
            dir={dir}
            className={`lg:col-span-5 bg-[#FAF8F4] border border-[#DCD5C7] rounded-lg p-6 ${
              lang === 'ar' ? 'font-arabic text-right' : ''
            }`}
          >
            <div className="border-b border-[#E5DFD2] pb-4" dir="ltr">
              <h3 className="font-serif text-2xl font-semibold text-[#182E23]">বেতন ও বৃত্তি নির্ধারক</h3>
              <p className="mt-0.5 text-xs font-medium text-[#2D4C3B]">
                Tuition &amp; Fee Estimator ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic text-[#8E6210]">
                  حاسبة الرسوم والمنح الدراسية
                </span>
              </p>
              <p dir={dir} className="mt-1 text-xs text-[#5B665F]">
                {lang === 'bn'
                  ? `${activeProgramName} (${program.gradesByLang.bn}) ${copy.estimatorNote}`
                  : `${copy.estimatorNote} — ${activeProgramName}`}
              </p>
            </div>

            <div className="mt-5 space-y-4">
              {/* 5 Official Fee Package Selector */}
              <div>
                <span className="block text-xs font-medium text-[#434E47] mb-2">
                  {copy.planSelectorLabel}
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2" data-testid="fee-plan-buttons">
                  {FEE_PLANS.map((plan, idx) => {
                    const isSelected = plan.id === feePlanId;
                    return (
                      <button
                        key={plan.id}
                        type="button"
                        onClick={() => setFeePlanId(plan.id)}
                        aria-pressed={isSelected}
                        className={`${
                          idx === FEE_PLANS.length - 1 ? 'sm:col-span-2' : ''
                        } py-2 px-3 text-xs sm:text-[13px] font-medium rounded-md border transition-colors cursor-pointer ${
                          lang === 'ar' ? 'text-right' : 'text-left'
                        } ${
                          isSelected
                            ? 'bg-[#234232] text-white border-[#234232]'
                            : 'bg-white text-[#2F3A33] border-[#DCD5C7] hover:border-[#234232]'
                        }`}
                      >
                        {plan.labelByLang[lang]}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Scholarship Rate (5% to 50%) */}
              <div className="grid grid-cols-1 gap-3">
                <div>
                  <label htmlFor="scholarship-tier" className="block text-xs font-medium text-[#434E47] mb-1.5">
                    {copy.scholarshipLabel}
                  </label>
                  <select
                    id="scholarship-tier"
                    value={scholarshipPercent}
                    onChange={(e) => setScholarshipPercent(Number(e.target.value) as ScholarshipPercent)}
                    className="w-full px-3 py-2 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] focus:outline-2 focus:outline-[#234232]"
                  >
                    {SCHOLARSHIP_PERCENT_OPTIONS.map((pct) => (
                      <option key={pct} value={pct}>
                        {pct === 0
                          ? copy.scholarshipNone
                          : `${toLocaleDigits(pct, lang)}% ${
                              lang === 'bn'
                                ? 'মেধা / অস্বচ্ছলতা বৃত্তি'
                                : lang === 'en'
                                  ? 'Merit / Financial Aid Waiver'
                                  : 'منحة تفوق / دعم مالي'
                            }`}
                      </option>
                    ))}
                  </select>
                </div>

                {scholarshipPercent > 0 && (
                  <div>
                    <span className="block text-xs font-medium text-[#434E47] mb-1.5">
                      {copy.scholarshipScopeLabel}
                    </span>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(
                        [
                          { id: 'monthly' as const, label: copy.scopeMonthly },
                          { id: 'one-time' as const, label: copy.scopeOneTime },
                          { id: 'both' as const, label: copy.scopeBoth },
                        ]
                      ).map((opt) => (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setScholarshipScope(opt.id)}
                          aria-pressed={scholarshipScope === opt.id}
                          className={`py-1.5 px-2 text-xs font-medium rounded-md border transition-colors whitespace-nowrap cursor-pointer ${
                            scholarshipScope === opt.id
                              ? 'bg-[#234232] text-white border-[#234232]'
                              : 'bg-white text-[#2F3A33] border-[#DCD5C7] hover:border-[#234232]'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Itemized One-Time & Monthly Fee Breakdown */}
            <dl className="mt-5 pt-4 border-t border-[#DCD5C7] space-y-2 text-xs sm:text-sm">
              <div className="flex justify-between gap-3">
                <dt className="text-[#4B564F]">{copy.feeAdmission}</dt>
                <dd className="font-mono font-medium text-[#182E23] tabular-nums whitespace-nowrap">
                  {formatAmount(tuition.admissionFee)}
                </dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-[#4B564F]">{copy.feeDress}</dt>
                <dd className="font-mono text-[#182E23] tabular-nums whitespace-nowrap">
                  {formatAmount(tuition.uniformCaseFee)}
                </dd>
              </div>
              {tuition.oneTimeScholarshipSavings > 0 && (
                <div className="flex justify-between gap-3 text-[#234232]">
                  <dt>
                    {copy.feeOneTimeWaiver} ({toLocaleDigits(tuition.scholarshipDiscountPercent, lang)}%)
                  </dt>
                  <dd className="font-mono font-medium tabular-nums whitespace-nowrap">
                    −{formatAmount(tuition.oneTimeScholarshipSavings)}
                  </dd>
                </div>
              )}
              <div className="pt-1.5 pb-2 border-b border-[#E5DFD2] flex justify-between gap-3 font-medium">
                <dt className="text-[#14231B]">{copy.feeNetOneTime}</dt>
                <dd
                  data-testid="estimator-net-onetime"
                  className="font-mono font-semibold text-[#182E23] tabular-nums whitespace-nowrap"
                >
                  {formatAmount(tuition.netOneTimeFee)}
                </dd>
              </div>

              <div className="pt-1 flex justify-between gap-3">
                <dt className="text-[#4B564F]">{copy.feeMonthlyTuition}</dt>
                <dd className="font-mono text-[#182E23] tabular-nums whitespace-nowrap">
                  {formatAmount(tuition.monthlyTuition)}
                </dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-[#4B564F]">{copy.feeWeeklyTest}</dt>
                <dd className="font-mono text-[#182E23] tabular-nums whitespace-nowrap">
                  {formatAmount(tuition.weeklyMonthlyTestFee)}
                </dd>
              </div>
              {tuition.hostelRentFee > 0 && (
                <div className="flex justify-between gap-3">
                  <dt className="text-[#4B564F]">{copy.feeHostelRent}</dt>
                  <dd className="font-mono text-[#182E23] tabular-nums whitespace-nowrap">
                    {formatAmount(tuition.hostelRentFee)}
                  </dd>
                </div>
              )}
              {tuition.foodFee > 0 && (
                <div className="flex justify-between gap-3">
                  <dt className="text-[#4B564F]">{copy.feeFood}</dt>
                  <dd className="font-mono text-[#182E23] tabular-nums whitespace-nowrap">
                    {formatAmount(tuition.foodFee)}
                  </dd>
                </div>
              )}
              {tuition.clubFee > 0 && (
                <div className="flex justify-between gap-3">
                  <dt className="text-[#4B564F]">{copy.feeClub}</dt>
                  <dd className="font-mono text-[#182E23] tabular-nums whitespace-nowrap">
                    {formatAmount(tuition.clubFee)}
                  </dd>
                </div>
              )}
              {tuition.labFee > 0 && (
                <div className="flex justify-between gap-3">
                  <dt className="text-[#4B564F]">{copy.feeLab}</dt>
                  <dd className="font-mono text-[#182E23] tabular-nums whitespace-nowrap">
                    {formatAmount(tuition.labFee)}
                  </dd>
                </div>
              )}
              {tuition.scholarshipMonthlySavings > 0 && (
                <div className="flex justify-between gap-3 text-[#234232]">
                  <dt>
                    {copy.feeMonthlyWaiver} ({toLocaleDigits(tuition.scholarshipDiscountPercent, lang)}%)
                  </dt>
                  <dd className="font-mono font-medium tabular-nums whitespace-nowrap">
                    −{formatAmount(tuition.scholarshipMonthlySavings)}
                  </dd>
                </div>
              )}

              <div className="pt-3 border-t border-[#DCD5C7] flex justify-between items-baseline gap-3">
                <dt className="font-semibold text-[#14231B]">{copy.feeNet}</dt>
                <dd
                  data-testid="estimator-net-monthly"
                  className="font-mono text-lg font-semibold text-[#182E23] tabular-nums whitespace-nowrap"
                >
                  {formatAmount(tuition.netMonthlyFee)}
                </dd>
              </div>
              <div className="flex justify-between items-baseline gap-3 text-xs text-[#5B665F]">
                <dt>{copy.feeAnnual}</dt>
                <dd
                  data-testid="estimator-annual-total"
                  className="font-mono font-medium tabular-nums whitespace-nowrap"
                >
                  {formatAmount(tuition.annualTotal)}
                </dd>
              </div>
            </dl>

            <button
              type="button"
              onClick={() => onSelectDivisionForApplication(activeDivision, shift, residential)}
              className="mt-6 w-full py-2.5 px-4 text-sm font-semibold text-white bg-[#234232] hover:bg-[#182E23] rounded-md transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#234232]"
            >
              {lang === 'bn'
                ? `${program.bnTitle}${copy.applyPrefix}`
                : `${copy.applyPrefix}${activeProgramName}`}
            </button>
          </aside>
        </div>

        {/* Full Official Fee Structure Matrix (All 5 Plans) */}
        <div id="fee-structure" className="mt-14 pt-10 border-t border-[#E5DFD2]" data-testid="fee-structure-section">
          <div className="max-w-3xl">
            <p className="text-xs font-medium tracking-wide text-[#8E6210]">{copy.feeMatrixEyebrow}</p>
            <h3 className="mt-1.5 font-serif text-2xl sm:text-3xl font-semibold text-[#14231B]">
              {copy.feeMatrixHeading}
            </h3>
            <p
              dir={dir}
              lang={lang}
              className={`mt-1.5 text-sm text-[#4B564F] ${lang === 'ar' ? 'font-arabic text-right' : ''}`}
            >
              {copy.feeMatrixSubtitle}
            </p>
          </div>

          <div className="mt-6 overflow-x-auto border border-[#E5DFD2] rounded-lg bg-white">
            <table
              dir={dir}
              className={`w-full border-collapse text-sm ${
                lang === 'ar' ? 'text-right font-arabic' : 'text-left'
              }`}
            >
              <thead>
                <tr className="bg-[#FAF8F4] border-b border-[#E5DFD2] text-xs font-semibold text-[#182E23]">
                  <th className="py-3.5 px-4 min-w-[200px]">{copy.thFeeItem}</th>
                  {FEE_PLANS.map((plan) => {
                    const isActive = plan.id === feePlanId;
                    return (
                      <th
                        key={plan.id}
                        className={`py-3.5 px-3 min-w-[140px] ${
                          lang === 'ar' ? 'text-left' : 'text-right'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => setFeePlanId(plan.id)}
                          aria-pressed={isActive}
                          className={`inline-block font-semibold underline-offset-4 hover:underline cursor-pointer ${
                            isActive ? 'text-[#234232] underline decoration-[#C5932A]' : 'text-[#354039]'
                          }`}
                        >
                          {plan.labelByLang[lang]}
                        </button>
                      </th>
                    );
                  })}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EFECE4]">
                {(
                  [
                    { label: copy.feeAdmission, key: 'admissionFee' as const },
                    { label: copy.feeDress, key: 'uniformCaseFee' as const },
                    { label: copy.feeMonthlyTuition, key: 'monthlyTuition' as const },
                    { label: copy.feeWeeklyTest, key: 'weeklyMonthlyTestFee' as const },
                    { label: copy.feeHostelRent, key: 'hostelRentFee' as const },
                    { label: copy.feeFood, key: 'foodFee' as const },
                    { label: copy.feeClub, key: 'clubFee' as const },
                    { label: copy.feeLab, key: 'labFee' as const },
                  ]
                ).map((row) => (
                  <tr key={row.key} className="hover:bg-[#FAF8F4]/70 transition-colors">
                    <td className="py-3 px-4 font-medium text-[#1A1F1C]">{row.label}</td>
                    {FEE_PLANS.map((plan) => {
                      const val = plan[row.key];
                      const isActive = plan.id === feePlanId;
                      return (
                        <td
                          key={`${row.key}-${plan.id}`}
                          className={`py-3 px-3 font-mono tabular-nums whitespace-nowrap ${
                            lang === 'ar' ? 'text-left' : 'text-right'
                          } ${isActive ? 'bg-[#FAF8F4] font-semibold text-[#182E23]' : 'text-[#434E47]'}`}
                        >
                          {val > 0 ? formatAmount(val) : '—'}
                        </td>
                      );
                    })}
                  </tr>
                ))}

                <tr className="bg-[#FAF8F4] font-semibold border-t border-[#DCD5C7]">
                  <td className="py-3 px-4 text-[#182E23]">{copy.rowTotalOneTime}</td>
                  {FEE_PLANS.map((plan) => (
                    <td
                      key={`onetime-${plan.id}`}
                      className={`py-3 px-3 font-mono tabular-nums whitespace-nowrap text-[#182E23] ${
                        lang === 'ar' ? 'text-left' : 'text-right'
                      }`}
                    >
                      {formatAmount(plan.admissionFee + plan.uniformCaseFee)}
                    </td>
                  ))}
                </tr>
                <tr className="bg-[#F4EFE4] font-semibold">
                  <td className="py-3.5 px-4 text-[#14231B]">{copy.rowTotalMonthly}</td>
                  {FEE_PLANS.map((plan) => {
                    const monthlySum =
                      plan.monthlyTuition +
                      plan.weeklyMonthlyTestFee +
                      plan.hostelRentFee +
                      plan.foodFee +
                      plan.clubFee +
                      plan.labFee;
                    return (
                      <td
                        key={`monthly-${plan.id}`}
                        className={`py-3.5 px-3 font-mono tabular-nums whitespace-nowrap text-[#234232] ${
                          lang === 'ar' ? 'text-left' : 'text-right'
                        }`}
                      >
                        {formatAmount(monthlySum)}
                      </td>
                    );
                  })}
                </tr>
              </tbody>
            </table>
          </div>

          <div
            dir={dir}
            lang={lang}
            className={`mt-5 p-4 sm:p-5 bg-[#FAF8F4] border border-[#DCD5C7] rounded-lg text-sm leading-relaxed text-[#2F3A33] ${
              lang === 'ar' ? 'font-arabic text-right' : ''
            }`}
          >
            <span className="font-semibold text-[#182E23]">{copy.scholarshipNoteTitle}</span>{' '}
            <span>{copy.scholarshipNoteBody}</span>
          </div>
        </div>
      </div>
    </section>
  );
}

import { Languages } from 'lucide-react';
import { useDescriptionLanguage } from '../context/LanguageContext';
import type { DescriptionLang, LangMode } from '../utils/i18n';

interface DescriptionTranslateBarProps {
  compact?: boolean;
}

const LANG_NAME: Record<DescriptionLang, string> = {
  bn: 'বাংলা',
  en: 'English',
  ar: 'العربية',
};

const OPTIONS: Array<{ mode: LangMode; label: string }> = [
  { mode: 'auto', label: 'Auto' },
  { mode: 'bn', label: 'বাংলা' },
  { mode: 'en', label: 'English' },
  { mode: 'ar', label: 'العربية' },
];

export function DescriptionTranslateBar({ compact = false }: DescriptionTranslateBarProps) {
  const { mode, lang, detectedLang, setMode } = useDescriptionLanguage();

  return (
    <div
      className={`flex flex-wrap items-center justify-between gap-3 ${
        compact
          ? 'py-2.5 px-3.5 bg-white border border-[#DCD5C7] rounded-lg'
          : 'py-3 px-4 bg-white border border-[#DCD5C7] rounded-lg'
      }`}
    >
      <div className="flex items-center gap-2 text-xs text-[#434E47]">
        <Languages className="w-4 h-4 text-[#234232] shrink-0" aria-hidden="true" />
        <span className="font-medium text-[#182E23]">
          বর্ণনার ভাষা (Auto-Translate):
        </span>
        <span className="text-[#5B665F]">
          {mode === 'auto'
            ? `স্বয়ংক্রিয় (${LANG_NAME[detectedLang]})`
            : LANG_NAME[lang]}
        </span>
      </div>

      <div
        role="group"
        aria-label="বর্ণনা অনুবাদের ভাষা নির্বাচন করুন"
        className="flex flex-wrap items-center gap-1 bg-[#F5F2EB] p-1 rounded-md"
      >
        {OPTIONS.map((opt) => {
          const isActive = mode === opt.mode;
          return (
            <button
              key={opt.mode}
              type="button"
              onClick={() => setMode(opt.mode)}
              aria-pressed={isActive}
              className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#234232] ${
                isActive
                  ? 'bg-[#234232] text-white'
                  : 'text-[#354039] hover:text-[#182E23] hover:bg-white/70'
              }`}
            >
              {opt.mode === 'auto' ? 'Auto · স্বয়ংক্রিয়' : opt.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

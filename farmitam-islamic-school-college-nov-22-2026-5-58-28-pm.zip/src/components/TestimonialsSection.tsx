import { useState } from 'react';
import { useDescriptionLanguage } from '../context/LanguageContext';
import { TESTIMONIALS, type TestimonialItem } from '../data/schoolData';
import { filterTestimonials, type TestimonialRoleFilter } from '../utils/admissions';
import { DescriptionTranslateBar } from './DescriptionTranslateBar';

const TESTIMONIALS_COPY = {
  bn: {
    intro:
      'অভিভাবক ও শিক্ষার্থীদের বাস্তব অভিজ্ঞতা এবং সাফল্যের গল্প—যেখানে দ্বীনি চরিত্র গঠন ও আধুনিক শিক্ষার ফলাফল একসাথে প্রতিফলিত হয়েছে।',
    featuredTag: 'বিশেষ সাফল্যের গল্প',
    filters: [
      { key: 'All' as const, label: 'সকল মতামত (৭)' },
      { key: 'Parent' as const, label: 'অভিভাবকবৃন্দ (৪)' },
      { key: 'Student' as const, label: 'শিক্ষার্থীবৃন্দ (৩)' },
    ],
    outcomesTitle: 'প্রাতিষ্ঠানিক আস্থা ও ফলাফলের ভিত্তি',
    trustStats: [
      { value: '৪টি', label: 'সমন্বিত বিভাগ (প্লে–দশম, ক্যাডেট, নূরানী, হিফজ)' },
      { value: '৩০:১', label: 'প্রতিটি বিভাগে নিবিড় শিক্ষক-শিক্ষার্থী অনুপাত' },
      { value: 'সাপ্তাহিক', label: 'নিয়মিত সবক-সবিনা ও মূল্যায়ন টেস্ট তদারকি' },
    ],
    parentRoleTag: 'অভিভাবক',
    studentRoleTag: 'শিক্ষার্থী',
  },
  en: {
    intro:
      'Verified reflections from guardians and students showcasing measurable growth in Quran memorization, national board readiness, and Islamic character.',
    featuredTag: 'Featured Success Story',
    filters: [
      { key: 'All' as const, label: 'All Voices (7)' },
      { key: 'Parent' as const, label: 'Parents & Guardians (4)' },
      { key: 'Student' as const, label: 'Students & Huffaz (3)' },
    ],
    outcomesTitle: 'Foundations of Community Trust',
    trustStats: [
      { value: '4 Wings', label: 'General (Play–Ten), Cadet, Noorani & Hifzul Quran' },
      { value: '30:1', label: 'Dedicated Faculty-to-Student Mentorship Ratio' },
      { value: 'Weekly', label: 'Structured Diagnostic Tests & Daily Sabaq-Sabina Audits' },
    ],
    parentRoleTag: 'Parent',
    studentRoleTag: 'Student',
  },
  ar: {
    intro:
      'تجارب حقيقية وقصص نجاح من أولياء الأمور والطلاب تجسد ثمرة الجمع بين التربية الإيمانية والتميز العلمي الحديث.',
    featuredTag: 'قصة نجاح مميزة',
    filters: [
      { key: 'All' as const, label: 'جميع الشهادات (٧)' },
      { key: 'Parent' as const, label: 'أولياء الأمور (٤)' },
      { key: 'Student' as const, label: 'الطلاب والحفاظ (٣)' },
    ],
    outcomesTitle: 'ركائز الثقة المجتمعية والنتائج',
    trustStats: [
      { value: '٤ أقسام', label: 'العام والكاديت والنوراني وتحفيظ القرآن' },
      { value: '٣٠:١', label: 'نسبة إشراف وتوجيه منضبطة بين المعلمين والطلاب' },
      { value: 'أسبوعياً', label: 'اختبارات تقييمية منتظمة ومتابعة يومية للسبق والسبينا' },
    ],
    parentRoleTag: 'ولي أمر',
    studentRoleTag: 'طالب',
  },
};

export function TestimonialsSection() {
  const { lang, dir } = useDescriptionLanguage();
  const copy = TESTIMONIALS_COPY[lang];
  const [roleFilter, setRoleFilter] = useState<TestimonialRoleFilter>('All');

  const filteredItems = filterTestimonials(TESTIMONIALS, roleFilter);
  const featuredItem: TestimonialItem | undefined =
    filteredItems.find((item) => item.featured) ?? filteredItems[0];
  const secondaryItems = filteredItems.filter((item) => item.id !== featuredItem?.id);

  return (
    <section id="testimonials" className="py-16 lg:py-20 border-b border-[#E5DFD2] bg-white">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-6 border-b border-[#E5DFD2]">
          <div className="max-w-3xl">
            <p className="text-xs font-medium tracking-wide text-[#8E6210]">
              ০৭. অভিভাবক ও শিক্ষার্থীদের মতামত · Parent &amp; Student Testimonials ·{' '}
              <span dir="rtl" lang="ar" className="font-arabic">
                آراء أولياء الأمور والطلاب
              </span>
            </p>
            <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-[#14231B] text-balance">
              অভিভাবক ও শিক্ষার্থীদের আস্থার গল্প
            </h2>
            <p className="mt-1 text-sm font-medium text-[#2D4C3B]">
              Voices of Parents &amp; Scholars ·{' '}
              <span dir="rtl" lang="ar" className="font-arabic font-semibold text-[#8E6210]">
                قصص نجاح وشهادات أولياء الأمور والطلاب
              </span>
            </p>
            <p
              dir={dir}
              lang={lang}
              className={`mt-2.5 text-[15px] leading-relaxed text-[#4B564F] ${
                lang === 'ar' ? 'font-arabic text-right' : ''
              }`}
            >
              {copy.intro}
            </p>
          </div>

          <div className="shrink-0">
            <DescriptionTranslateBar compact />
          </div>
        </div>

        {/* Interactive Audience Filter Bar */}
        <div
          className="mt-6 flex flex-wrap gap-2"
          role="group"
          aria-label="মতামত ফিল্টার করুন"
        >
          {copy.filters.map((filterOpt) => {
            const isSelected = filterOpt.key === roleFilter;
            return (
              <button
                key={filterOpt.key}
                type="button"
                aria-pressed={isSelected}
                onClick={() => setRoleFilter(filterOpt.key)}
                className={`px-3.5 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#234232] ${
                  isSelected
                    ? 'bg-[#234232] text-white'
                    : 'bg-white border border-[#DCD5C7] text-[#354039] hover:border-[#234232]'
                }`}
              >
                {filterOpt.label}
              </button>
            );
          })}
        </div>

        {/* Featured Editorial Success Story + Institutional Trust Metrics */}
        {featuredItem && (
          <article
            data-testid="featured-testimonial"
            dir={dir}
            lang={lang}
            className={`mt-8 bg-[#FAF8F4] border border-[#DCD5C7] rounded-lg p-6 sm:p-8 ${
              lang === 'ar' ? 'font-arabic text-right' : ''
            }`}
          >
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              <div className="lg:col-span-8 space-y-4">
                <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs font-medium text-[#8E6210]">
                  <span>{copy.featuredTag}</span>
                  <span aria-hidden="true">·</span>
                  <span>{featuredItem.wingLabelByLang[lang]}</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-[#234232]">{featuredItem.outcomeByLang[lang]}</span>
                </div>

                <blockquote className="font-serif text-xl sm:text-2xl leading-[1.6] text-[#182E23] text-pretty">
                  “{featuredItem.quoteByLang[lang]}”
                </blockquote>

                <div className="pt-4 border-t border-[#EFECE4] flex flex-wrap items-baseline justify-between gap-2">
                  <div>
                    <div className="text-base font-semibold text-[#14231B]">
                      {featuredItem.nameByLang[lang]}
                    </div>
                    <div className="text-xs text-[#5B665F] mt-0.5">
                      {featuredItem.roleByLang[lang]}
                    </div>
                  </div>
                  <div className="text-xs font-medium text-[#2D4C3B]">
                    {featuredItem.authorType === 'Parent' ? copy.parentRoleTag : copy.studentRoleTag}
                  </div>
                </div>
              </div>

              <div className="lg:col-span-4 pt-5 lg:pt-0 border-t lg:border-t-0 border-[#E5DFD2] space-y-4">
                <div className="text-xs font-medium tracking-wide text-[#5B665F]">
                  {copy.outcomesTitle}
                </div>
                <dl className="divide-y divide-[#EFECE4]">
                  {copy.trustStats.map((stat) => (
                    <div key={stat.value} className="py-3 first:pt-0 last:pb-0">
                      <dt className="font-serif text-xl font-semibold text-[#182E23] tabular-nums">
                        {stat.value}
                      </dt>
                      <dd className="mt-0.5 text-xs leading-relaxed text-[#4B564F]">{stat.label}</dd>
                    </div>
                  ))}
                </dl>
              </div>
            </div>
          </article>
        )}

        {/* Grid of Parent & Student Testimonials */}
        <div
          data-testid="testimonials-grid"
          dir={dir}
          lang={lang}
          className={`mt-6 grid grid-cols-1 gap-6 ${
            secondaryItems.length === 2 ? 'md:grid-cols-2' : 'md:grid-cols-2 lg:grid-cols-3'
          } ${lang === 'ar' ? 'font-arabic text-right' : ''}`}
        >
          {secondaryItems.map((item) => (
            <article
              key={item.id}
              data-testid="testimonial-card"
              className="p-6 bg-[#FAF8F4] border border-[#DCD5C7] rounded-lg flex flex-col justify-between gap-5"
            >
              <div>
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-medium text-[#8E6210]">
                  <span>
                    {item.authorType === 'Parent' ? copy.parentRoleTag : copy.studentRoleTag}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="text-[#5B665F]">{item.wingLabelByLang[lang]}</span>
                </div>

                <blockquote className="mt-3 text-sm sm:text-[15px] leading-relaxed text-[#2D3631]">
                  “{item.quoteByLang[lang]}”
                </blockquote>
              </div>

              <div className="pt-4 border-t border-[#EFECE4] space-y-2">
                <div className="text-xs font-medium text-[#234232]">{item.outcomeByLang[lang]}</div>
                <div>
                  <div className="text-sm font-semibold text-[#182E23]">{item.nameByLang[lang]}</div>
                  <div className="text-xs text-[#5B665F]">{item.roleByLang[lang]}</div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

import { useDescriptionLanguage } from '../context/LanguageContext';
import { HISTORY_MILESTONES, HISTORY_OVERVIEW, INSTITUTION_CONTACT } from '../data/schoolData';
import { DescriptionTranslateBar } from './DescriptionTranslateBar';

const HISTORY_SUB_COPY = {
  bn: {
    foundedLabel: 'প্রতিষ্ঠাকাল:',
    milestonesSubtitle: 'প্রতিষ্ঠাকালীন সনদ থেকে চার-বিভাগীয় আধুনিক একাডেমিক কমপ্লেক্স পর্যন্ত অগ্রযাত্রা',
  },
  en: {
    foundedLabel: 'Founded:',
    milestonesSubtitle: 'Key stages from founding charter to four-wing academic complex',
  },
  ar: {
    foundedLabel: 'تاريخ التأسيس:',
    milestonesSubtitle: 'المراحل الرئيسية من التأسيس إلى المجمع التعليمي المتكامل بأقسامه الأربعة',
  },
};

export function HistorySection() {
  const { lang, dir } = useDescriptionLanguage();
  const subCopy = HISTORY_SUB_COPY[lang];

  return (
    <section id="history" className="py-16 lg:py-20 border-b border-[#E5DFD2] bg-white">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        <div className="mb-8">
          <DescriptionTranslateBar compact />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          {/* Founding Narrative & Commitment (6 cols) */}
          <div className="lg:col-span-6 space-y-5">
            <p className="text-xs font-medium tracking-wide text-[#8E6210]">
              ০৩. প্রতিষ্ঠানের ইতিহাস · Institutional History ·{' '}
              <span dir="rtl" lang="ar" className="font-arabic">
                تاريخ المؤسسة
              </span>
            </p>
            <h2 className="font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-[#14231B] text-balance">
              গাজীপুরে শিকড়, দ্বীনি ও আধুনিক শিক্ষায় উৎকর্ষের অঙ্গীকার
            </h2>
            <p className="text-sm font-medium text-[#2D4C3B]">
              Rooted in Gazipur, Built for Sacred &amp; Modern Excellence ·{' '}
              <span dir="rtl" lang="ar" className="font-arabic font-semibold text-[#8E6210]">
                جذور راسخة في غازي بور للجمع بين العلم الشرعي والتميز الحديث
              </span>
            </p>

            <div
              dir={dir}
              className={`flex flex-wrap items-center gap-x-3 gap-y-1 text-xs font-mono text-[#5B665F] tabular-nums pt-1 ${
                lang === 'ar' ? 'font-arabic' : ''
              }`}
            >
              <span>
                {subCopy.foundedLabel} {HISTORY_OVERVIEW.foundingDateByLang[lang]}
              </span>
              <span aria-hidden="true">·</span>
              <span>{INSTITUTION_CONTACT.addressByLang[lang]}</span>
            </div>

            <div
              dir={dir}
              lang={lang}
              className={`pt-4 border-t border-[#DCD5C7] space-y-4 text-[15.5px] leading-[1.8] text-[#354039] max-w-[65ch] ${
                lang === 'ar' ? 'font-arabic text-right' : ''
              }`}
            >
              {HISTORY_OVERVIEW.paragraphsByLang[lang].map((paragraph, idx) => (
                <p key={idx}>{paragraph}</p>
              ))}
            </div>

            <div className="pt-4 border-t border-[#DCD5C7]">
              <h3 className="font-serif text-xl font-semibold text-[#182E23]">
                ইসলামী শিক্ষা ও একাডেমিক উৎকর্ষে আমাদের অঙ্গীকার
              </h3>
              <p className="mt-0.5 text-xs font-medium text-[#2D4C3B]">
                Commitment to Islamic Education &amp; Academic Excellence ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic text-[#8E6210]">
                  الالتزام بالتعليم الإسلامي والتميز الأكاديمي
                </span>
              </p>
              <ul
                dir={dir}
                lang={lang}
                className={`mt-3 space-y-2.5 text-sm leading-relaxed text-[#434E47] list-disc list-inside ${
                  lang === 'ar' ? 'font-arabic text-right' : ''
                }`}
              >
                {HISTORY_OVERVIEW.commitmentsByLang[lang].map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            </div>
          </div>

          {/* Vision, Mission & Milestones (6 cols) */}
          <div className="lg:col-span-6 space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <article className="p-6 bg-[#FAF8F4] border border-[#DCD5C7] rounded-lg">
                <div className="text-xs font-medium tracking-wide text-[#8E6210]">
                  আমাদের লক্ষ্য · Our Vision ·{' '}
                  <span dir="rtl" lang="ar" className="font-arabic">
                    رؤيتنا
                  </span>
                </div>
                <h3 className="mt-1.5 font-serif text-xl font-semibold text-[#182E23]">
                  আদর্শ আলেম ও যোগ্য নেতৃত্ব
                </h3>
                <p
                  dir={dir}
                  lang={lang}
                  className={`mt-2.5 text-sm leading-relaxed text-[#434E47] ${
                    lang === 'ar' ? 'font-arabic text-right' : ''
                  }`}
                >
                  {HISTORY_OVERVIEW.visionByLang[lang]}
                </p>
              </article>

              <article className="p-6 bg-[#FAF8F4] border border-[#DCD5C7] rounded-lg">
                <div className="text-xs font-medium tracking-wide text-[#8E6210]">
                  আমাদের উদ্দেশ্য · Our Mission ·{' '}
                  <span dir="rtl" lang="ar" className="font-arabic">
                    رسالتنا
                  </span>
                </div>
                <h3 className="mt-1.5 font-serif text-xl font-semibold text-[#182E23]">
                  চার-বিভাগীয় সমন্বিত পাঠদান
                </h3>
                <p
                  dir={dir}
                  lang={lang}
                  className={`mt-2.5 text-sm leading-relaxed text-[#434E47] ${
                    lang === 'ar' ? 'font-arabic text-right' : ''
                  }`}
                >
                  {HISTORY_OVERVIEW.missionByLang[lang]}
                </p>
              </article>
            </div>

            {/* Institutional Expansion Timeline */}
            <div className="p-6 bg-[#FAF8F4] border border-[#DCD5C7] rounded-lg">
              <div className="pb-3 border-b border-[#E5DFD2]">
                <h3 className="font-serif text-2xl font-semibold text-[#182E23]">
                  উল্লেখযোগ্য অর্জন ও সম্প্রসারণের মাইলফলক
                </h3>
                <p className="mt-0.5 text-xs font-medium text-[#2D4C3B]">
                  Milestones &amp; Institutional Expansion ·{' '}
                  <span dir="rtl" lang="ar" className="font-arabic text-[#8E6210]">
                    الإنجازات ومراحل التوسع
                  </span>
                </p>
                <p
                  dir={dir}
                  lang={lang}
                  className={`mt-1 text-xs text-[#5B665F] ${
                    lang === 'ar' ? 'font-arabic text-right' : ''
                  }`}
                >
                  {subCopy.milestonesSubtitle}
                </p>
              </div>

              <ol className="mt-4 divide-y divide-[#EFECE4]">
                {HISTORY_MILESTONES.map((milestone) => (
                  <li key={milestone.period} className="py-3.5 first:pt-1 last:pb-1">
                    <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
                      <h4 className="font-serif text-lg font-semibold text-[#182E23]">{milestone.title}</h4>
                      <span className="font-mono text-xs font-medium text-[#8E6210] tabular-nums whitespace-nowrap shrink-0">
                        {milestone.periodByLang[lang]}
                      </span>
                    </div>
                    <p className="mt-0.5 text-xs font-medium text-[#2D4C3B]">
                      {milestone.titleEn} ·{' '}
                      <span dir="rtl" lang="ar" className="font-arabic text-[#8E6210]">
                        {milestone.titleAr}
                      </span>
                    </p>
                    <p
                      dir={dir}
                      lang={lang}
                      className={`mt-1.5 text-sm leading-relaxed text-[#4B564F] ${
                        lang === 'ar' ? 'font-arabic text-right' : ''
                      }`}
                    >
                      {milestone.summaryByLang[lang]}
                    </p>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

import { useEffect, useState } from 'react';
import { Search, X } from 'lucide-react';
import { useDescriptionLanguage } from '../context/LanguageContext';
import {
  ACADEMIC_CALENDAR,
  DAILY_SCHEDULE,
  OFFICIAL_NOTICES,
  type NoticeItem,
} from '../data/schoolData';
import { filterNotices } from '../utils/admissions';

const NOTICES_COPY = {
  bn: {
    categories: {
      All: 'সকল নোটিশ',
      Admissions: 'ভর্তি',
      Examinations: 'পরীক্ষা',
      Events: 'অনুষ্ঠান',
    },
    searchAria: 'নোটিশ খুঁজুন',
    searchPlaceholder: 'বিজ্ঞপ্তি অনুসন্ধান...',
    emptyTitle: 'কোনো মিলযুক্ত বিজ্ঞপ্তি পাওয়া যায়নি',
    emptyReset: 'সকল বিজ্ঞপ্তি দেখুন',
    readMore: 'পূর্ণাঙ্গ বিজ্ঞপ্তি পড়ুন',
    scheduleSubtitle: 'প্রাত্যহিক পাঠদান সূচি ও জামাতসহ নামাজের বিরতি',
    modalNoticeSuffix: 'সংক্রান্ত বিজ্ঞপ্তি',
    modalIssuedBy: 'প্রচারে',
    modalCloseAria: 'নোটিশ উইন্ডো বন্ধ করুন',
    modalCloseButton: 'বন্ধ করুন',
  },
  en: {
    categories: {
      All: 'All',
      Admissions: 'Admissions',
      Examinations: 'Examinations',
      Events: 'Events',
    },
    searchAria: 'Search notices',
    searchPlaceholder: 'Search notices...',
    emptyTitle: 'No matching notices found',
    emptyReset: 'Show all notices',
    readMore: 'Read full notice',
    scheduleSubtitle: 'Daily academic timetable & prayer observances',
    modalNoticeSuffix: 'Notice',
    modalIssuedBy: 'Issued by',
    modalCloseAria: 'Close notice dialog',
    modalCloseButton: 'Close',
  },
  ar: {
    categories: {
      All: 'جميع الإعلانات',
      Admissions: 'القبول',
      Examinations: 'الاختبارات',
      Events: 'الفعاليات',
    },
    searchAria: 'البحث في الإعلانات',
    searchPlaceholder: 'ابحث في الإعلانات...',
    emptyTitle: 'لم يتم العثور على إعلانات مطابقة',
    emptyReset: 'عرض جميع الإعلانات',
    readMore: 'قراءة الإعلان كاملاً',
    scheduleSubtitle: 'الجدول اليومي للدراسة وأوقات الصلاة جماعة',
    modalNoticeSuffix: 'إعلان',
    modalIssuedBy: 'صادر عن',
    modalCloseAria: 'إغلاق نافذة الإعلان',
    modalCloseButton: 'إغلاق',
  },
};

const CATEGORY_KEYS: Array<'All' | NoticeItem['category']> = [
  'All',
  'Admissions',
  'Examinations',
  'Events',
];

export function NoticesScheduleSection() {
  const { lang, dir } = useDescriptionLanguage();
  const copy = NOTICES_COPY[lang];
  const [category, setCategory] = useState<'All' | NoticeItem['category']>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedNotice, setSelectedNotice] = useState<NoticeItem | null>(null);

  const visibleNotices = filterNotices(OFFICIAL_NOTICES, category, searchQuery);

  useEffect(() => {
    if (!selectedNotice) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedNotice(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedNotice]);

  return (
    <section id="notices" className="py-16 lg:py-20 border-b border-[#E5DFD2] bg-[#FAF8F4]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          {/* Official Notice Board (7 cols) */}
          <div className="lg:col-span-7">
            <p className="text-xs font-medium tracking-wide text-[#8E6210]">
              ০৬. অফিশিয়াল নোটিশ ও বিজ্ঞপ্তি · Official Bulletins ·{' '}
              <span dir="rtl" lang="ar" className="font-arabic">
                النشرات الرسمية
              </span>
            </p>
            <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-[#14231B]">
              নোটিশ বোর্ড
            </h2>
            <p className="mt-1 text-sm font-medium text-[#2D4C3B]">
              Notice Board ·{' '}
              <span dir="rtl" lang="ar" className="font-arabic font-semibold text-[#8E6210]">
                لوحة الإعلانات
              </span>
            </p>

            <div className="mt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex flex-wrap gap-2" role="group" aria-label="বিষয় অনুযায়ী নোটিশ ফিল্টার">
                {CATEGORY_KEYS.map((catKey) => {
                  const isActive = catKey === category;
                  return (
                    <button
                      key={catKey}
                      type="button"
                      onClick={() => setCategory(catKey)}
                      aria-pressed={isActive}
                      className={`px-3.5 py-1.5 text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#234232] ${
                        isActive
                          ? 'bg-[#234232] text-white'
                          : 'bg-white border border-[#DCD5C7] text-[#354039] hover:border-[#234232]'
                      }`}
                    >
                      {copy.categories[catKey]}
                    </button>
                  );
                })}
              </div>

              <div className="relative sm:w-56">
                <label htmlFor="notice-search" className="sr-only">
                  {copy.searchAria}
                </label>
                <Search
                  className="w-4 h-4 text-[#6B766F] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                  aria-hidden="true"
                />
                <input
                  id="notice-search"
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={copy.searchPlaceholder}
                  className="w-full pl-9 pr-3 py-1.5 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] placeholder:text-[#6B766F] focus:outline-2 focus:outline-[#234232]"
                />
              </div>
            </div>

            {visibleNotices.length === 0 ? (
              <div
                dir={dir}
                lang={lang}
                className={`mt-6 p-8 text-center border border-[#DCD5C7] rounded-lg bg-white ${
                  lang === 'ar' ? 'font-arabic' : ''
                }`}
              >
                <p className="font-serif text-lg font-semibold text-[#182E23]">{copy.emptyTitle}</p>
                <button
                  type="button"
                  onClick={() => {
                    setCategory('All');
                    setSearchQuery('');
                  }}
                  className="mt-3 px-4 py-1.5 text-sm font-medium text-white bg-[#234232] rounded-md hover:bg-[#182E23] cursor-pointer"
                >
                  {copy.emptyReset}
                </button>
              </div>
            ) : (
              <div className="mt-6 divide-y divide-[#DCD5C7] border-y border-[#DCD5C7] bg-white rounded-lg overflow-hidden">
                {visibleNotices.map((notice) => (
                  <article key={notice.id} className="p-5 hover:bg-[#FAF8F4]/70 transition-colors">
                    <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-[#5B665F] tabular-nums">
                      <span className="font-medium text-[#8E6210]">
                        {notice.categoryLabelByLang[lang]}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">{notice.refNumber}</span>
                      <span aria-hidden="true">·</span>
                      <time dateTime={notice.publishedAt}>{notice.publishedAt}</time>
                    </div>
                    <h3 className="mt-1.5 font-serif text-xl font-semibold text-[#182E23]">
                      <button
                        type="button"
                        onClick={() => setSelectedNotice(notice)}
                        className="text-left hover:text-[#234232] hover:underline underline-offset-4 decoration-[#C5932A] cursor-pointer focus-visible:outline-2 focus-visible:outline-[#234232]"
                      >
                        {notice.title}
                      </button>
                    </h3>
                    <p className="mt-0.5 text-xs font-medium text-[#2D4C3B]">
                      {notice.titleEn} ·{' '}
                      <span dir="rtl" lang="ar" className="font-arabic text-[#8E6210]">
                        {notice.titleAr}
                      </span>
                    </p>
                    <p
                      dir={dir}
                      lang={lang}
                      className={`mt-2 text-sm leading-relaxed text-[#434E47] ${
                        lang === 'ar' ? 'font-arabic text-right' : ''
                      }`}
                    >
                      {notice.excerptByLang[lang]}
                    </p>
                    <div className={`mt-3 ${lang === 'ar' ? 'text-right' : ''}`}>
                      <button
                        type="button"
                        onClick={() => setSelectedNotice(notice)}
                        className="text-xs font-semibold text-[#234232] hover:text-[#8E6210] underline underline-offset-4 cursor-pointer"
                      >
                        {copy.readMore}
                      </button>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </div>

          {/* Daily Timetable & Academic Calendar (5 cols) */}
          <div className="lg:col-span-5 space-y-8">
            <div className="bg-white border border-[#DCD5C7] rounded-lg p-6">
              <h3 className="font-serif text-2xl font-semibold text-[#182E23]">দৈনন্দিন ক্যাম্পাস সময়সূচি</h3>
              <p className="mt-0.5 text-xs font-medium text-[#2D4C3B]">
                Daily Campus Rhythm ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic text-[#8E6210]">
                  الجدول اليومي للحرم الدراسي
                </span>
              </p>
              <p
                dir={dir}
                lang={lang}
                className={`mt-1 text-xs text-[#5B665F] ${lang === 'ar' ? 'font-arabic text-right' : ''}`}
              >
                {copy.scheduleSubtitle}
              </p>

              <div className="mt-4 divide-y divide-[#E5DFD2]">
                {DAILY_SCHEDULE.map((row) => (
                  <div
                    key={row.period}
                    dir={dir}
                    lang={lang}
                    className={`py-2.5 flex items-start justify-between gap-4 text-sm ${
                      lang === 'ar' ? 'font-arabic text-right' : ''
                    }`}
                  >
                    <div>
                      <div className="font-medium text-[#1A1F1C]">{row.activityByLang[lang]}</div>
                      <div className="text-xs text-[#5B665F]">{row.notesByLang[lang]}</div>
                    </div>
                    <div
                      dir="ltr"
                      className="font-mono text-xs text-[#234232] tabular-nums whitespace-nowrap shrink-0 pt-0.5"
                    >
                      {row.timeRange}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white border border-[#DCD5C7] rounded-lg p-6">
              <h3 className="font-serif text-2xl font-semibold text-[#182E23]">গুরুত্বপূর্ণ তারিখ · ২০২৬–২০২৭</h3>
              <p className="mt-0.5 text-xs font-medium text-[#2D4C3B]">
                Key Academic Dates ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic text-[#8E6210]">
                  التواريخ الأكاديمية المهمة
                </span>
              </p>
              <div className="mt-4 divide-y divide-[#E5DFD2]">
                {ACADEMIC_CALENDAR.map((item) => (
                  <div
                    key={item.date + item.title}
                    dir={dir}
                    lang={lang}
                    className={`py-2.5 flex items-start justify-between gap-4 text-sm ${
                      lang === 'ar' ? 'font-arabic text-right' : ''
                    }`}
                  >
                    <div>
                      <div className="font-medium text-[#1A1F1C]">{item.titleByLang[lang]}</div>
                      <div className="text-xs text-[#5B665F]">{item.divisionScopeByLang[lang]}</div>
                    </div>
                    <time
                      dir="ltr"
                      dateTime={item.date}
                      className="font-mono text-xs font-medium text-[#8E6210] tabular-nums whitespace-nowrap shrink-0 pt-0.5"
                    >
                      {item.date}
                    </time>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Accessible Notice Detail Modal */}
      {selectedNotice && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="notice-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#14231B]/60 backdrop-blur-[2px]"
          onClick={(e) => {
            if (e.target === e.currentTarget) setSelectedNotice(null);
          }}
        >
          <div className="w-full max-w-2xl bg-[#FAF8F4] border border-[#DCD5C7] rounded-lg shadow-xl overflow-hidden">
            <div className="px-6 py-4 bg-white border-b border-[#E5DFD2] flex items-center justify-between gap-4">
              <div className="text-xs font-mono text-[#5B665F] tabular-nums">
                {selectedNotice.refNumber} · {selectedNotice.publishedAt}
              </div>
              <button
                type="button"
                onClick={() => setSelectedNotice(null)}
                aria-label={copy.modalCloseAria}
                className="w-9 h-9 inline-flex items-center justify-center rounded-md text-[#354039] hover:bg-[#EFECE4] cursor-pointer focus-visible:outline-2 focus-visible:outline-[#234232]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
              <div
                dir={dir}
                lang={lang}
                className={`text-xs font-medium tracking-wide text-[#8E6210] ${
                  lang === 'ar' ? 'font-arabic text-right' : ''
                }`}
              >
                {selectedNotice.categoryLabelByLang[lang]} {copy.modalNoticeSuffix}
              </div>
              <h3 id="notice-modal-title" className="font-serif text-2xl sm:text-3xl font-semibold text-[#182E23]">
                {selectedNotice.title}
              </h3>
              <p className="text-xs font-medium text-[#2D4C3B]">
                {selectedNotice.titleEn} ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic text-[#8E6210]">
                  {selectedNotice.titleAr}
                </span>
              </p>

              <div
                dir={dir}
                lang={lang}
                className={`pt-3 border-t border-[#E5DFD2] space-y-3 text-[15px] leading-relaxed text-[#354039] ${
                  lang === 'ar' ? 'font-arabic text-right' : ''
                }`}
              >
                {selectedNotice.bodyByLang[lang].map((paragraph, idx) => (
                  <p key={idx}>{paragraph}</p>
                ))}
              </div>

              <div
                dir={dir}
                lang={lang}
                className={`pt-4 border-t border-[#E5DFD2] flex flex-wrap items-center justify-between gap-4 text-xs text-[#5B665F] ${
                  lang === 'ar' ? 'font-arabic' : ''
                }`}
              >
                <span>
                  {copy.modalIssuedBy}: {selectedNotice.issuedByByLang[lang]}
                </span>
                <button
                  type="button"
                  onClick={() => setSelectedNotice(null)}
                  className="px-4 py-2 text-sm font-medium text-white bg-[#234232] hover:bg-[#182E23] rounded-md cursor-pointer"
                >
                  {copy.modalCloseButton}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

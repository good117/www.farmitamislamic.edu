import { useState } from 'react';
import { Search } from 'lucide-react';
import { useDescriptionLanguage } from '../context/LanguageContext';
import {
  CAMPUS_GALLERY_FIGURES,
  FACULTY_MEMBERS,
  INSTITUTION_CONTACT,
  type FacultyMember,
} from '../data/schoolData';
import { filterFaculty } from '../utils/admissions';
import { ResilientImage } from './ResilientImage';

const LEADERSHIP_COPY = {
  bn: {
    paragraphs: [
      'FARMITAM Islamic School & College-এ আমাদের শিক্ষা সংস্কৃতি গড়ে উঠেছে প্রতিদিনের ব্যক্তিগত মেন্টরশিপ ও নিবিড় তত্ত্বাবধানের ওপর। কোনো শিক্ষার্থী নূরানী (কায়েদা, আমপারা ও কুরআন) অথবা প্লে-গ্রুপ দিয়ে শুরু করুক, জেনারেল (প্লে–দশম) শাখায় অগ্রসর হোক, দুই বছর মেয়াদী ক্যাডেট প্রোগ্রামে প্রশিক্ষণ নিক, কিংবা হিফজুল কুরআন বিভাগে পবিত্র কুরআন মুখস্থ করুক—প্রত্যেকেই পায় শিক্ষকের একান্ত মনোযোগ।',
      'কোনাবাড়ী ক্যাম্পাসে কনিষ্ঠ (প্লে থেকে পঞ্চম) ও জ্যেষ্ঠ (ষষ্ঠ থেকে দশম ও ক্যাডেট) শিক্ষার্থীদের বয়সোপযোগী আনন্দময় শ্রেণিকক্ষ, শান্ত কুরআন শিক্ষাকক্ষ, সমৃদ্ধ কেন্দ্রীয় পাঠাগার এবং আধুনিক বিজ্ঞান গবেষণাগারের সমন্বয়ে গড়ে উঠেছে সুশৃঙ্খল শিক্ষা পরিবেশ।',
    ],
    principalCredentials: `অধ্যক্ষ, ${INSTITUTION_CONTACT.bnName} · পিএইচডি, আল-আজহার বিশ্ববিদ্যালয়`,
    quote:
      '“উপকারী জ্ঞান অর্জন করো যা ইহকাল ও পরকাল উভয়কেই আলোকিত করে—পদ্ধতিতে সুশৃঙ্খল, চরিত্রে বিনয়ী এবং মানবতার সেবায় অবিচল।”',
    quoteFooter: 'প্রতিষ্ঠাকালীন প্রাতিষ্ঠানিক আদর্শ · ফারমিটম একাডেমিক সিন্ডিকেট, ২০২৬',
    searchPlaceholder: 'শিক্ষকের নাম বা বিষয় লিখুন...',
    searchAria: 'নাম বা বিষয় অনুযায়ী শিক্ষক খুঁজুন',
    departments: {
      All: 'সকল বিভাগ',
      'Islamic Studies': 'ইসলামিক স্টাডিজ',
      Sciences: 'বিজ্ঞান বিভাগ',
      Languages: 'ভাষা বিভাগ',
      Humanities: 'মানবিক বিভাগ',
    },
    emptyTitle: 'কোনো শিক্ষকের তথ্য পাওয়া যায়নি',
    emptySubtitle: 'সকল শিক্ষকের তালিকা দেখতে বিভাগ বা অনুসন্ধান শব্দ পরিবর্তন করুন।',
    resetFilter: 'ফিল্টার রিসেট করুন',
    officeHoursLabel: 'অফিস সময়',
  },
  en: {
    paragraphs: [
      'At FARMITAM Islamic School & College, our educational culture is built on daily personal mentorship and attentive guidance. Whether a child enters Playgroup and Noorani (Quyeda, Ampar and Quran), progresses through General (Play to Ten), trains in the Two-Year Cadet Program, or memorizes the Quran in Hifzul Quran, every learner receives dedicated faculty attention.',
      'Across our Konabari campus, tailored age-appropriate classrooms for younger learners (Play to Primary) sit alongside senior high-school and Cadet study courtyards (Classes VI–X), quiet Quranic circles, our central reading hall, and modern STEM laboratories.',
    ],
    principalCredentials: `Principal, ${INSTITUTION_CONTACT.name} · PhD, Al-Azhar University`,
    quote:
      '“Seek beneficial knowledge that illuminates both this world and the hereafter—disciplined in method, humble in character, and steadfast in service to humanity.”',
    quoteFooter: 'Founding Institutional Charter · FARMITAM Academic Syndicate, 2026',
    searchPlaceholder: 'Search faculty by name or subject...',
    searchAria: 'Search faculty by name or subject',
    departments: {
      All: 'All Departments',
      'Islamic Studies': 'Islamic Studies',
      Sciences: 'Sciences',
      Languages: 'Languages',
      Humanities: 'Humanities',
    },
    emptyTitle: 'No matching faculty found',
    emptySubtitle: 'Clear your department filter or search term to view all educators.',
    resetFilter: 'Reset filters',
    officeHoursLabel: 'Office hours',
  },
  ar: {
    paragraphs: [
      'تقوم ثقافتنا التعليمية في مدرسة وكلية فارميتام الإسلامية على التوجيه الشخصي اليومي والرعاية الدقيقة؛ فسواء بدأ الطالب في مرحلة الروضة والنوراني (القاعدة وعمّ والقرآن)، أو واصل في القسم العام حتى الصف العاشر، أو التحق ببرنامج الكاديت لمدة سنتين، أو تفرغ لتحفيظ القرآن الكريم، فإنه ينال عناية تربوية متخصصة.',
      'يضم حرمنا الدراسي في كوناباري فصولاً مخصصة للصغار (من الروضة إلى الخامس) بأسلوب تعليمي محبب، إلى جانب ساحات دراسية منظمة لطلاب المرحلة العليا والكاديت (السادس إلى العاشر)، وحلقات القرآن، والمكتبة المركزية، والمختبرات العلمية الحديثة.',
    ],
    principalCredentials: `مدير ${INSTITUTION_CONTACT.arName} · دكتوراه، جامعة الأزهر`,
    quote:
      '«اطلب العلم النافع الذي ينير الدنيا والآخرة — منضبطاً في المنهج، متواضعاً في الخُلُق، ثابتاً في خدمة الإنسان.»',
    quoteFooter: 'الميثاق التأسيسي للمؤسسة · مجلس فارميتام الأكاديمي ٢٠٢٦',
    searchPlaceholder: 'ابحث عن أستاذ أو مادة...',
    searchAria: 'البحث عن الأساتذة حسب الاسم أو التخصص',
    departments: {
      All: 'جميع التخصصات',
      'Islamic Studies': 'الدراسات الإسلامية',
      Sciences: 'العلوم',
      Languages: 'اللغات',
      Humanities: 'الإنسانيات',
    },
    emptyTitle: 'لم يتم العثور على أساتذة مطابقين',
    emptySubtitle: 'قم بتعديل القسم أو كلمة البحث لعرض جميع أعضاء هيئة التدريس.',
    resetFilter: 'إعادة تعيين التصفية',
    officeHoursLabel: 'الساعات المكتبية',
  },
};

const DEPARTMENT_KEYS: Array<'All' | FacultyMember['department']> = [
  'All',
  'Islamic Studies',
  'Sciences',
  'Languages',
  'Humanities',
];

export function LeadershipFacultySection() {
  const { lang, dir } = useDescriptionLanguage();
  const copy = LEADERSHIP_COPY[lang];
  const [department, setDepartment] = useState<'All' | FacultyMember['department']>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const visibleFaculty = filterFaculty(FACULTY_MEMBERS, department, searchQuery);

  return (
    <>
      {/* Leadership & Campus Student Environments */}
      <section id="leadership" className="py-16 lg:py-20 border-b border-[#E5DFD2] bg-[#FAF8F4]">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
            {/* Principal's Editorial Address & Quote (5 cols) */}
            <div className="lg:col-span-5 space-y-5">
              <p className="text-xs font-medium tracking-wide text-[#8E6210]">
                ০৪. নেতৃত্ব, শিক্ষার্থী ও ক্যাম্পাস পরিবেশ · Campus &amp; Students ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic">
                  القيادة وبيئة الطلاب
                </span>
              </p>
              <h2 className="font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-[#14231B] text-balance">
                আত্মিক শুদ্ধতা ও মেধার সমন্বিত বিকাশ
              </h2>
              <p className="text-sm font-medium text-[#2D4C3B]">
                Educating the Mind Without Neglecting the Soul ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic font-semibold text-[#8E6210]">
                  تربية العقول وتزكية النفوس
                </span>
              </p>

              <div
                dir={dir}
                lang={lang}
                className={`pt-4 border-t border-[#DCD5C7] space-y-4 text-[15.5px] leading-[1.8] text-[#354039] max-w-[65ch] ${
                  lang === 'ar' ? 'font-arabic text-right' : ''
                }`}
              >
                {copy.paragraphs.map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>

              <div className="pt-4 border-t border-[#DCD5C7] space-y-0.5">
                <p className="font-serif text-lg font-semibold text-[#182E23]">মাওলানা ড. তারিকুল ইসলাম</p>
                <p className="text-xs font-medium text-[#2D4C3B]">
                  Mawlana Dr. Tariqul Islam ·{' '}
                  <span dir="rtl" lang="ar" className="font-arabic text-[#8E6210]">
                    مولانا الدكتور طارق الإسلام
                  </span>
                </p>
                <p
                  dir={dir}
                  lang={lang}
                  className={`text-xs text-[#5B665F] pt-0.5 ${lang === 'ar' ? 'font-arabic text-right' : ''}`}
                >
                  {copy.principalCredentials}
                </p>
              </div>

              <blockquote
                dir={dir}
                lang={lang}
                className={`py-5 border-y border-[#DCD5C7] ${lang === 'ar' ? 'font-arabic text-right' : ''}`}
              >
                <p className="font-serif text-lg sm:text-xl italic leading-snug text-[#182E23]">
                  {copy.quote}
                </p>
                <footer className="mt-2 text-xs text-[#5B665F]">{copy.quoteFooter}</footer>
              </blockquote>
            </div>

            {/* Junior & Senior Students + Campus Environment Gallery (7 cols) */}
            <div className="lg:col-span-7">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6" data-testid="student-environment-gallery">
                {CAMPUS_GALLERY_FIGURES.map((fig) => (
                  <figure key={fig.id} className="flex flex-col">
                    <div className="aspect-[4/3] rounded-lg overflow-hidden border border-[#DCD5C7] bg-[#EFECE4]">
                      <ResilientImage
                        src={fig.src}
                        alt={fig.altByLang[lang]}
                        className="w-full h-full object-cover"
                        fallbackTitle={fig.fallbackTitle}
                      />
                    </div>
                    <figcaption
                      dir={dir}
                      lang={lang}
                      className={`mt-2.5 text-xs font-serif italic text-[#5B665F] ${
                        lang === 'ar' ? 'font-arabic text-right not-italic' : ''
                      }`}
                    >
                      {fig.captionByLang[lang]}
                    </figcaption>
                  </figure>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Faculty & Scholars Directory */}
      <section id="faculty" className="py-16 lg:py-20 border-b border-[#E5DFD2] bg-white">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-[#E5DFD2]">
            <div>
              <p className="text-xs font-medium tracking-wide text-[#8E6210]">
                ০৫. অভিজ্ঞ শিক্ষকমণ্ডলী · Scholars &amp; Educators ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic">
                  الأساتذة والعلماء
                </span>
              </p>
              <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-[#14231B]">
                শিক্ষকমণ্ডলীর পরিচিতি
              </h2>
              <p className="mt-1 text-sm font-medium text-[#2D4C3B]">
                Faculty Directory ·{' '}
                <span dir="rtl" lang="ar" className="font-arabic font-semibold text-[#8E6210]">
                  هيئة التدريس
                </span>
              </p>
            </div>

            <div className="w-full md:w-72 relative">
              <label htmlFor="faculty-search" className="sr-only">
                {copy.searchAria}
              </label>
              <Search
                className="w-4 h-4 text-[#6B766F] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                id="faculty-search"
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={copy.searchPlaceholder}
                className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-[#DCD5C7] rounded-md text-[#1A1F1C] placeholder:text-[#6B766F] focus:outline-2 focus:outline-[#234232]"
              />
            </div>
          </div>

          {/* Department Filter Buttons */}
          <div
            className="mt-6 flex flex-wrap gap-2"
            role="group"
            aria-label="বিভাগ অনুযায়ী শিক্ষক ফিল্টার করুন"
          >
            {DEPARTMENT_KEYS.map((deptKey) => {
              const isSelected = deptKey === department;
              return (
                <button
                  key={deptKey}
                  type="button"
                  onClick={() => setDepartment(deptKey)}
                  aria-pressed={isSelected}
                  className={`px-3.5 py-1.5 text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#234232] ${
                    isSelected
                      ? 'bg-[#234232] text-white'
                      : 'bg-[#F5F2EB] text-[#354039] hover:bg-[#E9E3D5]'
                  }`}
                >
                  {copy.departments[deptKey]}
                </button>
              );
            })}
          </div>

          {/* Faculty Grid */}
          {visibleFaculty.length === 0 ? (
            <div
              dir={dir}
              lang={lang}
              className={`mt-8 py-12 px-6 text-center border border-[#E5DFD2] rounded-lg bg-[#FAF8F4] ${
                lang === 'ar' ? 'font-arabic' : ''
              }`}
            >
              <p className="font-serif text-xl font-semibold text-[#182E23]">{copy.emptyTitle}</p>
              <p className="mt-1 text-sm text-[#5B665F]">{copy.emptySubtitle}</p>
              <button
                type="button"
                onClick={() => {
                  setDepartment('All');
                  setSearchQuery('');
                }}
                className="mt-4 px-4 py-2 text-sm font-medium text-white bg-[#234232] rounded-md hover:bg-[#182E23] cursor-pointer"
              >
                {copy.resetFilter}
              </button>
            </div>
          ) : (
            <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {visibleFaculty.map((member) => (
                <article
                  key={member.id}
                  className="p-6 border border-[#DCD5C7] rounded-lg bg-[#FAF8F4] flex flex-col justify-between"
                >
                  <div>
                    <div
                      dir={dir}
                      lang={lang}
                      className={`text-xs font-medium tracking-wide text-[#8E6210] ${
                        lang === 'ar' ? 'font-arabic text-right' : ''
                      }`}
                    >
                      {member.departmentLabelByLang[lang]}
                    </div>
                    <h3 className="mt-1.5 font-serif text-xl font-semibold text-[#182E23]">{member.name}</h3>
                    <p className="mt-0.5 text-xs font-medium text-[#2D4C3B]">{member.nameEn}</p>
                    <p dir="rtl" lang="ar" className="font-arabic text-sm font-semibold text-[#8E6210] text-left">
                      {member.nameAr}
                    </p>
                    <p
                      dir={dir}
                      lang={lang}
                      className={`mt-1.5 text-sm font-medium text-[#2D4C3B] ${
                        lang === 'ar' ? 'font-arabic text-right' : ''
                      }`}
                    >
                      {member.roleByLang[lang]}
                    </p>
                    <p
                      dir={dir}
                      lang={lang}
                      className={`mt-3 text-sm leading-relaxed text-[#434E47] ${
                        lang === 'ar' ? 'font-arabic text-right' : ''
                      }`}
                    >
                      {member.focusByLang[lang]}
                    </p>
                  </div>

                  <div
                    dir={dir}
                    lang={lang}
                    className={`mt-5 pt-4 border-t border-[#E5DFD2] space-y-1 text-xs text-[#5B665F] ${
                      lang === 'ar' ? 'font-arabic text-right' : ''
                    }`}
                  >
                    <div>{member.credentialsByLang[lang]}</div>
                    <div className="font-mono tabular-nums text-[#234232]">
                      {copy.officeHoursLabel}: {member.officeHoursByLang[lang]}
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </section>
    </>
  );
}

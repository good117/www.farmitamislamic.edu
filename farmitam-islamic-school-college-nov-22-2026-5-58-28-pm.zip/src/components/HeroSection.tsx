import { ArrowRight } from 'lucide-react';
import { useDescriptionLanguage } from '../context/LanguageContext';
import {
  ACADEMIC_PROGRAMS,
  HERO_CAMPUS_FIGURE,
  INSTITUTION_CONTACT,
  type DivisionId,
} from '../data/schoolData';
import { DescriptionTranslateBar } from './DescriptionTranslateBar';
import { ResilientImage } from './ResilientImage';

interface HeroSectionProps {
  onApplyClick: () => void;
  onSelectDivision?: (division: DivisionId) => void;
}

const HERO_COPY = {
  bn: {
    sectionsHeading: 'আমাদের চারটি প্রধান শিক্ষা বিভাগ (প্রাথমিক থেকে দশম ও ইসলামিক শাখা)',
    sectionsAction: 'পাঠ্যসূচি ও ফি দেখুন',
    description:
      'গাজীপুরের কোনাবাড়ীতে প্রতিষ্ঠিত আমাদের এই বিদ্যাপীঠে জেনারেল (প্লে থেকে দশম শ্রেণি), ক্যাডেট (দুই বছর মেয়াদী প্রোগ্রাম), নূরানী (কায়েদা, আমপারা ও কুরআন) এবং হিফজুল কুরআন—এই চারটি সমন্বিত বিভাগে পবিত্র কুরআনের শিক্ষা ও আধুনিক একাডেমিক উৎকর্ষ একসাথে প্রদান করা হয়।',
    ctaPrimary: '২০২৬ ভর্তির আবেদন শুরু করুন',
    ctaSecondary: 'একাডেমিক বিভাগসমূহ দেখুন',
    ribbon: [
      { label: 'ক্যাম্পাসের ঠিকানা', value: INSTITUTION_CONTACT.addressByLang.bn },
      {
        label: 'যোগাযোগ ও ইমেইল',
        value: `01824-204543 · ${INSTITUTION_CONTACT.email}`,
      },
      { label: 'শিক্ষা বিভাগসমূহ', value: 'জেনারেল · ক্যাডেট · নূরানী · হিফজুল কুরআন' },
      { label: 'ভর্তি শিক্ষাবর্ষ', value: '২০২৬–২০২৭ · মূল্যায়ন ৫–৬ ডিসেম্বর' },
    ],
  },
  en: {
    sectionsHeading: 'Highlighted Academic Divisions (Playgroup to Class Ten & Islamic Wings)',
    sectionsAction: 'Syllabus & Fees',
    description:
      'Serving Konabari, Gazipur with four integrated divisions—General (Play to Ten), Cadet (Two Years Program), Noorani (Quyeda, Ampar and Quran), and Hifzul Quran—uniting authentic Quranic scholarship with disciplined modern education.',
    ctaPrimary: 'Start 2026 Application',
    ctaSecondary: 'Explore Academic Divisions',
    ribbon: [
      { label: 'Campus Address', value: INSTITUTION_CONTACT.addressByLang.en },
      {
        label: 'Contact & Gmail',
        value: `01824-204543 · ${INSTITUTION_CONTACT.email}`,
      },
      { label: 'Academic Sections', value: 'General · Cadet · Noorani · Hifzul Quran' },
      { label: 'Admissions Session', value: '2026–2027 · Placement Dec 5–6' },
    ],
  },
  ar: {
    sectionsHeading: 'الأقسام الدراسية الأربعة المعتمدة (من الروضة إلى العاشر والعلوم الشرعية)',
    sectionsAction: 'المنهج والرسوم',
    description:
      'تخدم مؤسستنا في كوناباري بغازي بور المجتمع عبر أربعة أقسام متكاملة: القسم العام (من الروضة إلى العاشر)، وقسم الكاديت (برنامج السنتين)، وقسم النوراني (القاعدة وعمّ والقرآن)، وقسم تحفيظ القرآن الكريم، في تكامل فريد بين العلوم الشرعية والتعليم الحديث.',
    ctaPrimary: 'ابدأ طلب الالتحاق ٢٠٢٦',
    ctaSecondary: 'استكشف الأقسام الأكاديمية',
    ribbon: [
      { label: 'عنوان الحرم الدراسي', value: INSTITUTION_CONTACT.addressByLang.ar },
      {
        label: 'التواصل والبريد الإلكتروني',
        value: `01824-204543 · ${INSTITUTION_CONTACT.email}`,
      },
      { label: 'الأقسام التعليمية', value: 'العام · الكاديت · النوراني · تحفيظ القرآن' },
      { label: 'موسم القبول', value: '٢٠٢٦–٢٠٢٧ · الاختبار ٥–٦ ديسمبر' },
    ],
  },
};

export function HeroSection({ onApplyClick, onSelectDivision }: HeroSectionProps) {
  const { lang, dir } = useDescriptionLanguage();
  const copy = HERO_COPY[lang];

  return (
    <section id="top" className="border-b border-[#E5DFD2] bg-[#FAF8F4]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 pt-8 pb-12 lg:pt-10 lg:pb-14">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          {/* Left Editorial Statement with Institution Name & Crest */}
          <div className="lg:col-span-6 flex flex-col justify-between py-1">
            <div>
              <div className="flex items-center gap-4 mb-5">
                <ResilientImage
                  src="/assets/aistudio/download_8c285805.png"
                  alt="ফারমিটম ইসলামিক স্কুল এন্ড কলেজ এর প্রাতিষ্ঠানিক মনোগ্রাম — Knowledge With Faith, Est-2026"
                  className="w-20 h-20 sm:w-24 sm:h-24 object-contain shrink-0"
                  fallbackTitle="FARMITAM Crest"
                />
                <div className="space-y-0.5">
                  <p className="text-xs font-medium tracking-wide text-[#8E6210]">
                    জ্ঞানের সাথে ঈমান · Knowledge With Faith ·{' '}
                    <span dir="rtl" lang="ar" className="font-arabic">
                      العلم مع الإيمان
                    </span>
                  </p>
                  <p className="font-serif text-lg sm:text-xl font-semibold text-[#182E23]">
                    {INSTITUTION_CONTACT.bnName}
                  </p>
                  <p className="text-xs sm:text-[13px] font-medium text-[#2D4C3B]">
                    {INSTITUTION_CONTACT.name} ·{' '}
                    <span dir="rtl" lang="ar" className="font-arabic font-semibold text-[#182E23]">
                      {INSTITUTION_CONTACT.arName}
                    </span>
                  </p>
                </div>
              </div>

              <h1 className="font-serif text-[clamp(1.9rem,3.2vw,3rem)] leading-[1.18] font-semibold tracking-tight text-[#14231B] text-balance">
                দ্বীনি মূল্যবোধ ও আধুনিক শিক্ষার অনন্য সমন্বয়।
              </h1>
              <div className="mt-2.5 space-y-1">
                <p className="font-serif text-lg sm:text-xl font-medium text-[#2D4C3B]">
                  Classical Wisdom, Contemporary Scholarship.
                </p>
                <p dir="rtl" lang="ar" className="font-arabic text-base sm:text-lg font-semibold text-[#8E6210] text-left">
                  الحكمة الإسلامية الأصيلة والعلوم الحديثة المعاصرة
                </p>
              </div>

              <p
                dir={dir}
                lang={lang}
                className={`mt-4 text-base sm:text-[16.5px] leading-[1.75] text-[#434E47] max-w-xl ${
                  lang === 'ar' ? 'font-arabic text-right' : ''
                }`}
              >
                {copy.description}
              </p>
            </div>

            <div className="mt-7 pt-5 border-t border-[#E5DFD2] flex flex-wrap items-center gap-5">
              <button
                type="button"
                onClick={onApplyClick}
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-[#234232] hover:bg-[#182E23] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#234232]"
              >
                <span>{copy.ctaPrimary}</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>

              <a
                href="#academics"
                className="text-sm font-semibold text-[#234232] hover:text-[#8E6210] underline underline-offset-4 decoration-[#C5932A] transition-colors whitespace-nowrap shrink-0 py-2"
              >
                {copy.ctaSecondary}
              </a>
            </div>
          </div>

          {/* Right Architectural Visual */}
          <div className="lg:col-span-6 flex flex-col">
            <figure className="flex-1 flex flex-col">
              <div className="flex-1 min-h-[260px] lg:min-h-[350px] rounded-lg overflow-hidden border border-[#DCD5C7] bg-[#EFECE4]">
                <ResilientImage
                  src={HERO_CAMPUS_FIGURE.src}
                  alt={HERO_CAMPUS_FIGURE.altByLang[lang]}
                  className="w-full h-full lg:h-full object-cover"
                  fallbackTitle={HERO_CAMPUS_FIGURE.fallbackTitle}
                />
              </div>
              <figcaption
                dir={dir}
                lang={lang}
                className={`mt-2.5 text-xs font-serif italic text-[#5B665F] ${
                  lang === 'ar' ? 'font-arabic text-right not-italic' : ''
                }`}
              >
                {HERO_CAMPUS_FIGURE.captionByLang[lang]}
              </figcaption>
            </figure>
          </div>
        </div>

        {/* Highlighted Academic Sections Placed After the School Name */}
        <div className="mt-8 pt-7 border-t border-[#DCD5C7]" data-testid="hero-section-highlights">
          <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1.5 mb-3.5">
            <h2
              dir={dir}
              lang={lang}
              className={`text-xs sm:text-sm font-semibold text-[#182E23] ${
                lang === 'ar' ? 'font-arabic text-right' : ''
              }`}
            >
              {copy.sectionsHeading}
            </h2>
            <p className="text-[11px] font-medium text-[#8E6210]">
              General · Cadet · Noorani · Hifzul Quran ·{' '}
              <span dir="rtl" lang="ar" className="font-arabic">
                الأقسام الدراسية
              </span>
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
            {ACADEMIC_PROGRAMS.map((program) => (
              <button
                key={program.id}
                type="button"
                onClick={() => onSelectDivision?.(program.id)}
                className="group text-left p-4 bg-white border border-[#DCD5C7] hover:border-[#234232] rounded-lg transition-colors flex flex-col justify-between gap-2.5 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#234232]"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 text-[11px] font-mono text-[#8E6210] tabular-nums">
                    <span>{program.code}</span>
                    <span>{program.gradesByLang[lang]}</span>
                  </div>
                  <div className="mt-1.5 font-serif text-base font-semibold text-[#182E23] group-hover:text-[#234232]">
                    {program.bnTitle}
                  </div>
                  <div className="mt-0.5 text-xs font-medium text-[#2D4C3B]">
                    {program.title}
                  </div>
                  <div dir="rtl" lang="ar" className="mt-0.5 font-arabic text-xs font-semibold text-[#8E6210] text-left">
                    {program.arTitle}
                  </div>
                  <p
                    dir={dir}
                    lang={lang}
                    className={`mt-2 text-xs leading-relaxed text-[#4B564F] ${
                      lang === 'ar' ? 'font-arabic text-right' : ''
                    }`}
                  >
                    {program.highlightByLang[lang]}
                  </p>
                </div>

                <div
                  dir={dir}
                  className={`pt-2 border-t border-[#EFECE4] flex items-center justify-between gap-2 text-xs font-semibold text-[#234232] group-hover:text-[#8E6210] ${
                    lang === 'ar' ? 'font-arabic' : ''
                  }`}
                >
                  <span>{program.ageRangeByLang[lang]}</span>
                  <span className="inline-flex items-center gap-1 whitespace-nowrap">
                    <span>{copy.sectionsAction}</span>
                    <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Auto-Translation Switcher for All Descriptions */}
        <div className="mt-6">
          <DescriptionTranslateBar />
        </div>

        {/* Full-Width Operational Utility Ribbon */}
        <div
          dir={dir}
          className={`mt-6 pt-6 border-t border-[#DCD5C7] grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 ${
            lang === 'ar' ? 'font-arabic text-right' : ''
          }`}
        >
          {copy.ribbon.map((item) => (
            <div key={item.label} className="space-y-1">
              <div className="text-xs font-medium text-[#5B665F]">{item.label}</div>
              <div className="text-sm font-semibold text-[#182E23] tabular-nums">{item.value}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

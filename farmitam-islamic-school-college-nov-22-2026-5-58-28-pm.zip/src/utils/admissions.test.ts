import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateTuitionBreakdown,
  filterFaculty,
  filterNotices,
  filterTestimonials,
  generateTrackingId,
  getDivisionWeeklyModes,
  getWeeklyInstructionSchedule,
  validateApplicationForm,
  type ApplicationFormValues,
} from './admissions';
import {
  ACADEMIC_PROGRAMS,
  CAMPUS_GALLERY_FIGURES,
  FACULTY_MEMBERS,
  HERO_CAMPUS_FIGURE,
  INSTITUTION_CONTACT,
  INSTITUTION_FEATURES,
  OFFICIAL_NOTICES,
  TESTIMONIALS,
} from '../data/schoolData';
import {
  detectPreferredLanguage,
  getDirectionForLang,
  resolveDescriptionLang,
} from './i18n';

test('ACADEMIC_PROGRAMS and INSTITUTION_CONTACT include exact Bengali, English, and Arabic names', () => {
  assert.equal(INSTITUTION_CONTACT.bnName, 'ফারমিটম ইসলামিক স্কুল এন্ড কলেজ');
  assert.equal(INSTITUTION_CONTACT.email, 'farmitameducation@gmail.com');
  const titles = ACADEMIC_PROGRAMS.map((p) => p.title);
  assert.deepEqual(titles, [
    'General (Play to Ten)',
    'Cadet (Two Years Program)',
    'Noorani (Quyeda, Ampar and Quran)',
    'Hifzul Quran',
  ]);
  for (const program of ACADEMIC_PROGRAMS) {
    assert.ok(program.bnTitle.length > 0);
    assert.ok(program.arTitle.length > 0);
    assert.equal(program.studentTeacherRatio, '৩০:১');
    assert.deepEqual(program.studentTeacherRatioByLang, { bn: '৩০:১', en: '30:1', ar: '٣٠:١' });
  }
  for (const member of FACULTY_MEMBERS) {
    assert.ok(member.name.length > 0);
    assert.ok(member.nameEn.length > 0);
    assert.ok(member.nameAr.length > 0);
  }
  const cadet = ACADEMIC_PROGRAMS.find((p) => p.id === 'cadet');
  assert.ok(cadet);
  assert.ok(cadet.highlightByLang.bn.includes('বাংলা') && cadet.highlightByLang.bn.includes('সাধারণ জ্ঞান'));
  assert.ok(cadet.highlightByLang.en.includes('Bangla') && cadet.highlightByLang.en.includes('General Knowledge'));
  assert.ok(cadet.modules.some((m) => m.subjectByLang.bn.includes('বাংলা')));
  assert.ok(cadet.modules.some((m) => m.subjectByLang.bn.includes('সাধারণ জ্ঞান')));
});

test('calculateTuitionBreakdown computes all 5 official fee plans accurately without scholarship', () => {
  // 1. অনাবাসিক প্রভাতি শাখা: 12000 + 5000 = 17000 one-time; 2000 + 500 = 2500 monthly
  const nonResMorning = calculateTuitionBreakdown({
    division: 'general',
    planId: 'non-res-morning',
    scholarshipPercent: 0,
  });
  assert.equal(nonResMorning.admissionFee, 12000);
  assert.equal(nonResMorning.uniformCaseFee, 5000);
  assert.equal(nonResMorning.netOneTimeFee, 17000);
  assert.equal(nonResMorning.monthlyTuition, 2000);
  assert.equal(nonResMorning.weeklyMonthlyTestFee, 500);
  assert.equal(nonResMorning.netMonthlyFee, 2500);
  assert.equal(nonResMorning.annualTotal, 17000 + 2500 * 12);

  // 2. আবাসিক প্রভাতি শাখা: 12000 + 5000 = 17000 one-time; 2000 + 500 + 1500 + 5000 + 500 = 9500 monthly
  const resMorning = calculateTuitionBreakdown({
    division: 'general',
    planId: 'res-morning',
    scholarshipPercent: 0,
  });
  assert.equal(resMorning.netOneTimeFee, 17000);
  assert.equal(resMorning.hostelRentFee, 1500);
  assert.equal(resMorning.foodFee, 5000);
  assert.equal(resMorning.clubFee, 500);
  assert.equal(resMorning.netMonthlyFee, 9500);

  // 3. অনাবাসিক দিবা শাখা: 15000 + 7000 = 22000 one-time; 3000 + 700 = 3700 monthly
  const nonResDay = calculateTuitionBreakdown({
    division: 'general',
    planId: 'non-res-day',
    scholarshipPercent: 0,
  });
  assert.equal(nonResDay.netOneTimeFee, 22000);
  assert.equal(nonResDay.netMonthlyFee, 3700);

  // 4. অনাবাসিক প্রভাতি+ল্যাব: 15000 + 7000 = 22000 one-time; 3000 + 700 + 500 = 4200 monthly
  const nonResLab = calculateTuitionBreakdown({
    division: 'cadet',
    planId: 'non-res-morning-lab',
    scholarshipPercent: 0,
  });
  assert.equal(nonResLab.netOneTimeFee, 22000);
  assert.equal(nonResLab.labFee, 500);
  assert.equal(nonResLab.netMonthlyFee, 4200);

  // 5. আবাসিক প্রভাতি+ল্যাব: 15000 + 7000 = 22000 one-time; 3000 + 700 + 1500 + 5000 + 500 = 10700 monthly
  const resLab = calculateTuitionBreakdown({
    division: 'hifzul-quran',
    planId: 'res-morning-lab',
    scholarshipPercent: 0,
  });
  assert.equal(resLab.netOneTimeFee, 22000);
  assert.equal(resLab.netMonthlyFee, 10700);
});

test('calculateTuitionBreakdown applies 5% to 50% scholarship across monthly, one-time, and both scopes', () => {
  // 25% monthly scholarship on non-res-day (monthlyTuition 3000 -> 750 savings -> 3700 - 750 = 2950)
  const monthly25 = calculateTuitionBreakdown({
    division: 'cadet',
    planId: 'non-res-day',
    scholarshipPercent: 25,
    scholarshipScope: 'monthly',
  });
  assert.equal(monthly25.scholarshipMonthlySavings, 750);
  assert.equal(monthly25.oneTimeScholarshipSavings, 0);
  assert.equal(monthly25.netMonthlyFee, 2950);
  assert.equal(monthly25.netOneTimeFee, 22000);

  // 50% one-time scholarship on non-res-morning (admissionFee 12000 -> 6000 savings -> 17000 - 6000 = 11000)
  const oneTime50 = calculateTuitionBreakdown({
    division: 'noorani',
    planId: 'non-res-morning',
    scholarshipPercent: 50,
    scholarshipScope: 'one-time',
  });
  assert.equal(oneTime50.oneTimeScholarshipSavings, 6000);
  assert.equal(oneTime50.scholarshipMonthlySavings, 0);
  assert.equal(oneTime50.netOneTimeFee, 11000);
  assert.equal(oneTime50.netMonthlyFee, 2500);

  // 5% both scope on res-morning-lab (admission 15000 * 5% = 750; monthlyTuition 3000 * 5% = 150)
  const both5 = calculateTuitionBreakdown({
    division: 'general',
    planId: 'res-morning-lab',
    scholarshipPercent: 5,
    scholarshipScope: 'both',
  });
  assert.equal(both5.oneTimeScholarshipSavings, 750);
  assert.equal(both5.scholarshipMonthlySavings, 150);
  assert.equal(both5.netOneTimeFee, 21250);
  assert.equal(both5.netMonthlyFee, 10550);
});

test('validateApplicationForm rejects empty fields and invalid contact formats', () => {
  const emptyForm: ApplicationFormValues = {
    studentName: '',
    dateOfBirth: '',
    guardianName: 'A',
    guardianPhone: '123',
    guardianEmail: 'not-an-email',
    division: 'general',
    shift: 'morning',
    residential: 'day-scholar',
    previousSchool: '',
    notes: '',
  };

  const errors = validateApplicationForm(emptyForm);
  assert.ok(errors.studentName);
  assert.ok(errors.dateOfBirth);
  assert.ok(errors.guardianName);
  assert.ok(errors.guardianPhone);
  assert.ok(errors.guardianEmail);
  assert.ok(errors.previousSchool);
});

test('validateApplicationForm accepts complete valid application', () => {
  const validForm: ApplicationFormValues = {
    studentName: 'Zayd Ibn Tariq',
    dateOfBirth: '2012-04-14',
    guardianName: 'Tariq Mahmood',
    guardianPhone: '01824204543',
    guardianEmail: 'tariq.mahmood@example.com',
    division: 'cadet',
    shift: 'morning',
    residential: 'hostel',
    previousSchool: 'Al-Manar Model Academy',
    notes: 'Applying for Cadet Two Years Program.',
  };

  const errors = validateApplicationForm(validForm);
  assert.deepEqual(errors, {});
});

test('generateTrackingId formats sequential IDs with leading zeros', () => {
  assert.equal(generateTrackingId(1, 2026), 'FISC-2026-0001');
  assert.equal(generateTrackingId(42, 2026), 'FISC-2026-0042');
});

test('filterNotices filters by category and search query', () => {
  const examNotices = filterNotices(OFFICIAL_NOTICES, 'Examinations', '');
  assert.equal(examNotices.length, 1);
  assert.equal(examNotices[0].refNumber, 'FISC/EXM/2026/009');

  const queryMatch = filterNotices(OFFICIAL_NOTICES, 'All', 'Noorani');
  assert.equal(queryMatch.length, 3);

  const bnQueryMatch = filterNotices(OFFICIAL_NOTICES, 'All', 'গাজীপুর');
  assert.equal(bnQueryMatch.length, 2);
});

test('filterFaculty filters by department and search term', () => {
  const scienceFaculty = filterFaculty(FACULTY_MEMBERS, 'Sciences', '');
  assert.equal(scienceFaculty.length, 2);

  const qiraatMatch = filterFaculty(FACULTY_MEMBERS, 'All', 'Noorani');
  assert.equal(qiraatMatch.length, 1);
  assert.equal(qiraatMatch[0].id, 'fac-3');

  const bnMatch = filterFaculty(FACULTY_MEMBERS, 'All', 'ক্যাডেট');
  assert.equal(bnMatch.length, 3);
});

test('detectPreferredLanguage and resolveDescriptionLang auto-detect bn, en, and ar', () => {
  assert.equal(detectPreferredLanguage(['ar-SA', 'en-US']), 'ar');
  assert.equal(detectPreferredLanguage(['en-GB', 'bn']), 'en');
  assert.equal(detectPreferredLanguage(['bn-BD', 'en-US']), 'bn');
  assert.equal(detectPreferredLanguage(['fr-FR']), 'bn');

  assert.equal(resolveDescriptionLang('auto', ['ar']), 'ar');
  assert.equal(resolveDescriptionLang('auto', ['en-US']), 'en');
  assert.equal(resolveDescriptionLang('en', ['bn-BD']), 'en');
  assert.equal(getDirectionForLang('ar'), 'rtl');
  assert.equal(getDirectionForLang('bn'), 'ltr');
});

test('validateApplicationForm returns translated errors for en and ar', () => {
  const emptyForm: ApplicationFormValues = {
    studentName: '',
    dateOfBirth: '',
    guardianName: '',
    guardianPhone: '',
    guardianEmail: '',
    division: 'general',
    shift: 'morning',
    residential: 'day-scholar',
    previousSchool: '',
    notes: '',
  };

  const enErrors = validateApplicationForm(emptyForm, 'en');
  const arErrors = validateApplicationForm(emptyForm, 'ar');
  assert.ok(enErrors.studentName?.includes('Enter'));
  assert.ok(arErrors.studentName?.includes('أدخل'));
});

test('getWeeklyInstructionSchedule returns exact instruction and test hours per division, shift, and residential mode', () => {
  // General: Morning 18+2, Day 28+2, Residential 80+3
  assert.deepEqual(
    {
      instr: getWeeklyInstructionSchedule('general', 'morning', 'day-scholar').instructionHours,
      test: getWeeklyInstructionSchedule('general', 'morning', 'day-scholar').testHours,
    },
    { instr: 18, test: 2 }
  );
  assert.deepEqual(
    {
      instr: getWeeklyInstructionSchedule('general', 'day', 'day-scholar').instructionHours,
      test: getWeeklyInstructionSchedule('general', 'day', 'day-scholar').testHours,
    },
    { instr: 28, test: 2 }
  );

  // Noorani: Morning 24+2, Day 34+2, Residential 80+3
  assert.deepEqual(
    {
      instr: getWeeklyInstructionSchedule('noorani', 'morning', 'day-scholar').instructionHours,
      test: getWeeklyInstructionSchedule('noorani', 'morning', 'day-scholar').testHours,
    },
    { instr: 24, test: 2 }
  );
  assert.deepEqual(
    {
      instr: getWeeklyInstructionSchedule('noorani', 'day', 'day-scholar').instructionHours,
      test: getWeeklyInstructionSchedule('noorani', 'day', 'day-scholar').testHours,
    },
    { instr: 34, test: 2 }
  );

  // Cadet: 30+2
  assert.deepEqual(
    {
      instr: getWeeklyInstructionSchedule('cadet', 'morning', 'day-scholar').instructionHours,
      test: getWeeklyInstructionSchedule('cadet', 'morning', 'day-scholar').testHours,
    },
    { instr: 30, test: 2 }
  );

  // Hifzul Quran: 80+3
  assert.deepEqual(
    {
      instr: getWeeklyInstructionSchedule('hifzul-quran', 'morning', 'day-scholar').instructionHours,
      test: getWeeklyInstructionSchedule('hifzul-quran', 'morning', 'day-scholar').testHours,
    },
    { instr: 80, test: 3 }
  );

  // Residential (any division): 80+3
  for (const division of ['general', 'cadet', 'noorani', 'hifzul-quran'] as const) {
    const res = getWeeklyInstructionSchedule(division, 'morning', 'hostel');
    assert.equal(res.instructionHours, 80);
    assert.equal(res.testHours, 3);
  }
});

test('ACADEMIC_PROGRAMS module hoursByMode sum exactly to each division weekly instruction hours', () => {
  for (const program of ACADEMIC_PROGRAMS) {
    const modes = getDivisionWeeklyModes(program.id);
    for (const mode of modes) {
      const moduleSum = program.modules.reduce((acc, mod) => acc + mod.hoursByMode[mode.modeKey], 0);
      assert.equal(
        moduleSum,
        mode.instructionHours,
        `${program.id} (${mode.modeKey}) module hours ${moduleSum} !== ${mode.instructionHours}`
      );
    }
  }
});

test('TESTIMONIALS covers parents and students across all 4 divisions and filterTestimonials filters accurately', () => {
  assert.equal(TESTIMONIALS.length, 7);
  const divisions = new Set(TESTIMONIALS.map((t) => t.division));
  assert.ok(divisions.has('general'));
  assert.ok(divisions.has('cadet'));
  assert.ok(divisions.has('noorani'));
  assert.ok(divisions.has('hifzul-quran'));

  for (const item of TESTIMONIALS) {
    assert.ok(item.nameByLang.bn.length > 0 && item.nameByLang.en.length > 0 && item.nameByLang.ar.length > 0);
    assert.ok(item.quoteByLang.bn.length > 0 && item.quoteByLang.en.length > 0 && item.quoteByLang.ar.length > 0);
  }

  assert.equal(filterTestimonials(TESTIMONIALS, 'All').length, 7);
  const parents = filterTestimonials(TESTIMONIALS, 'Parent');
  const students = filterTestimonials(TESTIMONIALS, 'Student');
  assert.equal(parents.length, 4);
  assert.equal(students.length, 3);
  assert.ok(parents.every((p) => p.authorType === 'Parent'));
  assert.ok(students.every((s) => s.authorType === 'Student'));
});

test('INSTITUTION_FEATURES includes all 5 requested institutional characteristics in bn, en, and ar', () => {
  assert.equal(INSTITUTION_FEATURES.length, 5);
  for (const feat of INSTITUTION_FEATURES) {
    assert.ok(feat.titleBn.length > 0 && feat.titleEn.length > 0 && feat.titleAr.length > 0);
    assert.ok(
      feat.descriptionByLang.bn.length > 0 &&
        feat.descriptionByLang.en.length > 0 &&
        feat.descriptionByLang.ar.length > 0
    );
  }

  const allBnTitles = INSTITUTION_FEATURES.map((f) => f.titleBn).join(' ');
  assert.ok(allBnTitles.includes('নৈতিক মূল্যবোধ শিক্ষা'));
  assert.ok(allBnTitles.includes('বাংলা, ইংরেজি ও আরবি শিক্ষা'));
  assert.ok(allBnTitles.includes('সাপ্তাহিক, মাসিক, সেমিস্টার, বাৎসরিক ও ভাইবা'));
  assert.ok(allBnTitles.includes('একই সাথে জেনারেল ও ইসলামিক শিক্ষার ব্যবস্থা'));
  assert.ok(allBnTitles.includes('প্রাক্টিক্যাল'));

  const assessmentFeat = INSTITUTION_FEATURES.find((f) => f.id === 'feat-five-stage-assessment');
  assert.ok(assessmentFeat?.checkpointsByLang);
  assert.equal(assessmentFeat.checkpointsByLang.bn.length, 5);
  assert.equal(assessmentFeat.checkpointsByLang.en.length, 5);
  assert.equal(assessmentFeat.checkpointsByLang.ar.length, 5);
});

test('all campus photo captions include Proposed (প্রস্তাবিত) Lab, Library, and Building/Campus', () => {
  const allFigures = [HERO_CAMPUS_FIGURE, ...CAMPUS_GALLERY_FIGURES];
  assert.equal(allFigures.length, 5);

  for (const fig of allFigures) {
    assert.ok(
      fig.captionByLang.bn.includes('প্রস্তাবিত'),
      `${fig.id} bn caption missing প্রস্তাবিত`
    );
    assert.ok(
      fig.captionByLang.en.includes('Proposed'),
      `${fig.id} en caption missing Proposed`
    );
    assert.ok(
      fig.captionByLang.ar.includes('المقترح') || fig.captionByLang.ar.includes('المقترحة'),
      `${fig.id} ar caption missing المقترح/المقترحة`
    );
  }

  const allBnCaptions = allFigures.map((f) => f.captionByLang.bn).join(' ');
  assert.ok(allBnCaptions.includes('প্রস্তাবিত ল্যাব'));
  assert.ok(allBnCaptions.includes('প্রস্তাবিত লাইব্রেরী'));
  assert.ok(allBnCaptions.includes('প্রস্তাবিত ভবন / ক্যাম্পাস'));
  assert.ok(allBnCaptions.includes('প্রস্তাবিত ক্যাম্পাস / ভবন'));
});



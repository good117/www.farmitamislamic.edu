import type { DivisionId, FacultyMember, NoticeItem, TestimonialItem } from '../data/schoolData';

export type ShiftOption = 'morning' | 'day' | 'morning-lab';
export type ResidentialOption = 'day-scholar' | 'hostel';
export type FeePlanId =
  | 'non-res-morning'
  | 'res-morning'
  | 'non-res-day'
  | 'non-res-morning-lab'
  | 'res-morning-lab';
export type ScholarshipPercent = 0 | 5 | 10 | 15 | 20 | 25 | 30 | 40 | 50;
export type ScholarshipScope = 'monthly' | 'one-time' | 'both';

export interface FeePlanDefinition {
  id: FeePlanId;
  shift: ShiftOption;
  residential: ResidentialOption;
  labelByLang: Record<'bn' | 'en' | 'ar', string>;
  shortLabelByLang: Record<'bn' | 'en' | 'ar', string>;
  admissionFee: number;
  uniformCaseFee: number;
  monthlyTuition: number;
  weeklyMonthlyTestFee: number;
  hostelRentFee: number;
  foodFee: number;
  clubFee: number;
  labFee: number;
}

export const FEE_PLANS: FeePlanDefinition[] = [
  {
    id: 'non-res-morning',
    shift: 'morning',
    residential: 'day-scholar',
    labelByLang: {
      bn: 'অনাবাসিক প্রভাতি শাখা',
      en: 'Day-Scholar Morning Shift',
      ar: 'الفترة الصباحية (طالب نهاري)',
    },
    shortLabelByLang: {
      bn: 'অনাবাসিক প্রভাতি',
      en: 'Non-Res Morning',
      ar: 'صباحي نهاري',
    },
    admissionFee: 12000,
    uniformCaseFee: 5000,
    monthlyTuition: 2000,
    weeklyMonthlyTestFee: 500,
    hostelRentFee: 0,
    foodFee: 0,
    clubFee: 0,
    labFee: 0,
  },
  {
    id: 'res-morning',
    shift: 'morning',
    residential: 'hostel',
    labelByLang: {
      bn: 'আবাসিক প্রভাতি শাখা',
      en: 'Residential Morning Shift',
      ar: 'الفترة الصباحية (سكن داخلي)',
    },
    shortLabelByLang: {
      bn: 'আবাসিক প্রভাতি',
      en: 'Res Morning',
      ar: 'صباحي داخلي',
    },
    admissionFee: 12000,
    uniformCaseFee: 5000,
    monthlyTuition: 2000,
    weeklyMonthlyTestFee: 500,
    hostelRentFee: 1500,
    foodFee: 5000,
    clubFee: 500,
    labFee: 0,
  },
  {
    id: 'non-res-day',
    shift: 'day',
    residential: 'day-scholar',
    labelByLang: {
      bn: 'অনাবাসিক দিবা শাখা',
      en: 'Day-Scholar Day Shift',
      ar: 'الفترة المسائية (طالب نهاري)',
    },
    shortLabelByLang: {
      bn: 'অনাবাসিক দিবা',
      en: 'Non-Res Day',
      ar: 'نهاري مسائي',
    },
    admissionFee: 15000,
    uniformCaseFee: 7000,
    monthlyTuition: 3000,
    weeklyMonthlyTestFee: 700,
    hostelRentFee: 0,
    foodFee: 0,
    clubFee: 0,
    labFee: 0,
  },
  {
    id: 'non-res-morning-lab',
    shift: 'morning-lab',
    residential: 'day-scholar',
    labelByLang: {
      bn: 'অনাবাসিক প্রভাতি + ল্যাব',
      en: 'Day-Scholar Morning + Lab',
      ar: 'الصباحية + المختبر (نهاري)',
    },
    shortLabelByLang: {
      bn: 'অনাবাসিক প্রভাতি+ল্যাব',
      en: 'Non-Res Morning+Lab',
      ar: 'صباحي + مختبر',
    },
    admissionFee: 15000,
    uniformCaseFee: 7000,
    monthlyTuition: 3000,
    weeklyMonthlyTestFee: 700,
    hostelRentFee: 0,
    foodFee: 0,
    clubFee: 0,
    labFee: 500,
  },
  {
    id: 'res-morning-lab',
    shift: 'morning-lab',
    residential: 'hostel',
    labelByLang: {
      bn: 'আবাসিক প্রভাতি + ল্যাব',
      en: 'Residential Morning + Lab',
      ar: 'الصباحية + المختبر (سكن داخلي)',
    },
    shortLabelByLang: {
      bn: 'আবাসিক প্রভাতি+ল্যাব',
      en: 'Res Morning+Lab',
      ar: 'داخلي + مختبر',
    },
    admissionFee: 15000,
    uniformCaseFee: 7000,
    monthlyTuition: 3000,
    weeklyMonthlyTestFee: 700,
    hostelRentFee: 1500,
    foodFee: 5000,
    clubFee: 0,
    labFee: 500,
  },
];

export const SCHOLARSHIP_PERCENT_OPTIONS: ScholarshipPercent[] = [0, 5, 10, 15, 20, 25, 30, 40, 50];

export interface TuitionInput {
  division: DivisionId;
  planId?: FeePlanId;
  shift?: ShiftOption;
  residential?: ResidentialOption;
  scholarshipPercent: ScholarshipPercent;
  scholarshipScope?: ScholarshipScope;
}

export interface TuitionBreakdown {
  planId: FeePlanId;
  admissionFee: number;
  uniformCaseFee: number;
  totalOneTimeBeforeWaiver: number;
  oneTimeScholarshipSavings: number;
  netOneTimeFee: number;
  monthlyTuition: number;
  weeklyMonthlyTestFee: number;
  hostelRentFee: number;
  foodFee: number;
  clubFee: number;
  labFee: number;
  baseMonthlyTuition: number;
  hostelMonthlyFee: number;
  scholarshipDiscountPercent: ScholarshipPercent;
  scholarshipScope: ScholarshipScope;
  scholarshipMonthlySavings: number;
  netMonthlyFee: number;
  annualTotal: number;
}

export interface ApplicationFormValues {
  studentName: string;
  dateOfBirth: string;
  guardianName: string;
  guardianPhone: string;
  guardianEmail: string;
  division: DivisionId;
  shift: ShiftOption;
  residential: ResidentialOption;
  previousSchool: string;
  notes: string;
}

export interface SubmittedApplication extends ApplicationFormValues {
  trackingId: string;
  submittedAt: string;
  status: 'Submitted — Under Review' | 'Assessment Scheduled';
}

export type ApplicationErrors = Partial<Record<keyof ApplicationFormValues, string>>;

export function resolveFeePlan(
  planId?: FeePlanId,
  shift: ShiftOption = 'morning',
  residential: ResidentialOption = 'day-scholar'
): FeePlanDefinition {
  if (planId) {
    const matched = FEE_PLANS.find((plan) => plan.id === planId);
    if (matched) return matched;
  }
  if (shift === 'morning-lab') {
    return residential === 'hostel' ? FEE_PLANS[4] : FEE_PLANS[3];
  }
  if (shift === 'day') {
    return residential === 'hostel' ? FEE_PLANS[4] : FEE_PLANS[2];
  }
  return residential === 'hostel' ? FEE_PLANS[1] : FEE_PLANS[0];
}

export function calculateTuitionBreakdown(input: TuitionInput): TuitionBreakdown {
  const plan = resolveFeePlan(input.planId, input.shift, input.residential);
  const scope: ScholarshipScope = input.scholarshipScope ?? 'monthly';
  const discountPercent = input.scholarshipPercent;

  const oneTimeScholarshipSavings =
    scope === 'one-time' || scope === 'both'
      ? Math.round((plan.admissionFee * discountPercent) / 100)
      : 0;
  const totalOneTimeBeforeWaiver = plan.admissionFee + plan.uniformCaseFee;
  const netOneTimeFee = totalOneTimeBeforeWaiver - oneTimeScholarshipSavings;

  const scholarshipMonthlySavings =
    scope === 'monthly' || scope === 'both'
      ? Math.round((plan.monthlyTuition * discountPercent) / 100)
      : 0;

  const hostelMonthlyFee = plan.hostelRentFee + plan.foodFee + plan.clubFee;
  const baseMonthlyTuition =
    plan.monthlyTuition + plan.weeklyMonthlyTestFee + hostelMonthlyFee + plan.labFee;
  const netMonthlyFee = baseMonthlyTuition - scholarshipMonthlySavings;
  const annualTotal = netOneTimeFee + netMonthlyFee * 12;

  return {
    planId: plan.id,
    admissionFee: plan.admissionFee,
    uniformCaseFee: plan.uniformCaseFee,
    totalOneTimeBeforeWaiver,
    oneTimeScholarshipSavings,
    netOneTimeFee,
    monthlyTuition: plan.monthlyTuition,
    weeklyMonthlyTestFee: plan.weeklyMonthlyTestFee,
    hostelRentFee: plan.hostelRentFee,
    foodFee: plan.foodFee,
    clubFee: plan.clubFee,
    labFee: plan.labFee,
    baseMonthlyTuition,
    hostelMonthlyFee,
    scholarshipDiscountPercent: discountPercent,
    scholarshipScope: scope,
    scholarshipMonthlySavings,
    netMonthlyFee,
    annualTotal,
  };
}

export function formatCurrencyBDT(amount: number): string {
  return `৳${amount.toLocaleString('en-US')}`;
}

export type InstructionModeKey = 'morning' | 'day' | 'residential';

export interface WeeklyInstructionSchedule {
  modeKey: InstructionModeKey;
  instructionHours: number;
  testHours: number;
  modeLabelByLang: Record<'bn' | 'en' | 'ar', string>;
  displayByLang: Record<'bn' | 'en' | 'ar', string>;
  compactByLang: Record<'bn' | 'en' | 'ar', string>;
}

const BN_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
const AR_DIGITS = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];

export function toLocaleDigits(value: number, lang: 'bn' | 'en' | 'ar'): string {
  const str = String(value);
  if (lang === 'en') return str;
  const map = lang === 'bn' ? BN_DIGITS : AR_DIGITS;
  return str.replace(/\d/g, (d) => map[Number(d)]);
}

function buildScheduleEntry(
  modeKey: InstructionModeKey,
  instructionHours: number,
  testHours: number,
  modeLabelByLang: Record<'bn' | 'en' | 'ar', string>
): WeeklyInstructionSchedule {
  const bnInstr = toLocaleDigits(instructionHours, 'bn');
  const bnTest = toLocaleDigits(testHours, 'bn');
  const arInstr = toLocaleDigits(instructionHours, 'ar');
  const arTest = toLocaleDigits(testHours, 'ar');

  return {
    modeKey,
    instructionHours,
    testHours,
    modeLabelByLang,
    displayByLang: {
      bn: `${bnInstr} ঘণ্টা · টেস্ট ${bnTest} ঘণ্টা`,
      en: `${instructionHours} hrs · Test ${testHours} hrs`,
      ar: `${arInstr} ساعة · اختبار ${arTest} ساعة`,
    },
    compactByLang: {
      bn: `${bnInstr} ঘণ্টা + টেস্ট ${bnTest} ঘণ্টা`,
      en: `${instructionHours} hrs + ${testHours} hrs test`,
      ar: `${arInstr} ساعة + ${arTest} ساعة اختبار`,
    },
  };
}

export function getWeeklyInstructionSchedule(
  division: DivisionId,
  shift: ShiftOption,
  residential: ResidentialOption
): WeeklyInstructionSchedule {
  if (residential === 'hostel') {
    return buildScheduleEntry('residential', 80, 3, {
      bn: 'আবাসিক (হোস্টেল)',
      en: 'Residential',
      ar: 'السكن الداخلي',
    });
  }

  const isDayShift = shift === 'day';

  switch (division) {
    case 'general':
      return !isDayShift
        ? buildScheduleEntry('morning', 18, 2, {
            bn: 'প্রভাতি শিফট',
            en: 'Morning Shift',
            ar: 'الفترة الصباحية',
          })
        : buildScheduleEntry('day', 28, 2, {
            bn: 'ডে-শিফট',
            en: 'Day Shift',
            ar: 'الفترة النهارية',
          });
    case 'noorani':
      return !isDayShift
        ? buildScheduleEntry('morning', 24, 2, {
            bn: 'প্রভাতি শিফট',
            en: 'Morning Shift',
            ar: 'الفترة الصباحية',
          })
        : buildScheduleEntry('day', 34, 2, {
            bn: 'ডে-শিফট',
            en: 'Day Shift',
            ar: 'الفترة النهارية',
          });
    case 'cadet':
      return buildScheduleEntry(isDayShift ? 'day' : 'morning', 30, 2, {
        bn: 'পূর্ণ দিবস (অনাবাসিক)',
        en: 'Full Program (Day)',
        ar: 'البرنامج النهاري الكامل',
      });
    case 'hifzul-quran':
      return buildScheduleEntry(isDayShift ? 'day' : 'morning', 80, 3, {
        bn: 'নিয়মিত পূর্ণ দিবস',
        en: 'Full Hifz Schedule',
        ar: 'الجدول الكامل للتحفيظ',
      });
  }
}

export function getDivisionWeeklyModes(division: DivisionId): WeeklyInstructionSchedule[] {
  if (division === 'general' || division === 'noorani') {
    return [
      getWeeklyInstructionSchedule(division, 'morning', 'day-scholar'),
      getWeeklyInstructionSchedule(division, 'day', 'day-scholar'),
      getWeeklyInstructionSchedule(division, 'morning', 'hostel'),
    ];
  }
  return [
    getWeeklyInstructionSchedule(division, 'morning', 'day-scholar'),
    getWeeklyInstructionSchedule(division, 'morning', 'hostel'),
  ];
}

export function validateApplicationForm(
  values: ApplicationFormValues,
  lang: 'bn' | 'en' | 'ar' = 'bn'
): ApplicationErrors {
  const errors: ApplicationErrors = {};

  const messages = {
    bn: {
      studentName: 'শিক্ষার্থীর পূর্ণ নাম লিখুন (কমপক্ষে ৩ অক্ষর)।',
      dateOfBirthEmpty: 'শিক্ষার্থীর জন্ম তারিখ নির্বাচন করুন।',
      dateOfBirthFuture: 'জন্ম তারিখ অবশ্যই ২০২৭ সালের পূর্বের হতে হবে।',
      dateOfBirthAge: 'স্কুল ও কলেজ বিভাগের জন্য শিক্ষার্থীর বয়স ৪ থেকে ২১ বছরের মধ্যে হতে হবে।',
      guardianName: 'পিতা/মাতা বা আইনগত অভিভাবকের পূর্ণ নাম লিখুন।',
      guardianPhone: 'সঠিক মোবাইল নম্বর দিন (১০ থেকে ১৫ অঙ্ক)।',
      guardianEmail: 'সঠিক অভিভাবক ইমেইল ঠিকানা দিন।',
      previousSchool: 'পূর্ববর্তী প্রতিষ্ঠানের নাম লিখুন অথবা "প্রথমবার ভর্তি" লিখুন।',
    },
    en: {
      studentName: 'Enter the student’s full name (at least 3 characters).',
      dateOfBirthEmpty: 'Select the student’s date of birth.',
      dateOfBirthFuture: 'Date of birth must be prior to 2027.',
      dateOfBirthAge: 'Applicant age must be between 4 and 21 years for school & college divisions.',
      guardianName: 'Enter a parent or legal guardian’s full name.',
      guardianPhone: 'Enter a valid contact phone number (10–15 digits).',
      guardianEmail: 'Enter a valid guardian email address.',
      previousSchool: 'Enter previous institution or write "First Time Enrollment".',
    },
    ar: {
      studentName: 'أدخل الاسم الكامل للطالب (٣ أحرف على الأقل).',
      dateOfBirthEmpty: 'اختر تاريخ ميلاد الطالب.',
      dateOfBirthFuture: 'يجب أن يكون تاريخ الميلاد قبل عام ٢٠٢٧.',
      dateOfBirthAge: 'يجب أن يكون عمر المتقدم بين ٤ و٢١ عاماً لأقسام المدرسة والكلية.',
      guardianName: 'أدخل الاسم الكامل لولي الأمر.',
      guardianPhone: 'أدخل رقم هاتف صحيحاً (١٠ إلى ١٥ رقماً).',
      guardianEmail: 'أدخل بريدًا إلكترونيًا صحيحًا لولي الأمر.',
      previousSchool: 'أدخل اسم المؤسسة السابقة أو اكتب "التحاق لأول مرة".',
    },
  }[lang];

  if (!values.studentName.trim() || values.studentName.trim().length < 3) {
    errors.studentName = messages.studentName;
  }

  if (!values.dateOfBirth.trim()) {
    errors.dateOfBirth = messages.dateOfBirthEmpty;
  } else {
    const dob = new Date(values.dateOfBirth);
    const reference = new Date('2026-12-31');
    if (Number.isNaN(dob.getTime()) || dob >= reference) {
      errors.dateOfBirth = messages.dateOfBirthFuture;
    } else {
      const ageYears = (reference.getTime() - dob.getTime()) / (1000 * 60 * 60 * 24 * 365.25);
      if (ageYears < 3.5 || ageYears > 22) {
        errors.dateOfBirth = messages.dateOfBirthAge;
      }
    }
  }

  if (!values.guardianName.trim() || values.guardianName.trim().length < 3) {
    errors.guardianName = messages.guardianName;
  }

  const normalizedPhone = values.guardianPhone.replace(/[\s\-()]/g, '');
  if (!/^\+?\d{10,15}$/.test(normalizedPhone)) {
    errors.guardianPhone = messages.guardianPhone;
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.guardianEmail.trim())) {
    errors.guardianEmail = messages.guardianEmail;
  }

  if (!values.previousSchool.trim()) {
    errors.previousSchool = messages.previousSchool;
  }

  return errors;
}

export function generateTrackingId(sequenceNumber: number, year = 2026): string {
  const safeSeq = Math.max(1, Math.floor(sequenceNumber));
  return `FISC-${year}-${String(safeSeq).padStart(4, '0')}`;
}

export function filterNotices(
  notices: NoticeItem[],
  category: 'All' | NoticeItem['category'],
  searchQuery: string
): NoticeItem[] {
  const normalizedQuery = searchQuery.trim().toLowerCase();
  return notices.filter((notice) => {
    const matchesCategory = category === 'All' || notice.category === category;
    if (!matchesCategory) return false;
    if (!normalizedQuery) return true;
    return (
      notice.title.toLowerCase().includes(normalizedQuery) ||
      notice.titleEn.toLowerCase().includes(normalizedQuery) ||
      notice.titleAr.toLowerCase().includes(normalizedQuery) ||
      notice.excerpt.toLowerCase().includes(normalizedQuery) ||
      notice.excerptByLang.en.toLowerCase().includes(normalizedQuery) ||
      notice.excerptByLang.ar.toLowerCase().includes(normalizedQuery) ||
      notice.refNumber.toLowerCase().includes(normalizedQuery)
    );
  });
}

export function filterFaculty(
  faculty: FacultyMember[],
  department: 'All' | FacultyMember['department'],
  searchQuery: string
): FacultyMember[] {
  const normalizedQuery = searchQuery.trim().toLowerCase();
  return faculty.filter((member) => {
    const matchesDepartment = department === 'All' || member.department === department;
    if (!matchesDepartment) return false;
    if (!normalizedQuery) return true;
    return (
      member.name.toLowerCase().includes(normalizedQuery) ||
      member.nameEn.toLowerCase().includes(normalizedQuery) ||
      member.nameAr.toLowerCase().includes(normalizedQuery) ||
      member.role.toLowerCase().includes(normalizedQuery) ||
      member.roleByLang.en.toLowerCase().includes(normalizedQuery) ||
      member.credentials.toLowerCase().includes(normalizedQuery) ||
      member.credentialsByLang.en.toLowerCase().includes(normalizedQuery) ||
      member.focus.toLowerCase().includes(normalizedQuery) ||
      member.focusByLang.en.toLowerCase().includes(normalizedQuery)
    );
  });
}

export type TestimonialRoleFilter = 'All' | TestimonialItem['authorType'];

export function filterTestimonials(
  testimonials: TestimonialItem[],
  role: TestimonialRoleFilter
): TestimonialItem[] {
  if (role === 'All') return testimonials;
  return testimonials.filter((item) => item.authorType === role);
}

export type DescriptionLang = 'bn' | 'en' | 'ar';
export type LangMode = 'auto' | DescriptionLang;

export function detectPreferredLanguage(navigatorLanguages: readonly string[] = []): DescriptionLang {
  for (const rawTag of navigatorLanguages) {
    const tag = rawTag.trim().toLowerCase();
    if (!tag) continue;
    if (tag.startsWith('bn')) return 'bn';
    if (tag.startsWith('ar')) return 'ar';
    if (tag.startsWith('en')) return 'en';
  }
  return 'bn';
}

export function resolveDescriptionLang(
  mode: LangMode,
  navigatorLanguages: readonly string[] = []
): DescriptionLang {
  if (mode === 'auto') {
    return detectPreferredLanguage(navigatorLanguages);
  }
  return mode;
}

export function getDirectionForLang(lang: DescriptionLang): 'rtl' | 'ltr' {
  return lang === 'ar' ? 'rtl' : 'ltr';
}

export function pickLocalized<T>(lang: DescriptionLang, map: Record<DescriptionLang, T>): T {
  return map[lang];
}

import type { DescriptionLang } from '../utils/i18n';

export type DivisionId = 'general' | 'cadet' | 'noorani' | 'hifzul-quran';

export type LocalizedString = Record<DescriptionLang, string>;
export type LocalizedList = Record<DescriptionLang, string[]>;

export interface CurriculumModule {
  code: string;
  subject: string;
  subjectByLang: LocalizedString;
  stream: string;
  streamByLang: LocalizedString;
  hoursPerWeek: number;
  hoursByMode: {
    morning: number;
    day: number;
    residential: number;
  };
}

export interface AcademicProgram {
  id: DivisionId;
  code: string;
  title: string;
  bnTitle: string;
  arTitle: string;
  grades: string;
  gradesByLang: LocalizedString;
  ageRange: string;
  ageRangeByLang: LocalizedString;
  shiftSummary: string;
  shiftSummaryByLang: LocalizedString;
  summary: string;
  summaryByLang: LocalizedString;
  highlightByLang: LocalizedString;
  seatCapacity: number;
  studentTeacherRatio: string;
  studentTeacherRatioByLang: LocalizedString;
  modules: CurriculumModule[];
}

export interface HistoryMilestone {
  period: string;
  periodByLang: LocalizedString;
  title: string;
  titleEn: string;
  titleAr: string;
  summary: string;
  summaryByLang: LocalizedString;
}

export interface FacultyMember {
  id: string;
  name: string;
  nameEn: string;
  nameAr: string;
  role: string;
  roleByLang: LocalizedString;
  department: 'Islamic Studies' | 'Sciences' | 'Humanities' | 'Languages';
  departmentLabel: string;
  departmentLabelByLang: LocalizedString;
  credentials: string;
  credentialsByLang: LocalizedString;
  officeHours: string;
  officeHoursByLang: LocalizedString;
  focus: string;
  focusByLang: LocalizedString;
}

export interface NoticeItem {
  id: string;
  refNumber: string;
  title: string;
  titleEn: string;
  titleAr: string;
  category: 'Admissions' | 'Examinations' | 'Events';
  categoryLabel: string;
  categoryLabelByLang: LocalizedString;
  publishedAt: string;
  excerpt: string;
  excerptByLang: LocalizedString;
  body: string[];
  bodyByLang: LocalizedList;
  issuedBy: string;
  issuedByByLang: LocalizedString;
}

export interface DailyScheduleRow {
  period: string;
  timeRange: string;
  activity: string;
  activityByLang: LocalizedString;
  notes: string;
  notesByLang: LocalizedString;
}

export interface CalendarMilestone {
  date: string;
  title: string;
  titleByLang: LocalizedString;
  divisionScope: string;
  divisionScopeByLang: LocalizedString;
}

export interface TestimonialItem {
  id: string;
  authorType: 'Parent' | 'Student';
  division: DivisionId;
  featured?: boolean;
  nameByLang: LocalizedString;
  roleByLang: LocalizedString;
  wingLabelByLang: LocalizedString;
  outcomeByLang: LocalizedString;
  quoteByLang: LocalizedString;
}

export interface InstitutionFeature {
  id: string;
  indexByLang: LocalizedString;
  kickerByLang: LocalizedString;
  titleBn: string;
  titleEn: string;
  titleAr: string;
  titleByLang: LocalizedString;
  descriptionByLang: LocalizedString;
  checkpointsByLang?: LocalizedList;
}

export interface CampusFigure {
  id: string;
  src: string;
  captionByLang: LocalizedString;
  altByLang: LocalizedString;
  fallbackTitle: string;
}

export const INSTITUTION_CONTACT = {
  name: 'FARMITAM Islamic School & College',
  bnName: 'ফারমিটম ইসলামিক স্কুল এন্ড কলেজ',
  arName: 'مدرسة وكلية فارميتام الإسلامية',
  address: 'পরশ আলী রোড, পারিজাত, কোনাবাড়ী, গাজীপুর',
  addressEn: 'Parosh Ali Road, Parijat, Konabari, Gazipur',
  addressByLang: {
    bn: 'পরশ আলী রোড, পারিজাত, কোনাবাড়ী, গাজীপুর',
    en: 'Parosh Ali Road, Parijat, Konabari, Gazipur',
    ar: 'طريق باروش علي، بارجات، كوناباري، غازي بور',
  } as LocalizedString,
  phone: '01824-204543',
  email: 'farmitameducation@gmail.com',
  hours: 'রবি–বৃহঃ · সকাল ০৭:৩০ – বিকেল ০৪:০০',
  hoursByLang: {
    bn: 'রবি–বৃহঃ · সকাল ০৭:৩০ – বিকেল ০৪:০০',
    en: 'Sun–Thu · 07:30 – 16:00',
    ar: 'الأحد–الخميس · ٠٧:٣٠ – ١٦:٠٠',
  } as LocalizedString,
  foundedYear: '২০২৬',
  foundedYearByLang: {
    bn: '২০২৬',
    en: '2026',
    ar: '٢٠٢٦',
  } as LocalizedString,
};

export const HISTORY_OVERVIEW = {
  foundingDate: 'জানুয়ারি ২০২৬',
  foundingDateByLang: {
    bn: 'জানুয়ারি ২০২৬',
    en: 'January 2026',
    ar: 'يناير ٢٠٢٦',
  } as LocalizedString,
  location: 'পরশ আলী রোড, পারিজাত, কোনাবাড়ী, গাজীপুর',
  paragraphsByLang: {
    bn: [
      'জানুয়ারি ২০২৬-এ গাজীপুরের কোনাবাড়ীর পারিজাতের পরশ আলী রোডে ফারমিটম ইসলামিক স্কুল এন্ড কলেজ (FARMITAM Islamic School & College) প্রতিষ্ঠিত হয়। সমাজে প্রচলিত দ্বীনি ও আধুনিক শিক্ষার মধ্যকার দূরত্ব ঘুচিয়ে একই প্রাঙ্গণে বিশুদ্ধ কুরআনিক জ্ঞান ও সুশৃঙ্খল আধুনিক শিক্ষার সমন্বয় ঘটানোই ছিল এই প্রতিষ্ঠান গড়ার মূল প্রেরণা।',
      'প্রতিষ্ঠার প্রথম শিক্ষাবর্ষ থেকেই প্রতিষ্ঠানটি চারটি সুসমন্বিত বিভাগে কার্যক্রম বিস্তৃত করেছে—জেনারেল (প্লে থেকে দশম শ্রেণি), নিবিড় ক্যাডেট (দুই বছর মেয়াদী প্রোগ্রাম), নূরানী (কায়েদা, আমপারা ও কুরআন) এবং পূর্ণকালীন হিফজুল কুরআন—যাতে গাজীপুর ও আশেপাশের জেলার শিক্ষার্থীরা নৈতিক ভিত্তি ও একাডেমিক শ্রেষ্ঠত্ব একসাথে অর্জন করতে পারে।',
    ],
    en: [
      'Founded in January 2026 on Parosh Ali Road in Parijat, Konabari, Gazipur, FARMITAM Islamic School & College was established to bridge a longstanding divide in community education: uniting authentic Quranic scholarship with disciplined modern schooling under a single roof.',
      'From its opening term, the institution expanded across four coordinated divisions—General (Play to Ten), the intensive Cadet (Two Years Program), Noorani (Quyeda, Ampar and Quran), and full-time Hifzul Quran—so families in Gazipur and surrounding districts can pursue both spiritual grounding and competitive academic distinction without compromise.',
    ],
    ar: [
      'تأسست مدرسة وكلية فارميتام الإسلامية في يناير ٢٠٢٦ في طريق باروش علي ببارجات، كوناباري في غازي بور، لسد الفجوة بين التعليم الديني والمدارس الحديثة من خلال الجمع بين العلوم الشرعية الأصيلة والتعليم الأكاديمي المنضبط تحت سقف واحد.',
      'ومنذ انطلاقتها الأولى، توسعت المؤسسة عبر أربعة أقسام متكاملة: القسم العام (من الروضة إلى الصف العاشر)، وبرنامج الكاديت المكثف لمدة سنتين، وقسم النوراني (القاعدة وعمّ والقرآن)، وقسم تحفيظ القرآن الكريم بدوام كامل، لتمكين الطلاب في غازي بور والمناطق المجاورة من الجمع بين التربية الإيمانية والتفوق العلمي.',
    ],
  } as LocalizedList,
  vision:
    'ইসলামী আদর্শ, নৈতিক চরিত্র (আদব ও তাকওয়া) এবং আধুনিক বিজ্ঞান, ক্যাডেট নেতৃত্ব ও জাতীয় শিক্ষায় উৎকর্ষ অর্জনকারী একদল আদর্শ আলেম, হাফেজ ও ভবিষ্যৎ নেতৃত্ব গড়ে তোলা।',
  visionByLang: {
    bn: 'ইসলামী আদর্শ, নৈতিক চরিত্র (আদব ও তাকওয়া) এবং আধুনিক বিজ্ঞান, ক্যাডেট নেতৃত্ব ও জাতীয় শিক্ষায় উৎকর্ষ অর্জনকারী একদল আদর্শ আলেম, হাফেজ ও ভবিষ্যৎ নেতৃত্ব গড়ে তোলা।',
    en: 'To nurture a generation of principled scholars, Huffaz, and future leaders who embody Islamic character (Adab and Taqwa) while achieving distinction in modern science, cadet leadership, and national academics.',
    ar: 'إعداد جيل من العلماء وحفاظ القرآن وقادة المستقبل الذين يتحلون بالأخلاق الإسلامية والأدب والتقوى مع تحقيق التميز في العلوم الحديثة والقيادة والتعليم الوطني.',
  } as LocalizedString,
  mission:
    'একটি সুশৃঙ্খল ও মেন্টরশিপ-নির্ভর ক্যাম্পাসে জেনারেল (প্লে থেকে দশম), ক্যাডেট (দুই বছর মেয়াদী প্রোগ্রাম), নূরানী (কায়েদা, আমপারা ও কুরআন) এবং হিফজুল কুরআন—এই চারটি সমন্বিত বিভাগের মাধ্যমে দ্বীনি ও আধুনিক শিক্ষার মানসম্মত পাঠদান নিশ্চিত করা।',
  missionByLang: {
    bn: 'একটি সুশৃঙ্খল ও মেন্টরশিপ-নির্ভর ক্যাম্পাসে জেনারেল (প্লে থেকে দশম), ক্যাডেট (দুই বছর মেয়াদী প্রোগ্রাম), নূরানী (কায়েদা, আমপারা ও কুরআন) এবং হিফজুল কুরআন—এই চারটি সমন্বিত বিভাগের মাধ্যমে দ্বীনি ও আধুনিক শিক্ষার মানসম্মত পাঠদান নিশ্চিত করা।',
    en: 'To deliver an integrated four-wing educational model—uniting General (Play to Ten), Cadet (Two Years Program), Noorani (Quyeda, Ampar and Quran), and Hifzul Quran—within a disciplined, mentorship-driven campus committed to both revealed and contemporary knowledge.',
    ar: 'تقديم نموذج تعليمي متكامل يجمع بين الأقسام الأربعة—العام (من الروضة إلى العاشر)، والكاديت (برنامج السنتين)، والنوراني (القاعدة وعمّ والقرآن)، وتحفيظ القرآن—داخل بيئة تعليمية منضبطة قائمة على التوجيه التربوي والعلمي.',
  } as LocalizedString,
  commitments: [
    'অভিজ্ঞ কারী ও হাফেজ শিক্ষকদের তত্ত্বাবধানে বিশুদ্ধ তাজবিদসহ কুরআন তিলাওয়াত ও নিয়মতান্ত্রিক হিফজ শিক্ষা।',
    'প্লে-গ্রুপ থেকে দশম শ্রেণি পর্যন্ত জেনারেল বিভাগে হাতে-কলমে বিজ্ঞান পরীক্ষাগার, গণিত ও ইংরেজি-বাংলা ভাষায় দক্ষতা অর্জন।',
    'দুই বছর মেয়াদী ক্যাডেট প্রোগ্রামে বাংলা, ইংরেজি, গণিত, সাধারণ জ্ঞান শিক্ষা, আইকিউ চর্চা ও ভাইভা প্রস্তুতির নিবিড় প্রশিক্ষণ।',
  ],
  commitmentsByLang: {
    bn: [
      'যারা হিফজুল কুরআন সম্পন্ন করতে ইচ্ছুক তাদের জন্য জেনারেল ক্লাসের পাশাপাশি অতিরিক্ত কুরআন ক্লাসসহ নূরানী শিক্ষা এবং হিফজ বিভাগে নিয়মিত সবক, সাত-সবক, আমুক্তা, তেলাওয়াত ও সবিনা তদারকি।',
      'প্লে-গ্রুপ থেকে দশম শ্রেণি পর্যন্ত জেনারেল বিভাগে হাতে-কলমে বিজ্ঞান পরীক্ষাগার, গণিত ও ইংরেজি-বাংলা ভাষায় দক্ষতা অর্জন।',
      'দুই বছর মেয়াদী ক্যাডেট প্রোগ্রামে বাংলা, ইংরেজি, গণিত, সাধারণ জ্ঞান শিক্ষা, আইকিউ চর্চা, ভাইভা প্রস্তুতি ও শারীরিক শৃঙ্খলার নিবিড় প্রশিক্ষণ।',
    ],
    en: [
      'Specialized Noorani wing—combining General classes with extra Quran hours for Hifz readiness—alongside Hifzul Quran circles with daily Sabaq, Saat-Sabaq, Amukhta, Tilawat, and Sabina supervision.',
      'Rigorous General curriculum from Playgroup to Class Ten with hands-on laboratory science, mathematics, and bilingual fluency.',
      'Focused Two-Year Cadet preparation cultivating Bangla, English, Mathematics, General Knowledge, analytical reasoning, physical discipline, and competitive interview readiness.',
    ],
    ar: [
      'قسم النوراني للراغبين في حفظ القرآن (دروس عامة + حصص قرآن إضافية)، وقسم التحفيظ بمتابعة يومية للسبق والسبع سبق والأمختة والتلاوة والسبينا.',
      'منهج عام متكامل من الروضة حتى الصف العاشر يضم المختبرات العلمية العملية والرياضيات وإتقان اللغات.',
      'إعداد مكثف في برنامج الكاديت لمدة سنتين يشمل اللغة البنغالية والإنجليزية والرياضيات والمعرفة العامة والتفكير التحليلي والانضباط البدني.',
    ],
  } as LocalizedList,
};

export const HISTORY_MILESTONES: HistoryMilestone[] = [
  {
    period: 'জানুয়ারি ২০২৬',
    periodByLang: { bn: 'জানুয়ারি ২০২৬', en: 'January 2026', ar: 'يناير ٢٠٢٦' },
    title: 'কোনাবাড়ী, গাজীপুরে প্রতিষ্ঠার সূচনা',
    titleEn: 'Founding Charter at Konabari, Gazipur',
    titleAr: 'التأسيس في كوناباري، غازي بور',
    summary:
      '"Knowledge With Faith" মূলমন্ত্রকে ধারণ করে কোনাবাড়ীর পারিজাতের পরশ আলী রোডে নৈতিক ও আধুনিক শিক্ষার সমন্বিত বিদ্যাপীঠ হিসেবে যাত্রা শুরু।',
    summaryByLang: {
      bn: '"Knowledge With Faith" মূলমন্ত্রকে ধারণ করে কোনাবাড়ীর পারিজাতের পরশ আলী রোডে নৈতিক ও আধুনিক শিক্ষার সমন্বিত বিদ্যাপীঠ হিসেবে যাত্রা শুরু।',
      en: 'Established on Parosh Ali Road, Parijat, Konabari with the institutional motto "Knowledge With Faith" to serve families seeking moral and academic excellence in one campus.',
      ar: 'تأسست المؤسسة في طريق باروش علي ببارجات، كوناباري حاملة شعار "العلم مع الإيمان" لتلبية تطلعات الأسر الباحثة عن التميز الأخلاقي والأكاديمي.',
    },
  },
  {
    period: 'এপ্রিল ২০২৬',
    periodByLang: { bn: 'এপ্রিল ২০২৬', en: 'April 2026', ar: 'أبريل ٢٠٢٦' },
    title: 'নূরানী ও হিফজুল কুরআন বিভাগের উদ্বোধন',
    titleEn: 'Noorani & Hifzul Quran Wing Inauguration',
    titleAr: 'افتتاح قسمي النوراني وتحفيظ القرآن',
    summary:
      'স্বতন্ত্র কুরআন শিক্ষাকক্ষ স্থাপনের মাধ্যমে জেনারেল ক্লাসের পাশাপাশি অতিরিক্ত সময় কুরআন ক্লাসসহ নূরানী (কায়েদা, আমপারা ও কুরআন) ভিত্তি কোর্স এবং নিয়মিত সবক, সাত-সবক, আমুক্তা, তেলাওয়াত ও সবিনা তদারকিসহ পূর্ণকালীন হিফজুল কুরআন বিভাগ চালু।',
    summaryByLang: {
      bn: 'স্বতন্ত্র কুরআন শিক্ষাকক্ষ স্থাপনের মাধ্যমে জেনারেল ক্লাসের পাশাপাশি অতিরিক্ত সময় কুরআন ক্লাসসহ নূরানী (কায়েদা, আমপারা ও কুরআন) ভিত্তি কোর্স এবং নিয়মিত সবক, সাত-সবক, আমুক্তা, তেলাওয়াত ও সবিনা তদারকিসহ পূর্ণকালীন হিফজুল কুরআন বিভাগ চালু।',
      en: 'Opened dedicated Quranic classrooms launching the Noorani wing—with General classes plus extra Quran hours to build full Hifz readiness—alongside full-time Hifzul Quran circles supervised through daily Sabaq, Saat-Sabaq, Amukhta, Tilawat, and Sabina.',
      ar: 'افتتاح فصول قرآنية مخصصة لإطلاق قسم النوراني الذي يجمع بين الدروس العامة وساعات القرآن الإضافية لتأهيل الطلاب للحفظ، إلى جانب حلقات تحفيظ القرآن الكريم مع المتابعة المنتظمة للسبق والسبع سبق والأمختة والتلاوة والسبينا.',
    },
  },
  {
    period: 'আগস্ট ২০২৬',
    periodByLang: { bn: 'আগস্ট ২০২৬', en: 'August 2026', ar: 'أغسطس ٢٠٢٦' },
    title: 'জেনারেল (প্লে–দশম) ও ক্যাডেট প্রোগ্রামের সম্প্রসারণ',
    titleEn: 'General (Play to Ten) & Cadet Program Expansion',
    titleAr: 'توسيع القسم العام وبرنامج الكاديت',
    summary:
      'আধুনিক বিজ্ঞান গবেষণাগার, কেন্দ্রীয় পাঠাগার, পূর্ণাঙ্গ জেনারেল (প্লে–দশম) শাখা এবং দুই বছর মেয়াদী বিশেষায়িত ক্যাডেট প্রস্তুতি প্রোগ্রামের মাধ্যমে একাডেমিক ভবন সম্প্রসারণ।',
    summaryByLang: {
      bn: 'আধুনিক বিজ্ঞান গবেষণাগার, কেন্দ্রীয় পাঠাগার, পূর্ণাঙ্গ জেনারেল (প্লে–দশম) শাখা এবং দুই বছর মেয়াদী বিশেষায়িত ক্যাডেট প্রস্তুতি প্রোগ্রামের মাধ্যমে একাডেমিক ভবন সম্প্রসারণ।',
      en: 'Expanded the academic complex with STEM laboratories, a central reading room, the complete General (Play to Ten) wing, and the specialized Two-Year Cadet Preparation Program.',
      ar: 'توسيع المجمع التعليمي بمختبرات العلوم والمكتبة المركزية واستكمال القسم العام وبرنامج الكاديت التخصصي لمدة سنتين.',
    },
  },
  {
    period: 'শিক্ষাবর্ষ ২০২৬–২০২৭',
    periodByLang: { bn: 'শিক্ষাবর্ষ ২০২৬–২০২৭', en: 'Session 2026–2027', ar: 'العام الدراسي ٢٠٢٦–٢٠٢٧' },
    title: 'মেধা ও হিফজ বৃত্তি তহবিল এবং আবাসিক সুবিধা',
    titleEn: 'Merit & Hifz Scholarship Endowment',
    titleAr: 'منح التفوق العلمي وحفظ القرآن والسكن الداخلي',
    summary:
      'দূরবর্তী শিক্ষার্থীদের জন্য নিরাপদ আবাসিক হোস্টেল চালুর পাশাপাশি ২৫% একাডেমিক মেধা বৃত্তি ও ৫০% হিফজুল কুরআন উৎকর্ষ বৃত্তি প্রবর্তন।',
    summaryByLang: {
      bn: 'দূরবর্তী শিক্ষার্থীদের জন্য নিরাপদ আবাসিক হোস্টেল চালুর পাশাপাশি ২৫% একাডেমিক মেধা বৃত্তি ও ৫০% হিফজুল কুরআন উৎকর্ষ বৃত্তি প্রবর্তন।',
      en: 'Instituted annual 25% Academic Merit and 50% Hifzul Quran Excellence grants alongside residential hostel facilities for out-of-district scholars.',
      ar: 'إقرار منح التفوق الأكاديمي بنسبة ٢٥٪ ومنح التميز في حفظ القرآن بنسبة ٥٠٪ مع توفير سكن داخلي آمن للطلاب القادمين من خارج المنطقة.',
    },
  },
];

export const ACADEMIC_PROGRAMS: AcademicProgram[] = [
  {
    id: 'general',
    code: 'SEC-01',
    title: 'General (Play to Ten)',
    bnTitle: 'জেনারেল বিভাগ (প্লে থেকে দশম শ্রেণি)',
    arTitle: 'القسم العام (من الروضة إلى العاشر)',
    grades: 'প্লে-গ্রুপ – দশম শ্রেণি',
    gradesByLang: {
      bn: 'প্লে-গ্রুপ – দশম শ্রেণি',
      en: 'Playgroup – Class X',
      ar: 'من الروضة حتى الصف العاشر',
    },
    ageRange: 'বয়স ৪ – ১৬ বছর',
    ageRangeByLang: {
      bn: 'বয়স ৪ – ১৬ বছর',
      en: 'Ages 4 – 16',
      ar: 'الأعمار ٤ – ١٦ سنة',
    },
    shiftSummary: 'প্রভাতী ও দিবা শাখা · ০৮:০০ – ১৪:৩০',
    shiftSummaryByLang: {
      bn: 'প্রভাতী ও দিবা শাখা · ০৮:০০ – ১৪:৩০',
      en: 'Morning & Day Shifts · 08:00 – 14:30',
      ar: 'الفترتان الصباحية والمسائية · ٠٨:٠٠ – ١٤:٣٠',
    },
    summary:
      'প্লে-গ্রুপ থেকে দশম শ্রেণি পর্যন্ত জাতীয় শিক্ষাক্রম অনুযায়ী পদার্থবিজ্ঞান, রসায়ন, উচ্চতর গণিত, ইংরেজি ও আইসিটি শিক্ষার পাশাপাশি প্রতিদিনের ইসলামিক স্টাডিজ ও নাযেরা কুরআন তিলাওয়াতের সমন্বিত পাঠদান।',
    summaryByLang: {
      bn: 'প্লে-গ্রুপ থেকে দশম শ্রেণি পর্যন্ত জাতীয় শিক্ষাক্রম অনুযায়ী পদার্থবিজ্ঞান, রসায়ন, উচ্চতর গণিত, ইংরেজি ও আইসিটি শিক্ষার পাশাপাশি প্রতিদিনের ইসলামিক স্টাডিজ ও নাযেরা কুরআন তিলাওয়াতের সমন্বিত পাঠদান।',
      en: 'Complete National Curriculum education from Playgroup through Class X integrating Physics, Chemistry, Higher Mathematics, English, and ICT alongside daily Islamic Studies and Quran recitation.',
      ar: 'تعليم متكامل وفق المنهج الوطني من الروضة حتى الصف العاشر يجمع بين الفيزياء والكيمياء والرياضيات المتقدمة والإنجليزية وتقنية المعلومات مع الدراسات الإسلامية وتلاوة القرآن اليومية.',
    },
    highlightByLang: {
      bn: 'জাতীয় শিক্ষাক্রম, বিজ্ঞান গবেষণাগার ও দৈনন্দিন ইসলামী শিক্ষা।',
      en: 'National Curriculum, science labs & daily Islamic studies.',
      ar: 'المنهج الوطني والمختبرات العلمية والتربية الإسلامية.',
    },
    seatCapacity: 180,
    studentTeacherRatio: '৩০:১',
    studentTeacherRatioByLang: { bn: '৩০:১', en: '30:1', ar: '٣٠:١' },
    modules: [
      {
        code: 'GEN-101',
        subject: 'ইসলাম শিক্ষা, সীরাত ও দৈনন্দিন আদব',
        subjectByLang: {
          bn: 'ইসলাম শিক্ষা, সীরাত ও দৈনন্দিন আদব',
          en: 'Islamic Studies, Seerah & Daily Adab',
          ar: 'التربية الإسلامية والسيرة والآداب اليومية',
        },
        stream: 'ইসলামিক সায়েন্সেস',
        streamByLang: { bn: 'ইসলামিক সায়েন্সেস', en: 'Islamic Sciences', ar: 'العلوم الإسلامية' },
        hoursPerWeek: 2,
        hoursByMode: { morning: 2, day: 4, residential: 12 },
      },
      {
        code: 'QRN-102',
        subject: 'নাযেরা কুরআন ও ব্যবহারিক তাজবিদ',
        subjectByLang: {
          bn: 'নাযেরা কুরআন ও ব্যবহারিক তাজবিদ',
          en: 'Nazirah Quran & Practical Tajweed',
          ar: 'تلاوة القرآن نظراً والتجويد العملي',
        },
        stream: 'ইসলামিক সায়েন্সেস',
        streamByLang: { bn: 'ইসলামিক সায়েন্সেস', en: 'Islamic Sciences', ar: 'العلوم الإسلامية' },
        hoursPerWeek: 2,
        hoursByMode: { morning: 2, day: 3, residential: 12 },
      },
      {
        code: 'MTH-103',
        subject: 'সাধারণ ও উচ্চতর গণিত',
        subjectByLang: {
          bn: 'সাধারণ ও উচ্চতর গণিত',
          en: 'General & Higher Mathematics',
          ar: 'الرياضيات العامة والمتقدمة',
        },
        stream: 'বিজ্ঞান ও বিশ্লেষণ',
        streamByLang: { bn: 'বিজ্ঞান ও বিশ্লেষণ', en: 'STEM & Analytical', ar: 'العلوم والتحليل' },
        hoursPerWeek: 4,
        hoursByMode: { morning: 4, day: 6, residential: 18 },
      },
      {
        code: 'SCI-104',
        subject: 'পদার্থ, রসায়ন, জীববিজ্ঞান ও ল্যাব ব্যবহারিক',
        subjectByLang: {
          bn: 'পদার্থ, রসায়ন, জীববিজ্ঞান ও ল্যাব ব্যবহারিক',
          en: 'Physics, Chemistry, Biology & Lab Practicum',
          ar: 'الفيزياء والكيمياء والأحياء والتطبيق المخبري',
        },
        stream: 'বিজ্ঞান ও বিশ্লেষণ',
        streamByLang: { bn: 'বিজ্ঞান ও বিশ্লেষণ', en: 'STEM & Analytical', ar: 'العلوم والتحليل' },
        hoursPerWeek: 5,
        hoursByMode: { morning: 5, day: 8, residential: 20 },
      },
      {
        code: 'LNG-105',
        subject: 'ইংরেজি, বাংলা ও একাডেমিক আইসিটি',
        subjectByLang: {
          bn: 'ইংরেজি, বাংলা ও একাডেমিক আইসিটি',
          en: 'English, Bengali & Academic ICT',
          ar: 'اللغة الإنجليزية والبنغالية وتقنية المعلومات',
        },
        stream: 'ভাষা ও ক্যাডেট প্রস্তুতি',
        streamByLang: { bn: 'ভাষা ও ক্যাডেট প্রস্তুতি', en: 'Languages & Prep', ar: 'اللغات والإعداد' },
        hoursPerWeek: 5,
        hoursByMode: { morning: 5, day: 7, residential: 18 },
      },
    ],
  },
  {
    id: 'cadet',
    code: 'SEC-02',
    title: 'Cadet (Two Years Program)',
    bnTitle: 'ক্যাডেট বিভাগ (দুই বছর মেয়াদী প্রোগ্রাম)',
    arTitle: 'قسم الكاديت (برنامج السنتين)',
    grades: 'পঞ্চম–ষষ্ঠ / সপ্তম শ্রেণি নিবিড় ব্যাচ',
    gradesByLang: {
      bn: 'পঞ্চম–ষষ্ঠ / সপ্তম শ্রেণি নিবিড় ব্যাচ',
      en: 'Classes V–VI / VII Intensive',
      ar: 'مجموعة مكثفة للصفوف الخامس والسادس والسابع',
    },
    ageRange: 'বয়স ১০ – ১৩ বছর',
    ageRangeByLang: { bn: 'বয়স ১০ – ১৩ বছর', en: 'Ages 10 – 13', ar: 'الأعمار ١٠ – ١٣ سنة' },
    shiftSummary: 'পূর্ণ দিবস নিবিড় প্রশিক্ষণ · ০৭:৪৫ – ১৫:৩০',
    shiftSummaryByLang: {
      bn: 'পূর্ণ দিবস নিবিড় প্রশিক্ষণ · ০৭:৪৫ – ১৫:৩০',
      en: 'Full Intensive Day · 07:45 – 15:30',
      ar: 'يوم دراسي مكثف · ٠٧:٤٥ – ١٥:٣٠',
    },
    summary:
      'ক্যাডেট কলেজ ভর্তি পরীক্ষার মানদণ্ড অনুযায়ী দুই বছর মেয়াদী সুপরিকল্পিত প্রস্তুতি কোর্স—যেখানে দৈনন্দিন গণিত অনুশীলন, ইংরেজি রচনা, বাংলা ব্যাকরণ ও নির্মিতি, সাধারণ জ্ঞান শিক্ষা (বাংলাদেশ ও আন্তর্জাতিক বিষয়াবলি), আইকিউ যুক্তিবিদ্যা এবং ইসলামী চরিত্র গঠনের ওপর বিশেষ গুরুত্ব দেওয়া হয়।',
    summaryByLang: {
      bn: 'ক্যাডেট কলেজ ভর্তি পরীক্ষার মানদণ্ড অনুযায়ী দুই বছর মেয়াদী সুপরিকল্পিত প্রস্তুতি কোর্স—যেখানে দৈনন্দিন গণিত অনুশীলন, ইংরেজি রচনা, বাংলা ব্যাকরণ ও নির্মিতি, সাধারণ জ্ঞান শিক্ষা (বাংলাদেশ ও আন্তর্জাতিক বিষয়াবলি), আইকিউ যুক্তিবিদ্যা এবং ইসলামী চরিত্র গঠনের ওপর বিশেষ গুরুত্ব দেওয়া হয়।',
      en: 'Structured two-year preparatory academy targeting Cadet College admission standards through daily Mathematics, English composition, Bangla grammar & literature, structured General Knowledge education, IQ drills, and Islamic character mentorship.',
      ar: 'أكاديمية إعداد منظمة لمدة عامين للالتحاق بكليات الكاديت من خلال التدريب اليومي على الرياضيات والإنشاء الإنجليزي واللغة البنغالية وتعليم المعرفة العامة واختبارات الذكاء والتربية الإسلامية.',
    },
    highlightByLang: {
      bn: 'দুই বছর মেয়াদী বাংলা, ইংরেজি, গণিত, সাধারণ জ্ঞান শিক্ষা ও আইকিউ-ভাইভা প্রস্তুতি।',
      en: '2-year Bangla, English, Math, General Knowledge & IQ prep.',
      ar: 'إعداد لمدة سنتين في البنغالية والإنجليزية والرياضيات والمعرفة العامة والذكاء.',
    },
    seatCapacity: 60,
    studentTeacherRatio: '৩০:১',
    studentTeacherRatioByLang: { bn: '৩০:১', en: '30:1', ar: '٣٠:١' },
    modules: [
      {
        code: 'CDT-201',
        subject: 'প্রতিযোগিতামূলক গণিত ও বিশ্লেষণাত্মক যুক্তি',
        subjectByLang: {
          bn: 'প্রতিযোগিতামূলক গণিত ও বিশ্লেষণাত্মক যুক্তি',
          en: 'Competitive Mathematics & Analytical Reasoning',
          ar: 'الرياضيات التنافسية والتفكير التحليلي',
        },
        stream: 'বিজ্ঞান ও বিশ্লেষণ',
        streamByLang: { bn: 'বিজ্ঞান ও বিশ্লেষণ', en: 'STEM & Analytical', ar: 'العلوم والتحليل' },
        hoursPerWeek: 7,
        hoursByMode: { morning: 7, day: 7, residential: 20 },
      },
      {
        code: 'CDT-202',
        subject: 'ইংরেজি গ্রামার, প্রবন্ধ ও কম্প্রিহেনশন',
        subjectByLang: {
          bn: 'ইংরেজি গ্রামার, প্রবন্ধ ও কম্প্রিহেনশন',
          en: 'English Grammar, Essay & Comprehension',
          ar: 'قواعد اللغة الإنجليزية والإنشاء والاستيعاب',
        },
        stream: 'ভাষা ও ক্যাডেট প্রস্তুতি',
        streamByLang: { bn: 'ভাষা ও ক্যাডেট প্রস্তুতি', en: 'Languages & Cadet Prep', ar: 'اللغات وإعداد الكاديت' },
        hoursPerWeek: 6,
        hoursByMode: { morning: 6, day: 6, residential: 16 },
      },
      {
        code: 'CDT-203',
        subject: 'বাংলা ভাষা, ব্যাকরণ, রচনা ও সাহিত্য পাঠ',
        subjectByLang: {
          bn: 'বাংলা ভাষা, ব্যাকরণ, রচনা ও সাহিত্য পাঠ',
          en: 'Bangla Language, Grammar & Composition',
          ar: 'اللغة البنغالية وقواعدها والإنشاء',
        },
        stream: 'ভাষা ও ক্যাডেট প্রস্তুতি',
        streamByLang: { bn: 'ভাষা ও ক্যাডেট প্রস্তুতি', en: 'Languages & Cadet Prep', ar: 'اللغات وإعداد الكاديت' },
        hoursPerWeek: 5,
        hoursByMode: { morning: 5, day: 5, residential: 12 },
      },
      {
        code: 'CDT-204',
        subject: 'সাধারণ জ্ঞান শিক্ষা, সাধারণ বিজ্ঞান ও আইকিউ পরীক্ষা',
        subjectByLang: {
          bn: 'সাধারণ জ্ঞান শিক্ষা, সাধারণ বিজ্ঞান ও আইকিউ পরীক্ষা',
          en: 'General Knowledge Education, Science & IQ Logic',
          ar: 'تعليم المعرفة العامة والعلوم العامة والمنطق الذهني',
        },
        stream: 'বিজ্ঞান ও বিশ্লেষণ',
        streamByLang: { bn: 'বিজ্ঞান ও বিশ্লেষণ', en: 'STEM & Analytical', ar: 'العلوم والتحليل' },
        hoursPerWeek: 5,
        hoursByMode: { morning: 5, day: 5, residential: 14 },
      },
      {
        code: 'CDT-205',
        subject: 'ভাইভা-ভোস, নেতৃত্ব ও শারীরিক ড্রিলে প্রশিক্ষণ',
        subjectByLang: {
          bn: 'ভাইভা-ভোস, নেতৃত্ব ও শারীরিক ড্রিলে প্রশিক্ষণ',
          en: 'Viva-Voce, Leadership & Physical Drill',
          ar: 'المقابلات الشفهية والقيادة والتدريب البدني',
        },
        stream: 'ভাষা ও ক্যাডেট প্রস্তুতি',
        streamByLang: { bn: 'ভাষা ও ক্যাডেট প্রস্তুতি', en: 'Languages & Cadet Prep', ar: 'اللغات وإعداد الكاديت' },
        hoursPerWeek: 4,
        hoursByMode: { morning: 4, day: 4, residential: 10 },
      },
      {
        code: 'ISL-206',
        subject: 'কুরআনিক নৈতিকতা, সালাত ও মাসনূন দোয়া',
        subjectByLang: {
          bn: 'কুরআনিক নৈতিকতা, সালাত ও মাসনূন দোয়া',
          en: 'Quranic Ethics, Salah & Daily Adhkar',
          ar: 'الأخلاق القرآنية والصلاة والأذكار اليومية',
        },
        stream: 'ইসলামিক সায়েন্সেস',
        streamByLang: { bn: 'ইসলামিক সায়েন্সেস', en: 'Islamic Sciences', ar: 'العلوم الإسلامية' },
        hoursPerWeek: 3,
        hoursByMode: { morning: 3, day: 3, residential: 8 },
      },
    ],
  },
  {
    id: 'noorani',
    code: 'SEC-03',
    title: 'Noorani (Quyeda, Ampar and Quran)',
    bnTitle: 'নূরানী বিভাগ (কায়েদা, আমপারা ও কুরআন)',
    arTitle: 'قسم النوراني (القاعدة وعمّ والقرآن)',
    grades: 'নূরানী স্তর ১ – ৩',
    gradesByLang: { bn: 'নূরানী স্তর ১ – ৩', en: 'Noorani Levels I – III', ar: 'المستويات النورانية ١ – ٣' },
    ageRange: 'বয়স ৪ – ৯ বছর',
    ageRangeByLang: { bn: 'বয়স ৪ – ৯ বছর', en: 'Ages 4 – 9', ar: 'الأعمار ٤ – ٩ سنوات' },
    shiftSummary: 'প্রভাতী শাখা · ০৮:০০ – ১২:৪৫',
    shiftSummaryByLang: {
      bn: 'প্রভাতী শাখা · ০৮:০০ – ১২:৪৫',
      en: 'Morning Shift · 08:00 – 12:45',
      ar: 'الفترة الصباحية · ٠٨:٠٠ – ١٢:٤٥',
    },
    summary:
      'যারা হিফজুল কুরআন সম্পন্ন করতে ইচ্ছুক তাদের জন্য এই বিভাগ। এই বিভাগের শিক্ষার্থীদের জেনারেল ক্লাসের পাশাপাশি অতিরিক্ত সময় কুরআন ক্লাস হয়, যার মাধ্যমে একজন শিক্ষার্থী হিফজ করার পূর্ণ সক্ষমতা অর্জন করেন।',
    summaryByLang: {
      bn: 'যারা হিফজুল কুরআন সম্পন্ন করতে ইচ্ছুক তাদের জন্য এই বিভাগ। এই বিভাগের শিক্ষার্থীদের জেনারেল ক্লাসের পাশাপাশি অতিরিক্ত সময় কুরআন ক্লাস হয়, যার মাধ্যমে একজন শিক্ষার্থী হিফজ করার পূর্ণ সক্ষমতা অর্জন করেন।',
      en: 'Designed specifically for students aspiring to complete Hifzul Quran. Alongside regular General academic classes, learners receive dedicated extra hours of Noorani Quyeda, Ampar, and Quran instruction so each student develops full readiness and capability for Hifz.',
      ar: 'صُمم هذا القسم خصيصاً للطلاب الراغبين في إتمام حفظ القرآن الكريم؛ حيث يحصل الطالب فيه على حصص إضافية مكثفة في القاعدة النورانية وعمّ والقرآن إلى جانب الدروس العامة، مما يؤهله لاكتساب القدرة الكاملة على الحفظ.',
    },
    highlightByLang: {
      bn: 'হিফজ আগ্রহীদের জন্য জেনারেল ক্লাসের পাশাপাশি অতিরিক্ত কুরআন ক্লাস।',
      en: 'For future Huffaz: General classes + extra Quran hours for Hifz readiness.',
      ar: 'للراغبين في الحفظ: دروس عامة + حصص قرآن إضافية للتأهيل.',
    },
    seatCapacity: 90,
    studentTeacherRatio: '৩০:১',
    studentTeacherRatioByLang: { bn: '৩০:১', en: '30:1', ar: '٣٠:١' },
    modules: [
      {
        code: 'NRN-301',
        subject: 'নূরানী কায়েদা, সহীহ মাখরাজ ও আমপারা (জুয আম্মা)',
        subjectByLang: {
          bn: 'নূরানী কায়েদা, সহীহ মাখরাজ ও আমপারা (জুয আম্মা)',
          en: 'Noorani Quyeda, Makharij & Ampar (Juz Amma)',
          ar: 'القاعدة النورانية وإتقان المخارج وجزء عمّ',
        },
        stream: 'ইসলামিক সায়েন্সেস',
        streamByLang: { bn: 'ইসলামিক সায়েন্সেস', en: 'Islamic Sciences', ar: 'العلوم الإسلامية' },
        hoursPerWeek: 6,
        hoursByMode: { morning: 6, day: 8, residential: 20 },
      },
      {
        code: 'NRN-302',
        subject: 'অতিরিক্ত সময় কুরআন ক্লাস (হিফজ প্রস্তুতি ও সক্ষমতা অর্জন)',
        subjectByLang: {
          bn: 'অতিরিক্ত সময় কুরআন ক্লাস (হিফজ প্রস্তুতি ও সক্ষমতা অর্জন)',
          en: 'Extra-Hour Quran Class (Hifz Readiness & Fluency)',
          ar: 'حصص القرآن الإضافية (الإعداد والتأهيل لحفظ القرآن)',
        },
        stream: 'ইসলামিক সায়েন্সেস',
        streamByLang: { bn: 'ইসলামিক সায়েন্সেস', en: 'Islamic Sciences', ar: 'العلوم الإسلامية' },
        hoursPerWeek: 7,
        hoursByMode: { morning: 7, day: 10, residential: 26 },
      },
      {
        code: 'NRN-303',
        subject: 'তাজবিদসহ সাবলীল নাযেরা কুরআন ও মাসনূন দোয়া',
        subjectByLang: {
          bn: 'তাজবিদসহ সাবলীল নাযেরা কুরআন ও মাসনূন দোয়া',
          en: 'Fluent Nazirah Quran Recitation & Masnoon Duas',
          ar: 'التلاوة السلسة بالتجويد والأدعية المأثورة',
        },
        stream: 'ইসলামিক সায়েন্সেস',
        streamByLang: { bn: 'ইসলামিক সায়েন্সেস', en: 'Islamic Sciences', ar: 'العلوم الإسلامية' },
        hoursPerWeek: 4,
        hoursByMode: { morning: 4, day: 6, residential: 14 },
      },
      {
        code: 'FND-304',
        subject: 'জেনারেল ক্লাস: বাংলা, ইংরেজি ও সাধারণ জ্ঞান',
        subjectByLang: {
          bn: 'জেনারেল ক্লাস: বাংলা, ইংরেজি ও সাধারণ জ্ঞান',
          en: 'General Classes: Bangla, English & Literacy',
          ar: 'الدروس العامة: البنغالية والإنجليزية ومهارات القراءة',
        },
        stream: 'ভাষা ও ক্যাডেট প্রস্তুতি',
        streamByLang: { bn: 'ভাষা ও ক্যাডেট প্রস্তুতি', en: 'Languages & Prep', ar: 'اللغات والإعداد' },
        hoursPerWeek: 4,
        hoursByMode: { morning: 4, day: 5, residential: 10 },
      },
      {
        code: 'NUM-305',
        subject: 'জেনারেল ক্লাস: প্রাথমিক গণিত ও হস্তাক্ষর চর্চা',
        subjectByLang: {
          bn: 'জেনারেল ক্লাস: প্রাথমিক গণিত ও হস্তাক্ষর চর্চা',
          en: 'General Classes: Primary Math & Handwriting',
          ar: 'الدروس العامة: الحساب الأساسي وتحسين الخط',
        },
        stream: 'বিজ্ঞান ও বিশ্লেষণ',
        streamByLang: { bn: 'বিজ্ঞান ও বিশ্লেষণ', en: 'STEM & Analytical', ar: 'العلوم والتحليل' },
        hoursPerWeek: 3,
        hoursByMode: { morning: 3, day: 5, residential: 10 },
      },
    ],
  },
  {
    id: 'hifzul-quran',
    code: 'SEC-04',
    title: 'Hifzul Quran',
    bnTitle: 'হিফজুল কুরআন বিভাগ',
    arTitle: 'قسم تحفيظ القرآن الكريم',
    grades: 'পূর্ণাঙ্গ হিফজ ও একাডেমিক সেতু',
    gradesByLang: {
      bn: 'পূর্ণাঙ্গ হিফজ ও একাডেমিক সেতু',
      en: 'Full Hifz & Academic Bridge',
      ar: 'الحفظ الكامل والجسر الأكاديمي',
    },
    ageRange: 'বয়স ৭ – ১৫ বছর',
    ageRangeByLang: { bn: 'বয়স ৭ – ১৫ বছর', en: 'Ages 7 – 15', ar: 'الأعمار ٧ – ١٥ سنة' },
    shiftSummary: 'পূর্ণ একাডেমিক দিবস · ০৬:৩০ – ১৫:৪৫',
    shiftSummaryByLang: {
      bn: 'পূর্ণ একাডেমিক দিবস · ০৬:৩০ – ১৫:৪৫',
      en: 'Full Academic Day · 06:30 – 15:45',
      ar: 'يوم دراسي كامل · ٠٦:٣٠ – ١٥:٤٥',
    },
    summary:
      'এই বিভাগের শিক্ষার্থীদের নিয়মিত সবক, সাত-সবক ও আমুক্তা নেওয়া হয় এবং অভিজ্ঞ কারী ও হাফেজ শিক্ষকদের মাধ্যমে তেলাওয়াত ও সবিনা নিয়মিত তদারকি করা হয়। পাশাপাশি জেনারেল বিভাগের বেসিক—বাংলা, ইংরেজি, গণিত ও আরবি ভাষার ক্লাসের সুব্যবস্থা রয়েছে।',
    summaryByLang: {
      bn: 'এই বিভাগের শিক্ষার্থীদের নিয়মিত সবক, সাত-সবক ও আমুক্তা নেওয়া হয় এবং অভিজ্ঞ কারী ও হাফেজ শিক্ষকদের মাধ্যমে তেলাওয়াত ও সবিনা নিয়মিত তদারকি করা হয়। পাশাপাশি জেনারেল বিভাগের বেসিক—বাংলা, ইংরেজি, গণিত ও আরবি ভাষার ক্লাসের সুব্যবস্থা রয়েছে।',
      en: 'Students in this division complete daily Sabaq (new lesson), Saat-Sabaq (recent seven-day revision), and Amukhta (cumulative review), with Tilawat and Sabina recitation closely supervised by certified Huffaz and Qaris—paired with structured classes in foundational Bangla, English, Mathematics, and Arabic.',
      ar: 'يتم في هذا القسم تسميع السبق والسبع سبق والأمختة يومياً بانتظام، مع المتابعة الدقيقة للتلاوة والسبينا بإشراف حفاظ وقراء مجازين، إلى جانب فصول منظمة في الأساسيات العامة: البنغالية والإنجليزية والرياضيات واللغة العربية.',
    },
    highlightByLang: {
      bn: 'নিয়মিত সবক, সাত-সবক, আমুক্তা, তেলাওয়াত ও সবিনা + বাংলা, ইংরেজি, গণিত ও আরবি।',
      en: 'Daily Sabaq, Saat-Sabaq, Amukhta, Tilawat & Sabina + Bangla, English, Math & Arabic.',
      ar: 'السبق والسبع سبق والأمختة والتلاوة والسبينا + البنغالية والإنجليزية والرياضيات والعربية.',
    },
    seatCapacity: 70,
    studentTeacherRatio: '৩০:১',
    studentTeacherRatioByLang: { bn: '৩০:১', en: '30:1', ar: '٣٠:١' },
    modules: [
      {
        code: 'HFZ-401',
        subject: 'নিয়মিত সবক, সাত-সবক ও আমুক্তা আদায়',
        subjectByLang: {
          bn: 'নিয়মিত সবক, সাত-সবক ও আমুক্তা আদায়',
          en: 'Daily Sabaq, Saat-Sabaq & Amukhta Circles',
          ar: 'حلقات التسميع اليومية (السبق والسبع سبق والأمختة)',
        },
        stream: 'ইসলামিক সায়েন্সেস',
        streamByLang: { bn: 'ইসলামিক সায়েন্সেস', en: 'Islamic Sciences', ar: 'العلوم الإسلامية' },
        hoursPerWeek: 44,
        hoursByMode: { morning: 44, day: 44, residential: 44 },
      },
      {
        code: 'HFZ-402',
        subject: 'নিয়মিত তেলাওয়াত, তাজবিদ ও সবিনা তদারকি',
        subjectByLang: {
          bn: 'নিয়মিত তেলাওয়াত, তাজবিদ ও সবিনা তদারকি',
          en: 'Tilawat, Applied Tajweed & Sabina Supervision',
          ar: 'التلاوة المتقنة والتجويد وإشراف السبينا المنتظم',
        },
        stream: 'ইসলামিক সায়েন্সেস',
        streamByLang: { bn: 'ইসলামিক সায়েন্সেস', en: 'Islamic Sciences', ar: 'العلوم الإسلامية' },
        hoursPerWeek: 16,
        hoursByMode: { morning: 16, day: 16, residential: 16 },
      },
      {
        code: 'HFZ-403',
        subject: 'জেনারেল বেসিক: বাংলা ও ইংরেজি ভাষা ক্লাস',
        subjectByLang: {
          bn: 'জেনারেল বেসিক: বাংলা ও ইংরেজি ভাষা ক্লাস',
          en: 'General Basics: Bangla & English Language',
          ar: 'الأساسيات العامة: البنغالية والإنجليزية',
        },
        stream: 'ভাষা ও ক্যাডেট প্রস্তুতি',
        streamByLang: { bn: 'ভাষা ও ক্যাডেট প্রস্তুতি', en: 'Languages & Prep', ar: 'اللغات والإعداد' },
        hoursPerWeek: 8,
        hoursByMode: { morning: 8, day: 8, residential: 8 },
      },
      {
        code: 'HFZ-404',
        subject: 'জেনারেল বেসিক: গণিত ও যৌক্তিক সংখ্যাবিজ্ঞান',
        subjectByLang: {
          bn: 'জেনারেল বেসিক: গণিত ও যৌক্তিক সংখ্যাবিজ্ঞান',
          en: 'General Basics: Mathematics & Numeracy',
          ar: 'الأساسيات العامة: الرياضيات والحساب',
        },
        stream: 'বিজ্ঞান ও বিশ্লেষণ',
        streamByLang: { bn: 'বিজ্ঞান ও বিশ্লেষণ', en: 'STEM & Analytical', ar: 'العلوم والتحليل' },
        hoursPerWeek: 6,
        hoursByMode: { morning: 6, day: 6, residential: 6 },
      },
      {
        code: 'HFZ-405',
        subject: 'আরবি ভাষা দক্ষতা ও মৌলিক দ্বীনি শিক্ষা',
        subjectByLang: {
          bn: 'আরবি ভাষা দক্ষতা ও মৌলিক দ্বীনি শিক্ষা',
          en: 'Arabic Language Fluency & Essential Islamic Studies',
          ar: 'مهارات اللغة العربية والأساسيات الشرعية',
        },
        stream: 'ভাষা ও ক্যাডেট প্রস্তুতি',
        streamByLang: { bn: 'ভাষা ও ক্যাডেট প্রস্তুতি', en: 'Languages & Prep', ar: 'اللغات والإعداد' },
        hoursPerWeek: 6,
        hoursByMode: { morning: 6, day: 6, residential: 6 },
      },
    ],
  },
];

export const FACULTY_MEMBERS: FacultyMember[] = [
  {
    id: 'fac-1',
    name: 'মাওলানা ড. তারিকুল ইসলাম',
    nameEn: 'Mawlana Dr. Tariqul Islam',
    nameAr: 'مولانا الدكتور طارق الإسلام',
    role: 'অধ্যক্ষ ও ইসলামী ফিকহ বিভাগীয় প্রধান',
    roleByLang: {
      bn: 'অধ্যক্ষ ও ইসলামী ফিকহ বিভাগীয় প্রধান',
      en: 'Principal & Chair of Islamic Jurisprudence',
      ar: 'مدير المؤسسة ورئيس قسم الفقه الإسلامي',
    },
    department: 'Islamic Studies',
    departmentLabel: 'ইসলামিক স্টাডিজ',
    departmentLabelByLang: { bn: 'ইসলামিক স্টাডিজ', en: 'Islamic Studies', ar: 'الدراسات الإسلامية' },
    credentials: 'পিএইচডি (উসূলুল ফিকহ), আল-আজহার বিশ্ববিদ্যালয় · কামিল (হাদিস)',
    credentialsByLang: {
      bn: 'পিএইচডি (উসূলুল ফিকহ), আল-আজহার বিশ্ববিদ্যালয় · কামিল (হাদিস)',
      en: 'PhD in Usul al-Fiqh, Al-Azhar University · Kamil (Hadith)',
      ar: 'دكتوراه في أصول الفقه، جامعة الأزهر · كامل في الحديث',
    },
    officeHours: 'রবি ও মঙ্গল · ১১:০০ – ১৩:০০',
    officeHoursByLang: {
      bn: 'রবি ও মঙ্গল · ১১:০০ – ১৩:০০',
      en: 'Sun & Tue · 11:00 – 13:00',
      ar: 'الأحد والثلاثاء · ١١:٠٠ – ١٣:٠٠',
    },
    focus: 'ধ্রুপদী মাদ্রাসা শিক্ষাক্রম ও আধুনিক একাডেমিক উৎকর্ষের মধ্যে সেতুবন্ধন তৈরির সমন্বিত পাঠদান পদ্ধতি।',
    focusByLang: {
      bn: 'ধ্রুপদী মাদ্রাসা শিক্ষাক্রম ও আধুনিক একাডেমিক উৎকর্ষের মধ্যে সেতুবন্ধন তৈরির সমন্বিত পাঠদান পদ্ধতি।',
      en: 'Integrative pedagogy bridging classical madrasa curricula with modern academic excellence.',
      ar: 'منهجية تربوية متكاملة تجمع بين المناهج الشرعية الأصيلة والتميز الأكاديمي الحديث.',
    },
  },
  {
    id: 'fac-2',
    name: 'অধ্যাপক নুসরাত জাহান চৌধুরী',
    nameEn: 'Prof. Nusrat Jahan Chowdhury',
    nameAr: 'الأستاذة نصرت جهان شودري',
    role: 'উপাধ্যক্ষ ও জেনারেল বিভাগ (প্লে–দশম) প্রধান',
    roleByLang: {
      bn: 'উপাধ্যক্ষ ও জেনারেল বিভাগ (প্লে–দশম) প্রধান',
      en: 'Vice Principal & Head of General Wing (Play to Ten)',
      ar: 'نائبة المدير ورئيسة القسم العام',
    },
    department: 'Sciences',
    departmentLabel: 'বিজ্ঞান বিভাগ',
    departmentLabelByLang: { bn: 'বিজ্ঞান বিভাগ', en: 'Sciences', ar: 'العلوم' },
    credentials: 'এম.এসসি (ফলিত পদার্থবিজ্ঞান), ঢাকা বিশ্ববিদ্যালয় · ১৪ বছরের অভিজ্ঞতা',
    credentialsByLang: {
      bn: 'এম.এসসি (ফলিত পদার্থবিজ্ঞান), ঢাকা বিশ্ববিদ্যালয় · ১৪ বছরের অভিজ্ঞতা',
      en: 'M.Sc. Applied Physics, University of Dhaka · 14 yrs teaching',
      ar: 'ماجستير الفيزياء التطبيقية، جامعة دكا · ١٤ عاماً خبرة',
    },
    officeHours: 'সোম ও বুধ · ১৩:৩০ – ১৫:০০',
    officeHoursByLang: {
      bn: 'সোম ও বুধ · ১৩:৩০ – ১৫:০০',
      en: 'Mon & Wed · 13:30 – 15:00',
      ar: 'الاثنين والأربعاء · ١٣:٣٠ – ١٥:٠٠',
    },
    focus: 'ষষ্ঠ থেকে দশম শ্রেণির শিক্ষার্থীদের ব্যবহারিক বিজ্ঞান শিক্ষা ও এসএসসি বোর্ড পরীক্ষার বিশেষ প্রস্তুতি।',
    focusByLang: {
      bn: 'ষষ্ঠ থেকে দশম শ্রেণির শিক্ষার্থীদের ব্যবহারিক বিজ্ঞান শিক্ষা ও এসএসসি বোর্ড পরীক্ষার বিশেষ প্রস্তুতি।',
      en: 'Experimental science instruction and SSC board preparation for Classes VI–X.',
      ar: 'تدريس العلوم التطبيقية وإعداد طلاب الصفوف من السادس إلى العاشر لامتحانات الشهادة.',
    },
  },
  {
    id: 'fac-3',
    name: 'কারী হাফেজ আব্দুর রহমান',
    nameEn: 'Qari Hafiz Abdur Rahman',
    nameAr: 'القارئ الحافظ عبد الرحمن',
    role: 'ডিন, হিফজুল কুরআন ও নূরানী (Noorani) বিজ্ঞান',
    roleByLang: {
      bn: 'ডিন, হিফজুল কুরআন ও নূরানী (Noorani) বিজ্ঞান',
      en: 'Dean of Hifzul Quran & Noorani Sciences',
      ar: 'عميد قسم تحفيظ القرآن والعلوم النورانية',
    },
    department: 'Islamic Studies',
    departmentLabel: 'ইসলামিক স্টাডিজ',
    departmentLabelByLang: { bn: 'ইসলামিক স্টাডিজ', en: 'Islamic Studies', ar: 'الدراسات الإسلامية' },
    credentials: 'আশারা কিরাত সনদপ্রাপ্ত · ১৮ বছরের হিফজ তত্ত্বাবধান অভিজ্ঞতা',
    credentialsByLang: {
      bn: 'আশারা কিরাত সনদপ্রাপ্ত · ১৮ বছরের হিফজ তত্ত্বাবধান অভিজ্ঞতা',
      en: 'Ijazah in Asharah Qira’at · 18 yrs Hifz supervision',
      ar: 'إجازة في القراءات العشر · ١٨ عاماً في الإشراف على التحفيظ',
    },
    officeHours: 'রবি – বৃহঃ · ০৯:৩০ – ১১:০০',
    officeHoursByLang: {
      bn: 'রবি – বৃহঃ · ০৯:৩০ – ১১:০০',
      en: 'Sun – Thu · 09:30 – 11:00',
      ar: 'الأحد – الخميس · ٠٩:٣٠ – ١١:٠٠',
    },
    focus:
      'নূরানী বিভাগে জেনারেল ক্লাসের পাশাপাশি অতিরিক্ত কুরআন পাঠদান ও হিফজ সক্ষমতা গঠন; এবং হিফজুল কুরআন বিভাগে নিয়মিত সবক, সাত-সবক, আমুক্তা, তেলাওয়াত ও সবিনা তদারকি।',
    focusByLang: {
      bn: 'নূরানী বিভাগে জেনারেল ক্লাসের পাশাপাশি অতিরিক্ত কুরআন পাঠদান ও হিফজ সক্ষমতা গঠন; এবং হিফজুল কুরআন বিভাগে নিয়মিত সবক, সাত-সবক, আমুক্তা, তেলাওয়াত ও সবিনা তদারকি।',
      en: 'Noorani Quyeda & extra-hour Quran readiness alongside General classes, and daily Hifzul Quran Sabaq, Saat-Sabaq, Amukhta, Tilawat, and Sabina supervision.',
      ar: 'تأهيل طلاب النوراني للحفظ عبر حصص القرآن الإضافية مع الدروس العامة، والإشراف اليومي على السبق والسبع سبق والأمختة والتلاوة والسبينا في قسم التحفيظ.',
    },
  },
  {
    id: 'fac-4',
    name: 'ড. তানভীর আহমেদ সিদ্দিকী',
    nameEn: 'Dr. Tanvir Ahmed Siddiqui',
    nameAr: 'الدكتور تنوير أحمد صديقي',
    role: 'পরিচালক, ক্যাডেট (দুই বছর মেয়াদী প্রোগ্রাম) ও গণিত',
    roleByLang: {
      bn: 'পরিচালক, ক্যাডেট (দুই বছর মেয়াদী প্রোগ্রাম) ও গণিত',
      en: 'Director of Cadet (Two Years Program) & Math',
      ar: 'مدير برنامج الكاديت وقسم الرياضيات',
    },
    department: 'Sciences',
    departmentLabel: 'বিজ্ঞান বিভাগ',
    departmentLabelByLang: { bn: 'বিজ্ঞান বিভাগ', en: 'Sciences', ar: 'العلوم' },
    credentials: 'পিএইচডি (কম্পিউটেশনাল গণিত), বুয়েট',
    credentialsByLang: {
      bn: 'পিএইচডি (কম্পিউটেশনাল গণিত), বুয়েট',
      en: 'PhD Computational Mathematics, BUET',
      ar: 'دكتوراه في الرياضيات الحاسوبية، جامعة بنغلاديش للهندسة (BUET)',
    },
    officeHours: 'মঙ্গল ও বৃহঃ · ১৪:০০ – ১৫:৩০',
    officeHoursByLang: {
      bn: 'মঙ্গল ও বৃহঃ · ১৪:০০ – ১৫:৩০',
      en: 'Tue & Thu · 14:00 – 15:30',
      ar: 'الثلاثاء والخميس · ١٤:٠٠ – ١٥:٣٠',
    },
    focus: 'দুই বছর মেয়াদী ক্যাডেট কলেজ ভর্তি গণিত, বিশ্লেষণাত্মক আইকিউ অনুশীলন ও অলিম্পিয়াড সমস্যা সমাধান।',
    focusByLang: {
      bn: 'দুই বছর মেয়াদী ক্যাডেট কলেজ ভর্তি গণিত, বিশ্লেষণাত্মক আইকিউ অনুশীলন ও অলিম্পিয়াড সমস্যা সমাধান।',
      en: 'Two-year Cadet College mathematics, analytical IQ drills, and Olympiad problem solving.',
      ar: 'رياضيات القبول في كليات الكاديت لمدة سنتين وتدريبات الذكاء وحل مسائل الأولمبياد.',
    },
  },
  {
    id: 'fac-5',
    name: 'উস্তাদা মারিয়াম বিনতে ইউসুফ',
    nameEn: 'Ustadha Maryam Bint Yusuf',
    nameAr: 'الأستاذة مريم بنت يوسف',
    role: 'সিনিয়র সমন্বয়ক, আরবি ও ইংরেজি ভাষা',
    roleByLang: {
      bn: 'সিনিয়র সমন্বয়ক, আরবি ও ইংরেজি ভাষা',
      en: 'Senior Coordinator of Arabic & English Rhetoric',
      ar: 'منسقة قسم البلاغة العربية والإنجليزية',
    },
    department: 'Languages',
    departmentLabel: 'ভাষা বিভাগ',
    departmentLabelByLang: { bn: 'ভাষা বিভাগ', en: 'Languages', ar: 'اللغات' },
    credentials: 'এম.এ (আরবি সাহিত্য), আইআইইউএম · সেল্টা (CELTA) সনদপ্রাপ্ত',
    credentialsByLang: {
      bn: 'এম.এ (আরবি সাহিত্য), আইআইইউএম · সেল্টা (CELTA) সনদপ্রাপ্ত',
      en: 'M.A. Arabic Literature, IIUM · CELTA Certified',
      ar: 'ماجستير الأدب العربي، الجامعة الإسلامية العالمية بماليزيا · شهادة CELTA',
    },
    officeHours: 'রবি ও বুধ · ১০:৩০ – ১২:৩০',
    officeHoursByLang: {
      bn: 'রবি ও বুধ · ১০:৩০ – ১২:৩০',
      en: 'Sun & Wed · 10:30 – 12:30',
      ar: 'الأحد والأربعاء · ١٠:٣٠ – ١٢:٣٠',
    },
    focus: 'জেনারেল ও ক্যাডেট শিক্ষার্থীদের আরবি, ইংরেজি এবং বাংলা ভাষায় সাবলীল রচনা ও বাগ্মিতা বিকাশ।',
    focusByLang: {
      bn: 'জেনারেল ও ক্যাডেট শিক্ষার্থীদের আরবি, ইংরেজি এবং বাংলা ভাষায় সাবলীল রচনা ও বাগ্মিতা বিকাশ।',
      en: 'Trilingual Arabic, English, and Bengali composition across General and Cadet cohorts.',
      ar: 'تنمية مهارات التعبير والكتابة باللغات العربية والإنجليزية والبنغالية لطلاب العام والكاديت.',
    },
  },
  {
    id: 'fac-6',
    name: 'ফারহানা ইয়াসমিন করিম',
    nameEn: 'Farhana Yasmin Karim',
    nameAr: 'فرحانة ياسمين كريم',
    role: 'চেয়ারম্যান, মানবিক বিভাগ ও ক্যাডেট ভাইভা মেন্টর',
    roleByLang: {
      bn: 'চেয়ারম্যান, মানবিক বিভাগ ও ক্যাডেট ভাইভা মেন্টর',
      en: 'Chair of Humanities & Cadet Viva Mentorship',
      ar: 'رئيسة قسم الإنسانيات وموجهة المقابلات الشخصية',
    },
    department: 'Humanities',
    departmentLabel: 'মানবিক বিভাগ',
    departmentLabelByLang: { bn: 'মানবিক বিভাগ', en: 'Humanities', ar: 'الإنسانيات' },
    credentials: 'এম.এস.এস (অর্থনীতি), জাহাঙ্গীরনগর বিশ্ববিদ্যালয়',
    credentialsByLang: {
      bn: 'এম.এস.এস (অর্থনীতি), জাহাঙ্গীরনগর বিশ্ববিদ্যালয়',
      en: 'M.S.S. Economics, Jahangirnagar University',
      ar: 'ماجستير العلوم الاجتماعية في الاقتصاد، جامعة جاهانغيرناغار',
    },
    officeHours: 'সোম ও বৃহঃ · ১১:৩০ – ১৩:০০',
    officeHoursByLang: {
      bn: 'সোম ও বৃহঃ · ১১:৩০ – ১৩:০০',
      en: 'Mon & Thu · 11:30 – 13:00',
      ar: 'الاثنين والخميس · ١١:٣٠ – ١٣:٠٠',
    },
    focus: 'বাংলা ভাষা ও সাহিত্য, সাধারণ জ্ঞান শিক্ষা, বাংলাদেশ ও বিশ্বপরিচয় এবং ক্যাডেট ভর্তি পরীক্ষার মৌখিক সাক্ষাৎকার প্রশিক্ষণ।',
    focusByLang: {
      bn: 'বাংলা ভাষা ও সাহিত্য, সাধারণ জ্ঞান শিক্ষা, বাংলাদেশ ও বিশ্বপরিচয় এবং ক্যাডেট ভর্তি পরীক্ষার মৌখিক সাক্ষাৎকার প্রশিক্ষণ।',
      en: 'Bangla language, General Knowledge education, Bangladesh & global studies, and Cadet viva mentorship.',
      ar: 'اللغة البنغالية والمعرفة العامة والدراسات الوطنية والعالمية وتدريب طلاب الكاديت على المقابلات.',
    },
  },
];

export const OFFICIAL_NOTICES: NoticeItem[] = [
  {
    id: 'not-1',
    refNumber: 'FISC/ADM/2026/014',
    title: '২০২৬–২০২৭ শিক্ষাবর্ষে চারটি বিভাগেই ভর্তি কার্যক্রম শুরু',
    titleEn: 'Admissions Open for Academic Session 2026–2027 Across All Four Wings',
    titleAr: 'فتح باب القبول للعام الدراسي ٢٠٢٦–٢٠٢٧ في جميع الأقسام الأربعة',
    category: 'Admissions',
    categoryLabel: 'ভর্তি',
    categoryLabelByLang: { bn: 'ভর্তি', en: 'Admissions', ar: 'القبول' },
    publishedAt: '2026-11-15',
    excerpt:
      'কোনাবাড়ী, গাজীপুর ক্যাম্পাসে জেনারেল (প্লে–দশম), ক্যাডেট (দুই বছর), নূরানী (Noorani) ও হিফজুল কুরআন বিভাগে ভর্তি চলছে।',
    excerptByLang: {
      bn: 'কোনাবাড়ী, গাজীপুর ক্যাম্পাসে জেনারেল (প্লে–দশম), ক্যাডেট (দুই বছর), নূরানী (Noorani) ও হিফজুল কুরআন বিভাগে ভর্তি চলছে।',
      en: 'Enrollment is open at our Konabari, Gazipur campus for General (Play to Ten), Cadet (Two Years Program), Noorani, and Hifzul Quran.',
      ar: 'باب التسجيل مفتوح في حرم كوناباري بغازي بور لأقسام العام والكاديت والنوراني وتحفيظ القرآن.',
    },
    body: [
      'FARMITAM Islamic School & College ২০২৬–২০২৭ শিক্ষাবর্ষের জন্য জেনারেল (Play to Ten), ক্যাডেট (Two Years Program), নূরানী (Quyeda, Ampar and Quran) এবং হিফজুল কুরআন বিভাগে নতুন শিক্ষার্থী ভর্তির আবেদন আহ্বান করছে।',
      'আগ্রহী অভিভাবকগণ আমাদের অনলাইন ভর্তি পোর্টালের মাধ্যমে আবেদন করতে পারবেন অথবা সরাসরি ক্যাম্পাস অফিস—পরশ আলী রোড, পারিজাত, কোনাবাড়ী, গাজীপুর (যোগাযোগ: 01824-204543) ঠিকানায় উপস্থিত হয়ে ফরম সংগ্রহ করতে পারবেন।',
      'ভর্তি পরীক্ষায় কৃতিত্ব ও হিফজুল কুরআনের প্রমাণিত যোগ্যতার ভিত্তিতে মাসিক বেতনে ২৫% থেকে ৫০% পর্যন্ত বিশেষ বৃত্তি প্রদান করা হবে।',
    ],
    bodyByLang: {
      bn: [
        'FARMITAM Islamic School & College ২০২৬–২০২৭ শিক্ষাবর্ষের জন্য জেনারেল (Play to Ten), ক্যাডেট (Two Years Program), নূরানী (Quyeda, Ampar and Quran) এবং হিফজুল কুরআন বিভাগে নতুন শিক্ষার্থী ভর্তির আবেদন আহ্বান করছে।',
        'আগ্রহী অভিভাবকগণ আমাদের অনলাইন ভর্তি পোর্টালের মাধ্যমে আবেদন করতে পারবেন অথবা সরাসরি ক্যাম্পাস অফিস—পরশ আলী রোড, পারিজাত, কোনাবাড়ী, গাজীপুর (যোগাযোগ: 01824-204543) ঠিকানায় উপস্থিত হয়ে ফরম সংগ্রহ করতে পারবেন।',
        'ভর্তি পরীক্ষায় কৃতিত্ব ও হিফজুল কুরআনের প্রমাণিত যোগ্যতার ভিত্তিতে মাসিক বেতনে ২৫% থেকে ৫০% পর্যন্ত বিশেষ বৃত্তি প্রদান করা হবে।',
      ],
      en: [
        'FARMITAM Islamic School & College invites applications from prospective students for the 2026–2027 academic session across General (Play to Ten), Cadet (Two Years Program), Noorani (Quyeda, Ampar and Quran), and Hifzul Quran.',
        'Prospective families may submit applications online through our Admissions Portal or visit the campus office at Parosh Ali Road, Parijat, Konabari, Gazipur (Tel: 01824-204543).',
        'Merit and Hifzul Quran tuition scholarships covering 25% to 50% of monthly tuition are awarded based on entrance assessment performance and documented memorization.',
      ],
      ar: [
        'تدعو مدرسة وكلية فارميتام الإسلامية أولياء الأمور لتقديم طلبات الالتحاق للعام الدراسي ٢٠٢٦–٢٠٢٧ في أقسام العام والكاديت والنوراني وتحفيظ القرآن الكريم.',
        'يمكن تقديم الطلبات إلكترونياً عبر بوابة القبول أو زيارة مكتب الحرم الدراسي في طريق باروش علي، بارجات، كوناباري، غازي بور (هاتف: 01824-204543).',
        'تُمنح منح دراسية تتراوح بين ٢٥٪ و٥٠٪ من الرسوم الشهرية بناءً على أداء اختبار القبول ومستوى حفظ القرآن الكريم.',
      ],
    },
    issuedBy: 'ভর্তি ও রেজিস্ট্রার দপ্তর',
    issuedByByLang: {
      bn: 'ভর্তি ও রেজিস্ট্রার দপ্তর',
      en: 'Office of Admissions & Registrar',
      ar: 'مكتب القبول والتسجيل',
    },
  },
  {
    id: 'not-2',
    refNumber: 'FISC/EXM/2026/009',
    title: 'মেধা যাচাই ও ক্যাডেট ভর্তি পরীক্ষার সময়সূচি প্রকাশ',
    titleEn: 'Placement & Cadet Entrance Diagnostic Assessment Timetable',
    titleAr: 'جدول اختبارات القبول وتحديد المستوى لقسم الكاديت والأقسام الأخرى',
    category: 'Examinations',
    categoryLabel: 'পরীক্ষা',
    categoryLabelByLang: { bn: 'পরীক্ষা', en: 'Examinations', ar: 'الاختبارات' },
    publishedAt: '2026-11-18',
    excerpt:
      'জেনারেল, নূরানী (Noorani) এবং ক্যাডেট (দুই বছর মেয়াদী প্রোগ্রাম) প্রার্থীদের মূল্যায়ন পরীক্ষার তারিখ ও প্রয়োজনীয় নির্দেশনা।',
    excerptByLang: {
      bn: 'জেনারেল, নূরানী (Noorani) এবং ক্যাডেট (দুই বছর মেয়াদী প্রোগ্রাম) প্রার্থীদের মূল্যায়ন পরীক্ষার তারিখ ও প্রয়োজনীয় নির্দেশনা।',
      en: 'Assessment dates, reporting times, and stationery guidelines for General (Play to Ten) and Cadet (Two Years Program) candidates.',
      ar: 'مواعيد اختبارات تحديد المستوى وإرشادات الحضور لمتقدمي القسم العام والنوراني وقسم الكاديت.',
    },
    body: [
      'জেনারেল (প্লে থেকে দশম) এবং নূরানী (Noorani) বিভাগে আবেদনকারী শিক্ষার্থীদের প্রাথমিক মেধা মূল্যায়ন পরীক্ষা আগামী শনিবার, ৫ ডিসেম্বর ২০২৬ সকাল ০৯:০০ টায় কোনাবাড়ী ক্যাম্পাসে অনুষ্ঠিত হবে।',
      'ক্যাডেট (Two Years Program) বিভাগের বাংলা, ইংরেজি, গণিত, সাধারণ জ্ঞান ও আইকিউ যাচাই পরীক্ষা আগামী রবিবার, ৬ ডিসেম্বর ২০২৬ সকাল ১০:০০ টায় শুরু হবে।',
      'পরীক্ষার দিন প্রার্থীদের অবশ্যই অনলাইন আবেদনের ট্র্যাকিং রসিদ এবং দুই কপি পাসপোর্ট সাইজের ছবি সঙ্গে আনতে হবে।',
    ],
    bodyByLang: {
      bn: [
        'জেনারেল (প্লে থেকে দশম) এবং নূরানী (Noorani) বিভাগে আবেদনকারী শিক্ষার্থীদের প্রাথমিক মেধা মূল্যায়ন পরীক্ষা আগামী শনিবার, ৫ ডিসেম্বর ২০২৬ সকাল ০৯:০০ টায় কোনাবাড়ী ক্যাম্পাসে অনুষ্ঠিত হবে।',
        'ক্যাডেট (Two Years Program) বিভাগের বাংলা, ইংরেজি, গণিত, সাধারণ জ্ঞান ও আইকিউ যাচাই পরীক্ষা আগামী রবিবার, ৬ ডিসেম্বর ২০২৬ সকাল ১০:০০ টায় শুরু হবে।',
        'পরীক্ষার দিন প্রার্থীদের অবশ্যই অনলাইন আবেদনের ট্র্যাকিং রসিদ এবং দুই কপি পাসপোর্ট সাইজের ছবি সঙ্গে আনতে হবে।',
      ],
      en: [
        'Registered candidates for General (Play to Ten) and Noorani placements will sit for their foundational evaluation on Saturday, December 5, 2026, beginning promptly at 09:00 AM at the Konabari campus.',
        'Cadet (Two Years Program) diagnostic tests covering Bangla, English, Mathematics, General Knowledge, and IQ reasoning will take place on Sunday, December 6, 2026, at 10:00 AM.',
        'Candidates must bring their printed Application Tracking Receipt and two passport-size photographs.',
      ],
      ar: [
        'يُعقد الاختبار التقييمي لمتقدمي القسم العام والنوراني يوم السبت ٥ ديسمبر ٢٠٢٦ الساعة ٩:٠٠ صباحاً في حرم كوناباري.',
        'وتُعقد اختبارات القبول لقسم الكاديت في البنغالية والإنجليزية والرياضيات والمعرفة العامة والمنطق يوم الأحد ٦ ديسمبر ٢٠٢٦ الساعة ١٠:٠٠ صباحاً.',
        'يجب على جميع المتقدمين إحضار إيصال التتبع المطبوع وصورتين شخصيتين.',
      ],
    },
    issuedBy: 'পরীক্ষা নিয়ন্ত্রকের দপ্তর',
    issuedByByLang: {
      bn: 'পরীক্ষা নিয়ন্ত্রকের দপ্তর',
      en: 'Controller of Examinations',
      ar: 'مراقب الامتحانات',
    },
  },
  {
    id: 'not-3',
    refNumber: 'FISC/EVT/2026/006',
    title: 'গাজীপুর ক্যাম্পাস ওপেন হাউস, পাঠাগার উদ্বোধন ও অভিভাবক মতবিনিময়',
    titleEn: 'Gazipur Campus Open House, Library Dedication & Parent Orientation',
    titleAr: 'اليوم المفتوح لحرم غازي بور وافتتاح المكتبة ولقاء أولياء الأمور',
    category: 'Events',
    categoryLabel: 'অনুষ্ঠান',
    categoryLabelByLang: { bn: 'অনুষ্ঠান', en: 'Events', ar: 'الفعاليات' },
    publishedAt: '2026-11-20',
    excerpt:
      'পরশ আলী রোড, পারিজাত, কোনাবাড়ী ক্যাম্পাসে বিজ্ঞান গবেষণাগার, নূরানী ও হিফজ শ্রেণিকক্ষ এবং ক্যাডেট উইং পরিদর্শনের আমন্ত্রণ।',
    excerptByLang: {
      bn: 'পরশ আলী রোড, পারিজাত, কোনাবাড়ী ক্যাম্পাসে বিজ্ঞান গবেষণাগার, নূরানী ও হিফজ শ্রেণিকক্ষ এবং ক্যাডেট উইং পরিদর্শনের আমন্ত্রণ।',
      en: 'Guided tours of the Science Laboratories, Noorani & Hifz Classrooms, and Cadet Wing at Parosh Ali Road, Parijat, Konabari.',
      ar: 'جولات تعريفية في المختبرات العلمية وفصول النوراني والتحفيظ وجناح الكاديت في حرم كوناباري بغازي بور.',
    },
    body: [
      'আগামী শুক্রবার, ২৭ নভেম্বর ২০২৬ সকাল ০৯:৩০ থেকে দুপুর ১২:৩০ পর্যন্ত আমাদের গাজীপুর ক্যাম্পাসে (পরশ আলী রোড, পারিজাত, কোনাবাড়ী) অভিভাবক মতবিনিময় ও ক্যাম্পাস ওপেন হাউস আয়োজন করা হয়েছে।',
      'হিফজুল কুরআন বিভাগের শিক্ষার্থীদের তিলাওয়াতের মাধ্যমে অনুষ্ঠান শুরু হবে এবং অধ্যক্ষ ড. তারিকুল ইসলাম "Knowledge With Faith" শিক্ষা দর্শনের ওপর দিকনির্দেশনামূলক বক্তব্য রাখবেন।',
      'উপস্থিত অভিভাবকগণ জেনারেল, ক্যাডেট, নূরানী ও হিফজ শ্রেণিকক্ষ সরাসরি ঘুরে দেখার সুযোগ পাবেন।',
    ],
    bodyByLang: {
      bn: [
        'আগামী শুক্রবার, ২৭ নভেম্বর ২০২৬ সকাল ০৯:৩০ থেকে দুপুর ১২:৩০ পর্যন্ত আমাদের গাজীপুর ক্যাম্পাসে (পরশ আলী রোড, পারিজাত, কোনাবাড়ী) অভিভাবক মতবিনিময় ও ক্যাম্পাস ওপেন হাউস আয়োজন করা হয়েছে।',
        'হিফজুল কুরআন বিভাগের শিক্ষার্থীদের তিলাওয়াতের মাধ্যমে অনুষ্ঠান শুরু হবে এবং অধ্যক্ষ ড. তারিকুল ইসলাম "Knowledge With Faith" শিক্ষা দর্শনের ওপর দিকনির্দেশনামূলক বক্তব্য রাখবেন।',
        'উপস্থিত অভিভাবকগণ জেনারেল, ক্যাডেট, নূরানী ও হিফজ শ্রেণিকক্ষ সরাসরি ঘুরে দেখার সুযোগ পাবেন।',
      ],
      en: [
        'Parents, guardians, and prospective scholars are cordially invited to our Campus Open House on Friday, November 27, 2026, from 09:30 AM to 12:30 PM at Parosh Ali Road, Parijat, Konabari, Gazipur.',
        'The morning opens with Quran recitation by Hifzul Quran students, followed by Principal Dr. Tariqul Islam’s address on our "Knowledge With Faith" educational mission.',
        'Faculty coordinators will host live walkthroughs of the General, Cadet, Noorani, and Hifz classrooms.',
      ],
      ar: [
        'يسعدنا دعوة أولياء الأمور والطلاب لحضور اليوم المفتوح يوم الجمعة ٢٧ نوفمبر ٢٠٢٦ من الساعة ٩:٣٠ صباحاً حتى ١٢:٣٠ ظهراً في حرم كوناباري بغازي بور.',
        'يفتتح اللقاء بتلاوة عطرة من طلاب قسم تحفيظ القرآن، تليها كلمة المدير الدكتور طارق الإسلام حول رسالة المؤسسة التربوية.',
        'وسيصطحب منسقو الأقسام أولياء الأمور في جولة ميدانية داخل فصول الأقسام الأربعة.',
      ],
    },
    issuedBy: 'অধ্যক্ষের সচিবালয়',
    issuedByByLang: {
      bn: 'অধ্যক্ষের সচিবালয়',
      en: 'Principal’s Secretariat',
      ar: 'مكتب مدير المؤسسة',
    },
  },
  {
    id: 'not-4',
    refNumber: 'FISC/ADM/2026/018',
    title: 'আবাসিক হোস্টেল নীতিমালা ও অভিভাবক সাক্ষাৎ নির্দেশিকা',
    titleEn: 'Residential Hostel Guidelines & Guardian Verification Protocol',
    titleAr: 'لوائح السكن الداخلي ونظام متابعة وزيارة أولياء الأمور',
    category: 'Admissions',
    categoryLabel: 'ভর্তি',
    categoryLabelByLang: { bn: 'ভর্তি', en: 'Admissions', ar: 'القبول' },
    publishedAt: '2026-11-21',
    excerpt:
      'ক্যাডেট ও হিফজুল কুরআন আবাসিক শিক্ষার্থীদের সান্ধ্যকালীন অধ্যয়ন, স্বাস্থ্যসম্মত খাবার ও অভিভাবক সাক্ষাতের সময়সূচি।',
    excerptByLang: {
      bn: 'ক্যাডেট ও হিফজুল কুরআন আবাসিক শিক্ষার্থীদের সান্ধ্যকালীন অধ্যয়ন, স্বাস্থ্যসম্মত খাবার ও অভিভাবক সাক্ষাতের সময়সূচি।',
      en: 'Supervised evening study hours, dietary meal plans, and visitation schedule for Cadet and Hifzul Quran residential students.',
      ar: 'ساعات المذاكرة المسائية تحت الإشراف والوجبات الصحية ومواعيد زيارة أولياء الأمور لطلاب السكن الداخلي.',
    },
    body: [
      'ফারমিটম আবাসিক শাখায় প্রতিটি ফ্লোরে আবাসিক শিক্ষকের সার্বক্ষণিক তত্ত্বাবধানে জেনারেল, ক্যাডেট ও হিফজুল কুরআন শিক্ষার্থীদের জন্য নিরাপদ থাকার ব্যবস্থা রয়েছে।',
      'প্রতিদিন মাগরিবের জামাতের পর সন্ধ্যা ১৮:৩০ থেকে রাত ২১:০০ পর্যন্ত বাধ্যতামূলক তত্ত্বাবধানে অধ্যয়ন এবং ফজরের পর নিয়মিত কুরআন রিভিশন পরিচালিত হয়।',
      'আবাসিক ভর্তি সংক্রান্ত যেকোনো তথ্যের জন্য অফিস চলাকালীন 01824-204543 নম্বরে যোগাযোগ করুন।',
    ],
    bodyByLang: {
      bn: [
        'ফারমিটম আবাসিক শাখায় প্রতিটি ফ্লোরে আবাসিক শিক্ষকের সার্বক্ষণিক তত্ত্বাবধানে জেনারেল, ক্যাডেট ও হিফজুল কুরআন শিক্ষার্থীদের জন্য নিরাপদ থাকার ব্যবস্থা রয়েছে।',
        'প্রতিদিন মাগরিবের জামাতের পর সন্ধ্যা ১৮:৩০ থেকে রাত ২১:০০ পর্যন্ত বাধ্যতামূলক তত্ত্বাবধানে অধ্যয়ন এবং ফজরের পর নিয়মিত কুরআন রিভিশন পরিচালিত হয়।',
        'আবাসিক ভর্তি সংক্রান্ত যেকোনো তথ্যের জন্য অফিস চলাকালীন 01824-204543 নম্বরে যোগাযোগ করুন।',
      ],
      en: [
        'The FARMITAM Residential Wing provides supervised dormitories for General, Cadet, and Hifzul Quran students with resident teachers on every floor.',
        'Evening schedules include Maghrib congregational prayer, supervised study blocks from 18:30 to 21:00, and structured Fajr Quran revision circles.',
        'For residential inquiries, guardians may call 01824-204543 during campus hours.',
      ],
      ar: [
        'يوفر السكن الداخلي لمدرسة وكلية فارميتام غرفاً آمنة لطلاب الأقسام العامة والكاديت وتحفيظ القرآن تحت إشراف معلمين مقيمين في كل طابق.',
        'يشمل البرنامج المسائي صلاة المغرب جماعة وساعات مذاكرة موجهة من ٦:٣٠ إلى ٩:٠٠ مساءً وحلقات مراجعة القرآن بعد الفجر.',
        'للاستفسار عن السكن الداخلي يرجى الاتصال على 01824-204543 خلال ساعات الدوام.',
      ],
    },
    issuedBy: 'ছাত্রকল্যাণ ও আবাসিক তত্ত্বাবধায়ক দপ্তর',
    issuedByByLang: {
      bn: 'ছাত্রকল্যাণ ও আবাসিক তত্ত্বাবধায়ক দপ্তর',
      en: 'Dean of Student Affairs & Residential Life',
      ar: 'عمادة شؤون الطلاب والسكن الداخلي',
    },
  },
];

export const DAILY_SCHEDULE: DailyScheduleRow[] = [
  {
    period: '01',
    timeRange: '07:45 – 08:15',
    activity: 'প্রভাতী সমাবেশ ও দৈনন্দিন মাসনূন দোয়া',
    activityByLang: {
      bn: 'প্রভাতী সমাবেশ ও দৈনন্দিন মাসনূন দোয়া',
      en: 'Morning Assembly & Daily Adhkar',
      ar: 'الطابور الصباحي والأذكار اليومية',
    },
    notes: 'কেন্দ্রীয় প্রাঙ্গণ',
    notesByLang: { bn: 'কেন্দ্রীয় প্রাঙ্গণ', en: 'Main Courtyard', ar: 'الفناء الرئيسي' },
  },
  {
    period: '02',
    timeRange: '08:15 – 10:15',
    activity: 'নূরানী, হিফজ ও মৌলিক ইসলামী শিক্ষা',
    activityByLang: {
      bn: 'নূরানী, হিফজ ও মৌলিক ইসলামী শিক্ষা',
      en: 'Noorani, Hifz & Core Islamic Sciences',
      ar: 'النوراني والتحفيظ والعلوم الشرعية',
    },
    notes: 'কুরআন ও হাদিস উইং',
    notesByLang: { bn: 'কুরআন ও হাদিস উইং', en: 'Quran & Hadith Wings', ar: 'جناح القرآن والحديث' },
  },
  {
    period: '03',
    timeRange: '10:15 – 10:40',
    activity: 'মধ্য-সকাল বিরতি ও টিফিন',
    activityByLang: {
      bn: 'মধ্য-সকাল বিরতি ও টিফিন',
      en: 'Mid-Morning Recess & Refreshment',
      ar: 'الاستراحة الصباحية',
    },
    notes: 'খোলা বারান্দা চত্বর',
    notesByLang: { bn: 'খোলা বারান্দা চত্বর', en: 'Courtyard Cloister', ar: 'الرواق المفتوح' },
  },
  {
    period: '04',
    timeRange: '10:40 – 13:00',
    activity: 'জেনারেল পাঠদান, গণিত ও ক্যাডেট অনুশীলন',
    activityByLang: {
      bn: 'জেনারেল পাঠদান, গণিত ও ক্যাডেট অনুশীলন',
      en: 'General Academics, Math & Cadet Reasoning',
      ar: 'الدروس العامة والرياضيات وتدريبات الكاديت',
    },
    notes: 'একাডেমিক শ্রেণিকক্ষ',
    notesByLang: { bn: 'একাডেমিক শ্রেণিকক্ষ', en: 'Academic Classrooms', ar: 'الفصول الدراسية' },
  },
  {
    period: '05',
    timeRange: '13:00 – 13:45',
    activity: 'যোহরের জামাত ও মধ্যাহ্নভোজ বিরতি',
    activityByLang: {
      bn: 'যোহরের জামাত ও মধ্যাহ্নভোজ বিরতি',
      en: 'Zuhr Congregational Prayer & Lunch',
      ar: 'صلاة الظهر جماعة واستراحة الغداء',
    },
    notes: 'ক্যাম্পাস মসজিদ ও ডাইনিং',
    notesByLang: { bn: 'ক্যাম্পাস মসজিদ ও ডাইনিং', en: 'Campus Masjid & Dining', ar: 'مسجد الحرم وقاعة الطعام' },
  },
  {
    period: '06',
    timeRange: '13:45 – 15:30',
    activity: 'বিজ্ঞান ল্যাব, ক্যাডেট ড্রিল ও অনুশীলন',
    activityByLang: {
      bn: 'বিজ্ঞান ল্যাব, ক্যাডেট ড্রিল ও অনুশীলন',
      en: 'Science Labs, Cadet Drill & Guided Revision',
      ar: 'مختبرات العلوم وتدريب الكاديت والمراجعة',
    },
    notes: 'গবেষণাগার ও পাঠাগার',
    notesByLang: { bn: 'গবেষণাগার ও পাঠাগার', en: 'Labs & Reading Hall', ar: 'المختبرات وقاعة القراءة' },
  },
];

export const ACADEMIC_CALENDAR: CalendarMilestone[] = [
  {
    date: '2026-11-27',
    title: 'গাজীপুর ক্যাম্পাস ওপেন হাউস ও মতবিনিময়',
    titleByLang: {
      bn: 'গাজীপুর ক্যাম্পাস ওপেন হাউস ও মতবিনিময়',
      en: 'Gazipur Campus Open House & Orientation',
      ar: 'اليوم المفتوح والتعريف بحرم غازي بور',
    },
    divisionScope: 'সকল চারটি বিভাগ',
    divisionScopeByLang: { bn: 'সকল চারটি বিভাগ', en: 'All Four Sections', ar: 'جميع الأقسام الأربعة' },
  },
  {
    date: '2026-12-05',
    title: 'জেনারেল (প্লে–দশম) ও নূরানী মূল্যায়ন',
    titleByLang: {
      bn: 'জেনারেল (প্লে–দশম) ও নূরানী মূল্যায়ন',
      en: 'General (Play to Ten) & Noorani Placement',
      ar: 'تقييم القسم العام والنوراني',
    },
    divisionScope: 'জেনারেল ও নূরানী',
    divisionScopeByLang: { bn: 'জেনারেল ও নূরানী', en: 'General & Noorani', ar: 'العام والنوراني' },
  },
  {
    date: '2026-12-06',
    title: 'ক্যাডেট (দুই বছর মেয়াদী প্রোগ্রাম) ভর্তি পরীক্ষা',
    titleByLang: {
      bn: 'ক্যাডেট (দুই বছর মেয়াদী প্রোগ্রাম) ভর্তি পরীক্ষা',
      en: 'Cadet (Two Years Program) Entrance Test',
      ar: 'اختبار القبول لبرنامج الكاديت',
    },
    divisionScope: 'ক্যাডেট ও হিফজুল কুরআন',
    divisionScopeByLang: { bn: 'ক্যাডেট ও হিফজুল কুরআন', en: 'Cadet & Hifzul Quran', ar: 'الكاديت وتحفيظ القرآن' },
  },
  {
    date: '2026-12-18',
    title: 'ভর্তি নিশ্চয়ন ও আসন বরাদ্দ সম্পন্ন',
    titleByLang: {
      bn: 'ভর্তি নিশ্চয়ন ও আসন বরাদ্দ সম্পন্ন',
      en: 'Admission Confirmation & Seat Settlement',
      ar: 'تأكيد القبول وتثبيت المقاعد',
    },
    divisionScope: '২০২৬–২০২৭ শিক্ষাবর্ষ',
    divisionScopeByLang: { bn: '২০২৬–২০২৭ শিক্ষাবর্ষ', en: '2026–2027 Cohort', ar: 'دفعة ٢٠٢٦–٢٠٢٧' },
  },
  {
    date: '2027-01-04',
    title: 'নতুন শিক্ষাবর্ষের আনুষ্ঠানিক ক্লাস শুরু',
    titleByLang: {
      bn: 'নতুন শিক্ষাবর্ষের আনুষ্ঠানিক ক্লাস শুরু',
      en: 'Inaugural Term Classes Commence',
      ar: 'انطلاق الفصل الدراسي الأول',
    },
    divisionScope: 'সকল বিভাগ',
    divisionScopeByLang: { bn: 'সকল বিভাগ', en: 'All Sections', ar: 'جميع الأقسام' },
  },
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'test-1',
    authorType: 'Parent',
    division: 'noorani',
    featured: true,
    nameByLang: {
      bn: 'মো. রফিকুল ইসলাম পাটোয়ারী',
      en: 'Md. Rafiqul Islam Patwary',
      ar: 'السيد رفيق الإسلام باتواري',
    },
    roleByLang: {
      bn: 'অভিভাবক (তৃতীয় শ্রেণি ও নূরানী)',
      en: 'Parent · Class III & Noorani Wing',
      ar: 'ولي أمر · الصف الثالث وقسم النوراني',
    },
    wingLabelByLang: {
      bn: 'নূরানী ও জেনারেল',
      en: 'Noorani & General',
      ar: 'النوراني والعام',
    },
    outcomeByLang: {
      bn: '৬ মাসে কুরআন নাযেরা ও শ্রেণিতে প্রথম স্থান',
      en: 'Completed Nazirah in 6 months · Ranked 1st in class',
      ar: 'أتم التلاوة نظراً في ٦ أشهر · الأول في صفه',
    },
    quoteByLang: {
      bn: 'আমার ছেলে নূরানী বিভাগে জেনারেল ক্লাসের পাশাপাশি প্রতিদিন অতিরিক্ত সময় কুরআন ক্লাস পাওয়ায় মাত্র ছয় মাসেই শুদ্ধ তাজবিদসহ কুরআন নাযেরা শুরু করেছে এবং গণিত ও ইংরেজিতেও শ্রেণিতে প্রথম হয়েছে। ফারমিটম ইসলামিক স্কুল এন্ড কলেজ আমাদের দীর্ঘদিনের দ্বীনি ও আধুনিক শিক্ষার স্বপ্ন পূরণ করেছে।',
      en: 'Because the Noorani wing pairs regular General classes with dedicated extra Quran hours, my son progressed to fluent Nazirah recitation with Tajweed within six months while finishing first in Mathematics and English.',
      ar: 'بفضل الدمج بين الدروس العامة وساعات القرآن الإضافية في قسم النوراني، انتقل ابني إلى تلاوة القرآن بالتجويد الصحيح خلال ستة أشهر فقط مع تفوقه في الرياضيات والإنجليزية.',
    },
  },
  {
    id: 'test-2',
    authorType: 'Parent',
    division: 'cadet',
    nameByLang: {
      bn: 'মিসেস সালমা খাতুন',
      en: 'Mrs. Salma Khatun',
      ar: 'السيدة سلمى خاتون',
    },
    roleByLang: {
      bn: 'অভিভাবক · ক্যাডেট (দুই বছর মেয়াদী প্রোগ্রাম)',
      en: 'Parent · Cadet Two Years Program',
      ar: 'ولية أمر · برنامج الكاديت لمدة سنتين',
    },
    wingLabelByLang: {
      bn: 'ক্যাডেট প্রোগ্রাম',
      en: 'Cadet Program',
      ar: 'برنامج الكاديت',
    },
    outcomeByLang: {
      bn: 'সাপ্তাহিক টেস্টে ৯২% গড় ও ভাইভা দক্ষতা',
      en: '92% average in weekly tests & viva readiness',
      ar: 'معدل ٩٢٪ في الاختبارات الأسبوعية وإتقان المقابلات',
    },
    quoteByLang: {
      bn: 'ক্যাডেট বিভাগে ৩০:১ অনুপাতে শিক্ষকদের নিবিড় তদারকি এবং বাংলা, ইংরেজি, গণিত ও সাধারণ জ্ঞান শিক্ষার পাশাপাশি প্রতি সপ্তাহে ২ ঘণ্টার নিয়মিত টেস্ট আমার সন্তানের আত্মবিশ্বাস ও সময়ানুবর্তিতা আমূল বদলে দিয়েছে।',
      en: 'Focused mentoring in Bangla, English, Mathematics, and General Knowledge alongside consistent 2-hour weekly Cadet tests transformed my son’s analytical confidence and discipline.',
      ar: 'إن المتابعة الدقيقة في اللغة البنغالية والإنجليزية والرياضيات والمعرفة العامة مع الاختبار الأسبوعي المنتظم غيّرت مستوى ثقة ابني وانضباطه بشكل ملحوظ.',
    },
  },
  {
    id: 'test-3',
    authorType: 'Student',
    division: 'hifzul-quran',
    nameByLang: {
      bn: 'হাফেজ আব্দুল্লাহ আল-নোমান',
      en: 'Hafez Abdullah Al-Noman',
      ar: 'الحافظ عبد الله النعمان',
    },
    roleByLang: {
      bn: 'শিক্ষার্থী · হিফজুল কুরআন (আবাসিক)',
      en: 'Scholar · Hifzul Quran Residential',
      ar: 'طالب · قسم تحفيظ القرآن (السكن الداخلي)',
    },
    wingLabelByLang: {
      bn: 'হিফজুল কুরআন',
      en: 'Hifzul Quran',
      ar: 'تحفيظ القرآن',
    },
    outcomeByLang: {
      bn: '১৪ মাসে ২২ পারা হিফজ ও আরবি-ইংরেজি সমতা',
      en: '22 Juz memorized in 14 months alongside academics',
      ar: 'حفظ ٢٢ جزءاً في ١٤ شهراً مع التفوق اللغوي',
    },
    quoteByLang: {
      bn: 'প্রতিদিন ফজরের পর ওস্তাদজির কাছে নিয়মিত সবক, সাত-সবক ও আমুক্তা আদায় এবং সাপ্তাহিক ৩ ঘণ্টার সবিনা তদারকির ফলে আমার মুখস্থশক্তি অনেক মজবুত হয়েছে। পাশাপাশি বাংলা, ইংরেজি, গণিত ও আরবি ক্লাস থাকায় জেনারেল পড়াশোনাতেও আমি পিছিয়ে নেই।',
      en: 'Daily Sabaq, Saat-Sabaq, and Amukhta checks with our Huffaz mentors—plus weekly 3-hour Sabina monitoring and core classes in Bangla, English, Math, and Arabic—kept my Hifz sharp without falling behind academically.',
      ar: 'المتابعة اليومية للسبق والسبع سبق والأمختة ومراقبة السبينا الأسبوعية إلى جانب دروس البنغالية والإنجليزية والرياضيات والعربية مكّنتني من الحفظ المتقن دون تأخر دراسي.',
    },
  },
  {
    id: 'test-4',
    authorType: 'Parent',
    division: 'general',
    nameByLang: {
      bn: 'প্রকৌশলী তৌহিদুল ইসলাম',
      en: 'Engr. Towhidul Islam',
      ar: 'المهندس توحيد الإسلام',
    },
    roleByLang: {
      bn: 'অভিভাবক · অষ্টম শ্রেণি (ডে-শিফট)',
      en: 'Parent · Class VIII General (Day Shift)',
      ar: 'ولي أمر · الصف الثامن (الفترة النهارية)',
    },
    wingLabelByLang: {
      bn: 'জেনারেল (প্লে–দশম)',
      en: 'General (Play to Ten)',
      ar: 'القسم العام',
    },
    outcomeByLang: {
      bn: 'বিজ্ঞান প্রজেক্টে প্রথম ও পাঁচ ওয়াক্ত সালাতের অভ্যাস',
      en: '1st in Campus Science Fair & consistent daily Salah',
      ar: 'المركز الأول في معرض العلوم والالتزام بالصلاة',
    },
    quoteByLang: {
      bn: 'কোনাবাড়ীতে এমন একটি ক্যাম্পাস যেখানে আধুনিক বিজ্ঞান গবেষণাগার, ২৮ ঘণ্টার ডে-শিফট পাঠদান ও সাপ্তাহিক ২ ঘণ্টার মূল্যায়নের পাশাপাশি সন্তান নামাজ ও ইসলামী আদব শিখে বড় হচ্ছে—একজন অভিভাবক হিসেবে এর চেয়ে বড় স্বস্তি আর নেই।',
      en: 'Finding a Konabari campus where our daughter learns hands-on science across a structured 28-hour day shift while practicing Salah and Islamic Adab is the greatest reassurance for our family.',
      ar: 'إن وجود حرم تعليمي في كوناباري يجمع بين مختبرات العلوم الحديثة والالتزام بالصلاة والآداب الإسلامية يمنحنا أكبر طمأنينة كأسرة.',
    },
  },
  {
    id: 'test-5',
    authorType: 'Student',
    division: 'general',
    nameByLang: {
      bn: 'নুসাইবা তাবাসসুম',
      en: 'Nusaybah Tabassum',
      ar: 'نسيبة تبسم',
    },
    roleByLang: {
      bn: 'শিক্ষার্থী · দশম শ্রেণি (বিজ্ঞান শাখা)',
      en: 'Student · Class X Science Cohort',
      ar: 'طالبة · الصف العاشر (القسم العلمي)',
    },
    wingLabelByLang: {
      bn: 'জেনারেল (প্লে–দশম)',
      en: 'General (Play to Ten)',
      ar: 'القسم العام',
    },
    outcomeByLang: {
      bn: 'পদার্থ ও উচ্চতর গণিতে ৯৫% ও কুরআন তিলাওয়াত সনদ',
      en: '95% in Physics & Higher Math · Tajweed Honors',
      ar: '٩٥٪ في الفيزياء والرياضيات · شهادة إتقان التلاوة',
    },
    quoteByLang: {
      bn: 'আমাদের বিজ্ঞান গবেষণাগারে হাতে-কলমে ব্যবহারিক ক্লাস, কেন্দ্রীয় পাঠাগারে দলগত অধ্যয়ন এবং শিক্ষকদের আন্তরিক দিকনির্দেশনা আমাকে এসএসসি পরীক্ষার জন্য পূর্ণ আত্মবিশ্বাসী করে তুলেছে।',
      en: 'Hands-on laboratory sessions, quiet study hours in our central library, and close guidance from our subject teachers have prepared me thoroughly for my upcoming SSC board examinations.',
      ar: 'التجارب العلمية في المختبرات وساعات المطالعة في المكتبة المركزية وتوجيه الأساتذة منحتني ثقة كاملة للامتحانات النهائية.',
    },
  },
  {
    id: 'test-6',
    authorType: 'Student',
    division: 'cadet',
    nameByLang: {
      bn: 'আহনাফ শাহরিয়ার',
      en: 'Ahnaf Shahriar',
      ar: 'أحنف شهريار',
    },
    roleByLang: {
      bn: 'শিক্ষার্থী · ক্যাডেট (দ্বিতীয় বর্ষ)',
      en: 'Student · Cadet Year II Cohort',
      ar: 'طالب · برنامج الكاديت (السنة الثانية)',
    },
    wingLabelByLang: {
      bn: 'ক্যাডেট প্রোগ্রাম',
      en: 'Cadet Program',
      ar: 'برنامج الكاديت',
    },
    outcomeByLang: {
      bn: 'আইকিউ ও সাধারণ জ্ঞান অলিম্পিয়াডে জেলা পর্যায়ে মনোনীত',
      en: 'District Qualifier · IQ & General Knowledge Olympiad',
      ar: 'متأهل على مستوى المحافظة في أولمبياد الذكاء والمعرفة',
    },
    quoteByLang: {
      bn: 'ক্যাডেট ব্যাচে প্রতিদিনের ৩০ ঘণ্টার অনুশীলনে গণিত, ইংরেজি, বাংলা ব্যাকরণ ও সাধারণ জ্ঞান শিক্ষার পাশাপাশি ভাইভা-ভোস ও উপস্থিত বক্তৃতার চর্চা আমাকে যেকোনো প্রতিযোগিতায় লড়ার সাহস জুগিয়েছে।',
      en: 'Our structured 30-hour Cadet weekly training in Mathematics, English, Bangla grammar, General Knowledge, and live viva drills gave me the composure to excel in district-level competitions.',
      ar: 'منحني التدريب الأسبوعي المنظم في الرياضيات والإنجليزية والبنغالية والمعرفة العامة وتدريبات المقابلات الشفهية الثقة للمنافسة والتميز.',
    },
  },
  {
    id: 'test-7',
    authorType: 'Parent',
    division: 'hifzul-quran',
    nameByLang: {
      bn: 'মাওলানা মোস্তাফিজুর রহমান',
      en: 'Mawlana Mostafizur Rahman',
      ar: 'مولانا مستفيض الرحمن',
    },
    roleByLang: {
      bn: 'অভিভাবক · আবাসিক ও হিফজুল কুরআন বিভাগ',
      en: 'Parent · Residential & Hifzul Quran Wing',
      ar: 'ولي أمر · السكن الداخلي وتحفيظ القرآن',
    },
    wingLabelByLang: {
      bn: 'আবাসিক ও হিফজ',
      en: 'Residential & Hifz',
      ar: 'السكن الداخلي والتحفيظ',
    },
    outcomeByLang: {
      bn: 'সাপ্তাহিক ৮০ ঘণ্টা তদারকি ও সুশৃঙ্খল আবাসিক জীবন',
      en: '80-hr structured mentorship & disciplined boarding care',
      ar: 'متابعة أسبوعية ٨٠ ساعة ورعاية داخلية منضبطة',
    },
    quoteByLang: {
      bn: 'আবাসিক শাখায় সপ্তাহে ৮০ ঘণ্টার নিবিড় তদারকি, সময়মতো জামাতে নামাজ, স্বাস্থ্যসম্মত খাবার এবং প্রতি সপ্তাহে ৩ ঘণ্টার মূল্যায়ন পরীক্ষার কারণে আমরা সন্তানকে নিশ্চিন্তে হোস্টেলে রেখে স্বস্তি পাচ্ছি।',
      en: 'Knowing our son receives 80 hours of structured residential supervision each week—including congregational prayers, wholesome meals, and 3-hour weekly evaluations—gives our family complete peace of mind.',
      ar: 'إن متابعة ابني في السكن الداخلي لمدة ٨٠ ساعة أسبوعياً مع الصلوات في جماعة والوجبات الصحية والتقييم الأسبوعي تمنحنا طمأنينة كاملة.',
    },
  },
];

export const INSTITUTION_FEATURES: InstitutionFeature[] = [
  {
    id: 'feat-dual-curriculum',
    indexByLang: { bn: 'বৈশিষ্ট্য ০১', en: 'Feature 01', ar: 'الميزة ٠١' },
    kickerByLang: {
      bn: 'সমন্বিত শিক্ষাক্রম · Dual Education',
      en: 'Integrated Curriculum · সমন্বিত শিক্ষাক্রম',
      ar: 'منهج متكامل · الجمع بين التعليمين',
    },
    titleBn: 'একই সাথে জেনারেল ও ইসলামিক শিক্ষার ব্যবস্থা',
    titleEn: 'Integrated General & Islamic Education Together',
    titleAr: 'الجمع بين التعليم العام والإسلامي في آن واحد',
    titleByLang: {
      bn: 'একই সাথে জেনারেল ও ইসলামিক শিক্ষার ব্যবস্থা',
      en: 'Integrated General & Islamic Education Together',
      ar: 'الجمع بين التعليم العام والإسلامي في آن واحد',
    },
    descriptionByLang: {
      bn: 'প্লে থেকে দশম শ্রেণির জাতীয় পাঠ্যক্রম (বিজ্ঞান, গণিত ও আইসিটি) এবং নূরানী, নাযেরা ও হিফজুল কুরআনসহ বিশুদ্ধ ইসলামিক শিক্ষার পরিপূর্ণ সমন্বয়—যাতে একজন শিক্ষার্থী একই ক্যাম্পাসে দুনিয়া ও আখিরাত উভয় শিক্ষায় দক্ষ হয়ে ওঠে।',
      en: 'Full National Curriculum instruction from Play to Class Ten alongside structured Noorani, Nazirah, Tajweed, and Hifzul Quran studies under one roof—eliminating the gap between modern academics and authentic Islamic scholarship.',
      ar: 'تكامل تام بين المنهج الوطني العام من الروضة إلى الصف العاشر والدراسات الإسلامية الأصيلة من النوراني والتجويد وتحفيظ القرآن الكريم تحت سقف واحد، لينشأ الطالب متقناً للعلوم الدينية والحديثة معاً.',
    },
    checkpointsByLang: {
      bn: ['জেনারেল (প্লে–দশম)', 'ক্যাডেট (২ বছর মেয়াদী)', 'নূরানী বিভাগ', 'হিফজুল কুরআন'],
      en: ['General (Play–Ten)', 'Cadet (2 Years)', 'Noorani Wing', 'Hifzul Quran'],
      ar: ['القسم العام', 'برنامج الكاديت', 'قسم النوراني', 'تحفيظ القرآن'],
    },
  },
  {
    id: 'feat-five-stage-assessment',
    indexByLang: { bn: 'বৈশিষ্ট্য ০২', en: 'Feature 02', ar: 'الميزة ٠٢' },
    kickerByLang: {
      bn: 'ধারাবাহিক মূল্যায়ন · Continuous Evaluation',
      en: '5-Stage Assessment · ধারাবাহিক মূল্যায়ন',
      ar: 'التقييم المستمر · اختبارات متعددة المراحل',
    },
    titleBn: 'সাপ্তাহিক, মাসিক, সেমিস্টার, বাৎসরিক ও ভাইবা টেস্টের মাধ্যমে প্রত্যেক শিক্ষার্থীকে যোগ্য করে গড়ে তোলা হয়।',
    titleEn: 'Every Student Qualified Through Weekly, Monthly, Semester, Annual & Viva Tests',
    titleAr: 'تأهيل كل طالب عبر الاختبارات الأسبوعية والشهرية والفصلية والسنوية والمقابلات الشفهية',
    titleByLang: {
      bn: 'সাপ্তাহিক, মাসিক, সেমিস্টার, বাৎসরিক ও ভাইবা টেস্টের মাধ্যমে প্রত্যেক শিক্ষার্থীকে যোগ্য করে গড়ে তোলা হয়।',
      en: 'Every Student Qualified Through Weekly, Monthly, Semester, Annual & Viva Tests',
      ar: 'تأهيل كل طالب عبر الاختبارات الأسبوعية والشهرية والفصلية والسنوية والمقابلات الشفهية',
    },
    descriptionByLang: {
      bn: 'প্রতিটি শিফট ও বিভাগে (৩০:১ অনুপাতে) নিয়মিত লিখিত, সবিনা ও মৌখিক ভাইভা মূল্যায়নের মাধ্যমে শিক্ষার্থীর দুর্বলতা চিহ্নিত করে নিরবচ্ছিন্ন অগ্রগতি নিশ্চিত করা হয়।',
      en: 'Across every wing at a focused 30:1 ratio, scheduled written papers, Sabina audits, and oral viva boards diagnose gaps early and build steady mastery year-round.',
      ar: 'في كل قسم وبنسبة إشراف ٣٠:١، تسهم الاختبارات التحريرية ومراجعات السبينا والامتحانات الشفهية في معالجة نقاط الضعف وبناء التفوق المستمر.',
    },
    checkpointsByLang: {
      bn: ['সাপ্তাহিক টেস্ট (২–৩ ঘণ্টা)', 'মাসিক মূল্যায়ন', 'সেমিস্টার পরীক্ষা', 'বাৎসরিক ফাইনাল', 'ভাইবা-ভোস পরীক্ষা'],
      en: ['Weekly Test (2–3 hrs)', 'Monthly Review', 'Semester Exam', 'Annual Final', 'Viva-Voce Board'],
      ar: ['اختبار أسبوعي', 'تقييم شهري', 'امتحان فصلي', 'اختبار سنوي', 'امتحان شفوي'],
    },
  },
  {
    id: 'feat-moral-values',
    indexByLang: { bn: 'বৈশিষ্ট্য ০৩', en: 'Feature 03', ar: 'الميزة ٠٣' },
    kickerByLang: {
      bn: 'আদব ও চরিত্র · Character & Adab',
      en: 'Moral Values · নৈতিক চরিত্র',
      ar: 'الأخلاق والتربية · القيم الإسلامية',
    },
    titleBn: 'নৈতিক মূল্যবোধ শিক্ষা',
    titleEn: 'Moral & Ethical Values Education',
    titleAr: 'تعليم القيم الأخلاقية والتربية الإسلامية',
    titleByLang: {
      bn: 'নৈতিক মূল্যবোধ শিক্ষা',
      en: 'Moral & Ethical Values Education',
      ar: 'تعليم القيم الأخلاقية والتربية الإسلامية',
    },
    descriptionByLang: {
      bn: 'দৈনন্দিন জামাতে সালাত, পিতা-মাতা ও শিক্ষকদের প্রতি শ্রদ্ধাবোধ, সত্যবাদিতা, শৃঙ্খলা এবং সুন্নাহভিত্তিক আদব-কায়দার অনুশীলনের মাধ্যমে প্রতিটি শিক্ষার্থীর মাঝে উচ্চ নৈতিক চরিত্র গড়ে তোলা হয়।',
      en: 'Daily congregational Salah, honesty, respect for parents and teachers, personal discipline, and Sunnah-inspired Adab form the bedrock of student life across every grade.',
      ar: 'تربية الطلاب على أداء الصلاة جماعة، والصدق، وبر الوالدين، واحترام المعلمين، والانضباط الشخصي، والآداب النبوية في جميع المراحل الدراسية.',
    },
  },
  {
    id: 'feat-trilingual',
    indexByLang: { bn: 'বৈশিষ্ট্য ০৪', en: 'Feature 04', ar: 'الميزة ٠৪' },
    kickerByLang: {
      bn: 'ত্রিভাষিক দক্ষতা · Trilingual Mastery',
      en: 'Three Languages · ত্রিভাষিক শিক্ষা',
      ar: 'إتقان اللغات الثلاث · التعليم اللغوي',
    },
    titleBn: 'বাংলা, ইংরেজি ও আরবি শিক্ষা',
    titleEn: 'Bangla, English & Arabic Language Education',
    titleAr: 'تعليم اللغات البنغالية والإنجليزية والعربية',
    titleByLang: {
      bn: 'বাংলা, ইংরেজি ও আরবি শিক্ষা',
      en: 'Bangla, English & Arabic Language Education',
      ar: 'تعليم اللغات البنغالية والإنجليزية والعربية',
    },
    descriptionByLang: {
      bn: 'বিশুদ্ধ মাতৃভাষা বাংলা চর্চা, আন্তর্জাতিক যোগাযোগের জন্য সাবলীল ইংরেজি এবং কুরআন-হাদিস অনুধাবনের জন্য প্রাথমিক পর্যায় থেকেই প্রাঞ্জল আরবি ভাষায় সমান দক্ষতা গড়ে তোলা হয়।',
      en: 'Structured fluency in Bangla literacy, spoken and written English for modern academic readiness, and classical Arabic grammar from early grades to comprehend Quranic texts directly.',
      ar: 'بناء إتقان متوازن في اللغة البنغالية الأم، والإنجليزية قراءةً ومحادثةً للتميز الأكاديمي، واللغة العربية منذ المراحل المبكرة لفهم القرآن والسنة مباشرة.',
    },
  },
  {
    id: 'feat-practical',
    indexByLang: { bn: 'বৈশিষ্ট্য ০৫', en: 'Feature 05', ar: 'الميزة ٠৫' },
    kickerByLang: {
      bn: 'হাতে-কলমে দক্ষতা · Applied Learning',
      en: 'Practical Learning · প্রাক্টিক্যাল শিক্ষা',
      ar: 'التعليم العملي · مواكبة العصر',
    },
    titleBn: 'প্রাক্টিক্যাল শিক্ষার মাধ্যমে যুগোপযোগী করে গড়ে তোলা',
    titleEn: 'Preparing Contemporary Learners Through Practical Education',
    titleAr: 'تأهيل الطلاب لمواكبة العصر عبر التعليم العملي التطبيقي',
    titleByLang: {
      bn: 'প্রাক্টিক্যাল শিক্ষার মাধ্যমে যুগোপযোগী করে গড়ে তোলা',
      en: 'Preparing Contemporary Learners Through Practical Education',
      ar: 'تأهيل الطلاب لمواكبة العصر عبر التعليم العملي التطبيقي',
    },
    descriptionByLang: {
      bn: 'শুধু মুখস্থনির্ভরতা নয়—বিজ্ঞান গবেষণাগার, কম্পিউটার ও আইসিটি ল্যাব, ব্যবহারিক সালাত-তাজবিদ অনুশীলন এবং বাস্তব জীবনমুখী প্রজেক্টের মাধ্যমে শিক্ষার্থীদের সময়ের চাহিদা অনুযায়ী যুগোপযোগী ও আত্মনির্ভরশীল করে গড়ে তোলা হয়।',
      en: 'Moving beyond rote memorization through supervised STEM laboratory experiments, ICT & digital literacy sessions, practical Salah & Tajweed workshops, and real-world student projects.',
      ar: 'تجاوز الحفظ المجرد عبر التجارب المخبرية في العلوم، ومعامل الحاسوب وتقنية المعلومات، والتطبيق العملي للعبادات والتجويد، والمشاريع التطبيقية المواكبة للعصر.',
    },
  },
];

export const HERO_CAMPUS_FIGURE: CampusFigure = {
  id: 'fig-1-hero-campus',
  src: '/src/assets/images/hero_campus_courtyard_1795334815845.jpg',
  captionByLang: {
    bn: 'চিত্র ১ — প্রস্তাবিত ভবন / ক্যাম্পাস: মূল একাডেমিক ভবন, নামাজের খিলান বারান্দা ও কেন্দ্রীয় প্রাঙ্গণ',
    en: 'Fig. 1 — Proposed Building / Campus: Main Academic Building, Prayer Cloister & Central Courtyard',
    ar: 'شكل ١ — المبنى / الحرم المقترح: المبنى الأكاديمي الرئيسي ورواق الصلاة والفناء المركزي',
  },
  altByLang: {
    bn: 'ফারমিটম ইসলামিক স্কুল এন্ড কলেজ এর প্রস্তাবিত ভবন ও ক্যাম্পাস প্রাঙ্গণ এবং খিলানযুক্ত বারান্দা',
    en: 'Proposed building and sunlit academic campus courtyard with arched prayer cloister at FARMITAM Islamic School & College',
    ar: 'المبنى والحرم الأكاديمي المقترح في مدرسة وكلية فارميتام الإسلامية مع رواق الصلاة المقوس',
  },
  fallbackTitle: 'প্রস্তাবিত ভবন / ক্যাম্পাস',
};

export const CAMPUS_GALLERY_FIGURES: CampusFigure[] = [
  {
    id: 'fig-2-junior-classroom',
    src: '/src/assets/images/young_students_classroom_1795338513689.jpg',
    captionByLang: {
      bn: 'চিত্র ২ — প্রস্তাবিত ভবন / ক্যাম্পাস শ্রেণিকক্ষ (কনিষ্ঠ শিক্ষার্থী: প্লে–প্রাথমিক ও নূরানী): স্নেহময় পাঠদান ও বর্ণমালা-কুরআন শিক্ষার পরিবেশ',
      en: 'Fig. 2 — Proposed Building / Campus Classroom (Junior Learners: Play–Primary & Noorani): Interactive Early Learning Environment',
      ar: 'شكل ٢ — قاعة الفصول في المبنى / الحرم المقترح (الروضة–الابتدائي والنوراني): بيئة صفية دافئة وتفاعلية',
    },
    altByLang: {
      bn: 'প্রস্তাবিত ভবন ও ক্যাম্পাসের কনিষ্ঠ শিক্ষার্থী (প্লে থেকে প্রাথমিক ও নূরানী) শ্রেণিকক্ষে শিক্ষকের তত্ত্বাবধানে আনন্দময় পাঠদান পরিবেশ',
      en: 'Young Playgroup to Primary Muslim students learning joyfully inside the proposed building and campus classroom',
      ar: 'طلاب المرحلة التأسيسية الصغار يتعلمون في قاعة الفصول بالمبنى والحرم المقترح بإشراف المعلم',
    },
    fallbackTitle: 'প্রস্তাবিত ভবন / ক্যাম্পাস শ্রেণিকক্ষ',
  },
  {
    id: 'fig-3-senior-campus',
    src: '/src/assets/images/senior_students_campus_1795338513324.jpg',
    captionByLang: {
      bn: 'চিত্র ৩ — প্রস্তাবিত ক্যাম্পাস / ভবন প্রাঙ্গণ (জ্যেষ্ঠ শিক্ষার্থী: ষষ্ঠ–দশম ও ক্যাডেট): সুশৃঙ্খল শিক্ষা ও দলগত অধ্যয়ন পরিবেশ',
      en: 'Fig. 3 — Proposed Campus / Building Courtyard (Senior Scholars: Classes VI–X & Cadet): Disciplined Academic Study Environment',
      ar: 'شكل ٣ — ساحة الحرم / المبنى المقترح (طلاب السادس–العاشر والكاديت): بيئة دراسية منضبطة',
    },
    altByLang: {
      bn: 'প্রস্তাবিত ক্যাম্পাস ও ভবন প্রাঙ্গণে জ্যেষ্ঠ শিক্ষার্থী (ষষ্ঠ থেকে দশম ও ক্যাডেট) অধ্যয়ন ও দলগত আলোচনায় মগ্ন',
      en: 'Senior high-school and Cadet students studying together in the proposed campus and academic building courtyard',
      ar: 'طلاب المرحلة العليا والكاديت يدرسون معاً في ساحة الحرم والمبنى الأكاديمي المقترح',
    },
    fallbackTitle: 'প্রস্তাবিত ক্যাম্পাস / ভবন',
  },
  {
    id: 'fig-4-library',
    src: '/src/assets/images/campus_library_study_1795334816644.jpg',
    captionByLang: {
      bn: 'চিত্র ৪ — প্রস্তাবিত লাইব্রেরী: কেন্দ্রীয় কলেজ পাঠাগার ও ক্লাসিক্যাল গ্রন্থ অধ্যয়ন কক্ষ',
      en: 'Fig. 4 — Proposed Library: Central College Reading Hall & Classical Scholarship Collection',
      ar: 'شكل ٤ — المكتبة المقترحة: قاعة المطالعة المركزية ومجموعة الكتب التراثية',
    },
    altByLang: {
      bn: 'খিলানযুক্ত জানালা ও কাঠের পড়ার টেবিলসমৃদ্ধ প্রস্তাবিত লাইব্রেরী ও কেন্দ্রীয় কলেজ পাঠাগার',
      en: 'Proposed central college library with arched windows and hardwood reading tables',
      ar: 'المكتبة المقترحة للكلية المزودة بطاولات القراءة الخشبية والنوافذ المقوسة',
    },
    fallbackTitle: 'প্রস্তাবিত লাইব্রেরী',
  },
  {
    id: 'fig-5-laboratory',
    src: '/src/assets/images/science_laboratory_1795334815892.jpg',
    captionByLang: {
      bn: 'চিত্র ৫ — প্রস্তাবিত ল্যাব: জেনারেল ও ক্যাডেট বিভাগের পদার্থ, রসায়ন ও জীববিজ্ঞান গবেষণাগার',
      en: 'Fig. 5 — Proposed Lab: Physics, Chemistry & Biology Laboratory for General & Cadet Divisions',
      ar: 'شكل ٥ — المختبر المقترح: مختبر الفيزياء والكيمياء والأحياء للقسم العام والكاديت',
    },
    altByLang: {
      bn: 'অণুবীক্ষণ যন্ত্র ও আধুনিক সরঞ্জামসমৃদ্ধ প্রস্তাবিত ল্যাব (পদার্থবিজ্ঞান, রসায়ন ও জীববিজ্ঞান গবেষণাগার)',
      en: 'Proposed Physics, Chemistry, and Biology science laboratory equipped with microscopes and apparatus',
      ar: 'المختبر العلمي المقترح للفيزياء والكيمياء والأحياء المجهز بالمجاهر والأدوات الحديثة',
    },
    fallbackTitle: 'প্রস্তাবিত ল্যাব',
  },
];




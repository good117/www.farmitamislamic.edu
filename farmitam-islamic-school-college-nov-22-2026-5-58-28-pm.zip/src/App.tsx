import { useState } from 'react';
import { AcademicsSection } from './components/AcademicsSection';
import { AdmissionsSection } from './components/AdmissionsSection';
import { FeaturesSection } from './components/FeaturesSection';
import { Footer } from './components/Footer';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { HistorySection } from './components/HistorySection';
import { LeadershipFacultySection } from './components/LeadershipFacultySection';
import { NoticesScheduleSection } from './components/NoticesScheduleSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { LanguageProvider } from './context/LanguageContext';
import type { DivisionId } from './data/schoolData';
import type { ResidentialOption, ShiftOption } from './utils/admissions';

export default function App() {
  const [activeDivision, setActiveDivision] = useState<DivisionId>('general');
  const [prefill, setPrefill] = useState<{
    division?: DivisionId;
    shift?: ShiftOption;
    residential?: ResidentialOption;
  }>({});

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToAdmissions = () => scrollToSection('admissions');

  const handleSelectHighlightedDivision = (division: DivisionId) => {
    setActiveDivision(division);
    scrollToSection('academics');
  };

  const handleApplyFromEstimator = (
    division: DivisionId,
    shift: ShiftOption,
    residential: ResidentialOption
  ) => {
    setPrefill({ division, shift, residential });
    scrollToAdmissions();
  };

  return (
    <LanguageProvider>
      <div className="min-h-screen flex flex-col bg-[#FAF8F4] text-[#1A1F1C]">
        <Header onApplyClick={scrollToAdmissions} />
        <main className="flex-1">
          <HeroSection
            onApplyClick={scrollToAdmissions}
            onSelectDivision={handleSelectHighlightedDivision}
          />
          <AcademicsSection
            activeDivision={activeDivision}
            onChangeDivision={setActiveDivision}
            onSelectDivisionForApplication={handleApplyFromEstimator}
          />
          <FeaturesSection />
          <HistorySection />
          <LeadershipFacultySection />
          <NoticesScheduleSection />
          <TestimonialsSection />
          <AdmissionsSection
            prefillDivision={prefill.division}
            prefillShift={prefill.shift}
            prefillResidential={prefill.residential}
          />
        </main>
        <Footer />
      </div>
    </LanguageProvider>
  );
}

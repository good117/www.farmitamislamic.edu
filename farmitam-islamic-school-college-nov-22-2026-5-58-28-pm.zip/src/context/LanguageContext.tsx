import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import {
  detectPreferredLanguage,
  getDirectionForLang,
  resolveDescriptionLang,
  type DescriptionLang,
  type LangMode,
} from '../utils/i18n';

const LANG_STORAGE_KEY = 'farmitam_desc_lang_mode_v1';

interface LanguageContextValue {
  mode: LangMode;
  lang: DescriptionLang;
  detectedLang: DescriptionLang;
  dir: 'rtl' | 'ltr';
  setMode: (nextMode: LangMode) => void;
}

const LanguageContext = createContext<LanguageContextValue | null>(null);

function getBrowserLanguages(): string[] {
  if (typeof navigator === 'undefined') return ['bn'];
  if (Array.isArray(navigator.languages) && navigator.languages.length > 0) {
    return [...navigator.languages];
  }
  return navigator.language ? [navigator.language] : ['bn'];
}

function getInitialMode(): LangMode {
  if (typeof window !== 'undefined') {
    const params = new URLSearchParams(window.location.search);
    const paramLang = params.get('lang');
    if (paramLang === 'auto' || paramLang === 'bn' || paramLang === 'en' || paramLang === 'ar') {
      return paramLang;
    }
    try {
      const saved = localStorage.getItem(LANG_STORAGE_KEY);
      if (saved === 'auto' || saved === 'bn' || saved === 'en' || saved === 'ar') {
        return saved;
      }
    } catch {
      // Ignore storage errors
    }
  }
  return 'bn';
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [mode, setModeState] = useState<LangMode>(getInitialMode);
  const browserLanguages = getBrowserLanguages();
  const detectedLang = detectPreferredLanguage(browserLanguages);
  const lang = resolveDescriptionLang(mode, browserLanguages);
  const dir = getDirectionForLang(lang);

  const setMode = (nextMode: LangMode) => {
    setModeState(nextMode);
    try {
      localStorage.setItem(LANG_STORAGE_KEY, nextMode);
    } catch {
      // Ignore storage errors
    }
  };

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  return (
    <LanguageContext.Provider value={{ mode, lang, detectedLang, dir, setMode }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useDescriptionLanguage(): LanguageContextValue {
  const ctx = useContext(LanguageContext);
  if (!ctx) {
    throw new Error('useDescriptionLanguage must be used within a LanguageProvider');
  }
  return ctx;
}
